import React, { useState } from 'react';
import { PerformanceChart, OutputChart } from './Charts';
import { ACTIVITIES, WORKFLOWS, PROJECTS, AGENTS, KNOWLEDGE_ITEMS, ROADMAP_ITEMS } from '../constants';
import { ActivityItem, AgentCard } from './DashboardComponents';
import { Agent, Workflow, WorkflowStep, Project, ProjectFile, ProjectAgentResult, ProjectTeamMember, ProjectMilestone, ProjectActivityItem, KnowledgeItem, KnowledgeType, StickyNote, RoadmapItem, RoadmapType } from '../types';

// --- Reusable Layout Component ---
const ViewLayout: React.FC<{ 
  title: string; 
  description: string; 
  action?: React.ReactNode;
  children: React.ReactNode 
}> = ({ title, description, action, children }) => (
  <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
    <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-8 gap-4">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
        <p className="text-gray-500 mt-1">{description}</p>
      </div>
      {action && <div className="flex-shrink-0">{action}</div>}
    </div>
    {children}
  </div>
);

// --- Workflows View ---
export const WorkflowsView: React.FC = () => {
    const [viewMode, setViewMode] = useState<'list' | 'create'>('list');
    const [workflows, setWorkflows] = useState<Workflow[]>(WORKFLOWS);
    
    // Creator state
    const [newWorkflowName, setNewWorkflowName] = useState('');
    const [newWorkflowSteps, setNewWorkflowSteps] = useState<WorkflowStep[]>([]);
    
    // Drag and Drop state
    const [draggedStepIndex, setDraggedStepIndex] = useState<number | null>(null);
    
    const handleAddStep = (type: 'Trigger' | 'Action') => {
        const id = (newWorkflowSteps.length + 1).toString();
        const newStep: WorkflowStep = {
            id: Date.now().toString(), // Use timestamp for unique keys
            order: newWorkflowSteps.length + 1,
            name: type === 'Trigger' ? 'New Trigger' : 'New Action',
            type,
            details: type === 'Trigger' ? 'Define trigger condition' : 'Select action to perform',
            icon: type === 'Trigger' ? 'fa-bolt' : 'fa-gear'
        };
        setNewWorkflowSteps([...newWorkflowSteps, newStep]);
    };

    const handleDeleteStep = (index: number) => {
        const updatedSteps = [...newWorkflowSteps];
        updatedSteps.splice(index, 1);
        // Re-index orders
        updatedSteps.forEach((step, i) => step.order = i + 1);
        setNewWorkflowSteps(updatedSteps);
    };

    const handleSaveWorkflow = () => {
        if (!newWorkflowName) return;
        const newWorkflow: Workflow = {
            id: (workflows.length + 1).toString(),
            name: newWorkflowName,
            description: 'Custom manual workflow',
            status: 'Active',
            steps: newWorkflowSteps,
            lastRun: 'Just now'
        };
        setWorkflows([...workflows, newWorkflow]);
        setViewMode('list');
        setNewWorkflowName('');
        setNewWorkflowSteps([]);
    };

    // Drag Handlers
    const handleDragStart = (e: React.DragEvent, index: number) => {
        setDraggedStepIndex(index);
        // Set drag effect
        e.dataTransfer.effectAllowed = "move";
        // Optional: You can set a custom drag image here if needed
    };

    const handleDragOver = (e: React.DragEvent, index: number) => {
        e.preventDefault(); // Necessary to allow dropping
        if (draggedStepIndex === null) return;
        
        if (draggedStepIndex !== index) {
            const updatedSteps = [...newWorkflowSteps];
            const draggedItem = updatedSteps[draggedStepIndex];
            
            // Remove from old position
            updatedSteps.splice(draggedStepIndex, 1);
            // Insert at new position
            updatedSteps.splice(index, 0, draggedItem);
            
            // Update order property
            updatedSteps.forEach((step, i) => step.order = i + 1);
            
            setNewWorkflowSteps(updatedSteps);
            setDraggedStepIndex(index);
        }
    };

    const handleDragEnd = () => {
        setDraggedStepIndex(null);
    };

    if (viewMode === 'create') {
        return (
            <ViewLayout title="Create Manual Workflow" description="Define your automation sequence step-by-step.">
                <div className="flex flex-col lg:flex-row gap-6 h-[calc(100vh-200px)]">
                    {/* Sidebar Configuration */}
                    <div className="w-full lg:w-1/3 flex flex-col gap-4">
                        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
                            <h3 className="text-lg font-bold text-gray-900 mb-4">Workflow Details</h3>
                            <div className="space-y-4">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">Workflow Name</label>
                                    <input 
                                        type="text" 
                                        value={newWorkflowName}
                                        onChange={(e) => setNewWorkflowName(e.target.value)}
                                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" 
                                        placeholder="e.g., Daily Design Sync"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                                    <textarea 
                                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" 
                                        placeholder="Describe what this workflow does..."
                                        rows={3}
                                    ></textarea>
                                </div>
                            </div>
                        </div>

                         <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm flex-grow">
                            <h3 className="text-lg font-bold text-gray-900 mb-4">Toolbox</h3>
                            <div className="space-y-3">
                                <button onClick={() => handleAddStep('Trigger')} className="w-full text-left p-3 border border-gray-200 rounded-lg hover:bg-gray-50 flex items-center transition-colors group">
                                    <div className="w-10 h-10 rounded-lg bg-yellow-100 text-yellow-600 flex items-center justify-center mr-3 group-hover:scale-110 transition-transform">
                                        <i className="fa-solid fa-bolt"></i>
                                    </div>
                                    <div>
                                        <div className="text-sm font-medium text-gray-900">Add Trigger</div>
                                        <div className="text-xs text-gray-500">Start the workflow</div>
                                    </div>
                                    <i className="fa-solid fa-plus ml-auto text-gray-300 group-hover:text-indigo-600"></i>
                                </button>
                                <button onClick={() => handleAddStep('Action')} className="w-full text-left p-3 border border-gray-200 rounded-lg hover:bg-gray-50 flex items-center transition-colors group">
                                    <div className="w-10 h-10 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center mr-3 group-hover:scale-110 transition-transform">
                                        <i className="fa-solid fa-play"></i>
                                    </div>
                                    <div>
                                        <div className="text-sm font-medium text-gray-900">Add Action</div>
                                        <div className="text-xs text-gray-500">Perform a task</div>
                                    </div>
                                    <i className="fa-solid fa-plus ml-auto text-gray-300 group-hover:text-indigo-600"></i>
                                </button>
                            </div>
                        </div>
                    </div>

                    {/* Canvas / Timeline */}
                    <div className="w-full lg:w-2/3 bg-slate-50 rounded-xl border border-gray-200 p-8 relative overflow-y-auto min-h-[500px]">
                        <div className="absolute top-4 right-4 flex space-x-3 z-20">
                             <button onClick={() => setViewMode('list')} className="px-4 py-2 text-sm text-gray-600 hover:text-gray-900 font-medium">Cancel</button>
                             <button onClick={handleSaveWorkflow} className="px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700 shadow-sm">Save Workflow</button>
                        </div>

                        <div className="max-w-xl mx-auto mt-8 pb-10">
                             {/* Start Node */}
                             <div className="flex justify-center mb-0 relative z-10">
                                <div className="px-4 py-1.5 bg-gray-800 text-white text-[10px] font-bold rounded-full shadow-sm uppercase tracking-wider flex items-center gap-2">
                                    <i className="fa-solid fa-power-off"></i> Start
                                </div>
                             </div>
                             
                             {/* Vertical Connector Line from Start */}
                             <div className="h-8 w-0.5 bg-gray-300 mx-auto"></div>

                             {newWorkflowSteps.length === 0 ? (
                                 <div className="text-center py-16 border-2 border-dashed border-gray-300 rounded-xl bg-white/50">
                                     <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4 text-gray-400">
                                         <i className="fa-solid fa-diagram-project text-2xl"></i>
                                     </div>
                                     <h3 className="text-lg font-medium text-gray-900">Start Building</h3>
                                     <p className="text-gray-500">Add a trigger from the toolbox to begin.</p>
                                 </div>
                             ) : (
                                 <div className="relative">
                                     {/* Continuous Vertical Line */}
                                     <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-gray-300 z-0"></div>
                                     
                                     {newWorkflowSteps.map((step, idx) => (
                                         <div 
                                            key={step.id} 
                                            draggable
                                            onDragStart={(e) => handleDragStart(e, idx)}
                                            onDragOver={(e) => handleDragOver(e, idx)}
                                            onDragEnd={handleDragEnd}
                                            className={`relative z-10 mb-6 group transition-all duration-200 ${draggedStepIndex === idx ? 'opacity-40 scale-95' : 'opacity-100'}`}
                                         >
                                             <div className="flex items-start">
                                                 {/* Icon Node */}
                                                 <div className={`w-12 h-12 rounded-full border-4 border-slate-50 shadow-sm flex items-center justify-center flex-shrink-0 cursor-grab active:cursor-grabbing hover:scale-105 transition-transform ${step.type === 'Trigger' ? 'bg-amber-100 text-amber-600' : 'bg-indigo-100 text-indigo-600'}`}>
                                                     <i className={`fa-solid ${step.icon}`}></i>
                                                 </div>
                                                 
                                                 {/* Card Content */}
                                                 <div className="ml-6 flex-grow">
                                                    <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-shadow relative group-hover:border-indigo-300">
                                                        {/* Drag Handle */}
                                                        <div className="absolute left-2 top-1/2 -translate-y-1/2 text-gray-300 cursor-grab active:cursor-grabbing p-2 hover:text-gray-500 hidden group-hover:block animate-in fade-in">
                                                            <i className="fa-solid fa-grip-vertical"></i>
                                                        </div>
                                                        
                                                        <div className="pl-6">
                                                            <div className="flex justify-between items-start mb-1">
                                                                <h4 className="text-sm font-bold text-gray-900">{step.name}</h4>
                                                                <button 
                                                                    onClick={() => handleDeleteStep(idx)}
                                                                    className="text-gray-300 hover:text-red-500 transition-colors p-1"
                                                                >
                                                                    <i className="fa-solid fa-times"></i>
                                                                </button>
                                                            </div>
                                                            <p className="text-xs text-gray-500">{step.details}</p>
                                                        </div>
                                                        
                                                        {/* Type Badge */}
                                                        <div className={`absolute -top-2 -right-2 px-2 py-0.5 text-[10px] font-bold rounded-full border shadow-sm ${step.type === 'Trigger' ? 'bg-amber-50 text-amber-700 border-amber-100' : 'bg-indigo-50 text-indigo-700 border-indigo-100'}`}>
                                                            {step.type}
                                                        </div>
                                                    </div>
                                                 </div>
                                             </div>
                                             
                                             {/* Arrow Indicator between steps */}
                                             {idx < newWorkflowSteps.length - 1 && (
                                                <div className="absolute left-6 -ml-[5px] -bottom-4 text-gray-400 z-10 w-3 h-3 flex items-center justify-center">
                                                    <i className="fa-solid fa-caret-down"></i>
                                                </div>
                                             )}
                                         </div>
                                     ))}
                                     
                                     {/* End Node */}
                                     <div className="flex items-center mt-2">
                                         <div className="w-12 flex justify-center z-10">
                                             <div className="w-4 h-4 bg-gray-300 rounded-full border-2 border-white ring-2 ring-gray-100"></div>
                                         </div>
                                         <span className="ml-6 text-xs text-gray-400 font-medium uppercase tracking-wider">End</span>
                                     </div>
                                 </div>
                             )}
                        </div>
                    </div>
                </div>
            </ViewLayout>
        );
    }

    return (
        <ViewLayout title="Automation Workflows" description="Orchestrate your design agents with automated sequences.">
            <div className="flex justify-between items-center mb-6">
                <div className="relative">
                    <input type="text" placeholder="Search workflows..." className="pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                    <i className="fa-solid fa-search absolute left-3 top-2.5 text-gray-400"></i>
                </div>
                <button onClick={() => setViewMode('create')} className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-indigo-700 shadow-sm flex items-center">
                    <i className="fa-solid fa-plus mr-2"></i>
                    New Workflow
                </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {workflows.map((workflow) => (
                    <div key={workflow.id} className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-md transition-shadow group">
                        <div className="flex justify-between items-start mb-4">
                            <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${workflow.status === 'Active' ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-500'}`}>
                                <i className="fa-solid fa-diagram-project text-xl"></i>
                            </div>
                            <div className="flex space-x-2">
                                <span className={`px-2.5 py-0.5 text-xs font-medium rounded-full ${workflow.status === 'Active' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'}`}>
                                    {workflow.status}
                                </span>
                                <button className="text-gray-400 hover:text-gray-600"><i className="fa-solid fa-ellipsis-vertical"></i></button>
                            </div>
                        </div>
                        <h3 className="text-lg font-bold text-gray-900 mb-2">{workflow.name}</h3>
                        <p className="text-sm text-gray-500 mb-4 h-10 line-clamp-2">{workflow.description}</p>
                        
                        <div className="bg-gray-50 rounded-lg p-3 mb-4">
                            <div className="flex items-center space-x-2 text-xs text-gray-500 mb-2">
                                <i className="fa-solid fa-layer-group"></i>
                                <span>{workflow.steps.length} Steps Sequence</span>
                            </div>
                            <div className="flex items-center space-x-1">
                                {workflow.steps.slice(0, 5).map((step, i) => (
                                    <React.Fragment key={i}>
                                        <div className={`w-6 h-6 rounded flex items-center justify-center text-[10px] ${step.type === 'Trigger' ? 'bg-yellow-100 text-yellow-600' : 'bg-blue-100 text-blue-600'}`} title={step.name}>
                                            <i className={`fa-solid ${step.icon}`}></i>
                                        </div>
                                        {i < workflow.steps.length - 1 && i < 4 && <div className="w-2 h-px bg-gray-300"></div>}
                                    </React.Fragment>
                                ))}
                                {workflow.steps.length > 5 && <span className="text-xs text-gray-400 pl-1">+{workflow.steps.length - 5}</span>}
                            </div>
                        </div>

                        <div className="flex justify-between items-center pt-2 border-t border-gray-100">
                             <span className="text-xs text-gray-500">Run: {workflow.lastRun}</span>
                             <button className="text-indigo-600 text-sm font-medium hover:underline flex items-center">
                                 Details <i className="fa-solid fa-arrow-right ml-1 text-xs"></i>
                             </button>
                        </div>
                    </div>
                ))}
                
                <div 
                    onClick={() => setViewMode('create')}
                    className="border-2 border-dashed border-gray-200 rounded-xl p-6 flex flex-col items-center justify-center cursor-pointer hover:border-indigo-300 hover:bg-indigo-50 transition-colors text-gray-400 hover:text-indigo-600"
                >
                    <i className="fa-solid fa-plus text-3xl mb-3"></i>
                    <span className="font-medium">Create Manual Workflow</span>
                </div>
            </div>
        </ViewLayout>
    );
};

// --- Agents View ---
export const AgentsView: React.FC<{ 
  agents: Agent[]; 
  onEdit: (agent: Agent) => void; 
  onNew: () => void;
  onRun?: (agent: Agent) => void;
  onDuplicate?: (agent: Agent) => void;
}> = ({ agents, onEdit, onNew, onRun, onDuplicate }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState('All');

  const categories = ['All', 'Review', 'Research', 'Docs', 'Testing', 'Analysis', 'Brand', 'Strategy', 'Journey', 'Wireframe', 'Writing'];

  const filteredAgents = agents.filter(agent => {
    const matchesSearch = agent.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          agent.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          agent.tags.some(t => t.label.toLowerCase().includes(searchTerm.toLowerCase()));
    
    if (filter === 'All') return matchesSearch;
    const matchesFilter = agent.tags.some(t => t.label.toLowerCase() === filter.toLowerCase() || t.label.toLowerCase().includes(filter.toLowerCase()) || filter.toLowerCase().includes(t.label.toLowerCase())) ||
                          (filter === 'Docs' && (agent.tags.some(t => t.label === 'Documentation') || agent.name.toLowerCase().includes('document') || agent.name.toLowerCase().includes('notes'))) ||
                          (filter === 'Brand' && agent.name.toLowerCase().includes('brand')) ||
                          (filter === 'Writing' && agent.name.toLowerCase().includes('writer')) ||
                          (filter === 'Wireframe' && agent.name.toLowerCase().includes('wireframe')) ||
                          (filter === 'Journey' && agent.name.toLowerCase().includes('journey'));
    return matchesSearch && matchesFilter;
  });

  return (
    <ViewLayout title="AI Agents" description="Manage, customize, and run your 15 intelligent UX design assistants.">
       {/* Stats Overview */}
       <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm flex items-center space-x-4">
                <div className="w-12 h-12 bg-indigo-100 text-indigo-600 rounded-lg flex items-center justify-center text-xl">
                    <i className="fa-solid fa-robot"></i>
                </div>
                <div>
                    <div className="text-2xl font-bold text-gray-900">{agents.length}</div>
                    <div className="text-xs text-gray-500">Configured Agents</div>
                </div>
            </div>
             <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm flex items-center space-x-4">
                <div className="w-12 h-12 bg-green-100 text-green-600 rounded-lg flex items-center justify-center text-xl">
                    <i className="fa-solid fa-bolt"></i>
                </div>
                <div>
                    <div className="text-2xl font-bold text-gray-900">{agents.filter(a => a.status === 'Active').length}</div>
                    <div className="text-xs text-gray-500">Active Agents</div>
                </div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm flex items-center space-x-4">
                <div className="w-12 h-12 bg-purple-100 text-purple-600 rounded-lg flex items-center justify-center text-xl">
                    <i className="fa-solid fa-play"></i>
                </div>
                <div>
                    <div className="text-2xl font-bold text-gray-900">8.4k</div>
                    <div className="text-xs text-gray-500">Total Runs</div>
                </div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm flex items-center space-x-4">
                <div className="w-12 h-12 bg-orange-100 text-orange-600 rounded-lg flex items-center justify-center text-xl">
                    <i className="fa-solid fa-star"></i>
                </div>
                <div>
                    <div className="text-2xl font-bold text-gray-900">97.8%</div>
                    <div className="text-xs text-gray-500">Avg. Success</div>
                </div>
            </div>
       </div>

       {/* Controls */}
       <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4 bg-white p-2 rounded-xl border border-gray-200 shadow-sm">
          <div className="flex items-center overflow-x-auto w-full md:w-auto pb-2 md:pb-0 scrollbar-hide px-2">
              {categories.map(cat => (
                  <button 
                    key={cat}
                    onClick={() => setFilter(cat)}
                    className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-all whitespace-nowrap mr-1.5 ${filter === cat ? 'bg-gray-900 text-white shadow-md' : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'}`}
                  >
                      {cat}
                  </button>
              ))}
          </div>
          
          <div className="flex items-center gap-3 w-full md:w-auto px-2">
             <div className="relative flex-grow md:flex-grow-0 w-full">
                <input 
                    type="text" 
                    placeholder="Search 15 agents..." 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full md:w-64 pl-10 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                />
                <i className="fa-solid fa-search absolute left-3 top-2.5 text-gray-400"></i>
             </div>
             <button 
                onClick={onNew}
                className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-indigo-700 flex items-center shadow-lg shadow-indigo-200 transition-colors whitespace-nowrap"
            >
                <i className="fa-solid fa-plus mr-2"></i>
                New Agent
            </button>
          </div>
       </div>

       {/* Grid */}
       <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
          {filteredAgents.length > 0 ? (
              filteredAgents.map(agent => (
                  <AgentCard 
                    key={agent.id} 
                    agent={agent} 
                    onEdit={onEdit} 
                    onRun={onRun}
                    onDuplicate={onDuplicate}
                  />
              ))
          ) : (
              <div className="col-span-full text-center py-16 bg-white rounded-xl border border-gray-200 border-dashed">
                  <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4">
                      <i className="fa-solid fa-robot text-gray-300 text-2xl"></i>
                  </div>
                  <h3 className="text-lg font-medium text-gray-900">No agents found</h3>
                  <p className="text-gray-500 mt-1">Try adjusting your search or filter settings.</p>
                  <button onClick={() => {setFilter('All'); setSearchTerm('');}} className="mt-4 text-indigo-600 font-medium hover:underline">Clear Filters</button>
              </div>
          )}
       </div>
    </ViewLayout>
  );
};

// --- Design Library View ---
export const DesignLibraryView: React.FC = () => (
  <ViewLayout title="Design Library" description="Manage your design system assets, components, and styles.">
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
       {/* Color Palette */}
       <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm col-span-1 md:col-span-3">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Color System</h3>
          <div className="flex flex-wrap gap-4">
             {['bg-indigo-600', 'bg-purple-600', 'bg-pink-600', 'bg-blue-500', 'bg-green-500', 'bg-yellow-500', 'bg-red-500', 'bg-gray-900'].map((color, idx) => (
                <div key={idx} className="group cursor-pointer">
                    <div className={`w-16 h-16 ${color} rounded-xl shadow-sm group-hover:scale-105 transition-transform`}></div>
                    <p className="text-xs text-center mt-2 text-gray-500 font-mono">Token {idx+1}</p>
                </div>
             ))}
          </div>
       </div>
    </div>
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Typography */}
        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
            <h3 className="text-lg font-bold text-gray-900 mb-4">Typography</h3>
            <div className="space-y-4">
                <div>
                    <h1 className="text-4xl font-bold text-gray-900">Heading 1</h1>
                    <p className="text-xs text-gray-400 mt-1">Inter Bold 36px</p>
                </div>
                <div>
                    <h2 className="text-3xl font-bold text-gray-900">Heading 2</h2>
                    <p className="text-xs text-gray-400 mt-1">Inter Bold 30px</p>
                </div>
                <div>
                    <h3 className="text-xl font-bold text-gray-900">Heading 3</h3>
                    <p className="text-xs text-gray-400 mt-1">Inter Bold 20px</p>
                </div>
                <div>
                    <p className="text-base text-gray-600">Body text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                    <p className="text-xs text-gray-400 mt-1">Inter Regular 16px</p>
                </div>
            </div>
        </div>
        {/* Components */}
        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
            <h3 className="text-lg font-bold text-gray-900 mb-4">Components</h3>
            <div className="space-y-6">
                <div className="flex items-center space-x-4">
                    <button className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-medium shadow-sm">Primary Button</button>
                    <button className="bg-white text-gray-700 border border-gray-300 px-4 py-2 rounded-lg text-sm font-medium shadow-sm">Secondary</button>
                    <button className="text-indigo-600 text-sm font-medium hover:underline">Link Button</button>
                </div>
                <div className="flex items-center space-x-4">
                    <div className="relative">
                        <input type="checkbox" checked className="w-5 h-5 text-indigo-600 rounded border-gray-300 focus:ring-indigo-500" readOnly />
                    </div>
                    <div className="relative">
                        <input type="radio" checked className="w-5 h-5 text-indigo-600 border-gray-300 focus:ring-indigo-500" readOnly />
                    </div>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                        Badge
                    </span>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                        Error
                    </span>
                </div>
                <div>
                    <input type="text" placeholder="Input field..." className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:border-indigo-500" />
                </div>
            </div>
        </div>
    </div>
  </ViewLayout>
);

// --- Projects View & Detail View ---

interface ProjectDetailViewProps {
  project: Project;
  onBack: () => void;
  onUpdateProject: (updated: Project) => void;
}

const ProjectDetailView: React.FC<ProjectDetailViewProps> = ({ project, onBack, onUpdateProject }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'files' | 'agents' | 'timeline' | 'team' | 'activity'>('overview');
  
  // Modals state
  const [selectedResult, setSelectedResult] = useState<ProjectAgentResult | null>(null);
  const [selectedFile, setSelectedFile] = useState<ProjectFile | null>(null);
  const [isAddFileOpen, setIsAddFileOpen] = useState(false);
  const [isAddMemberOpen, setIsAddMemberOpen] = useState(false);
  const [isRunAgentOpen, setIsRunAgentOpen] = useState(false);
  
  // Timeline Milestone state
  const [isAddMilestoneOpen, setIsAddMilestoneOpen] = useState(false);
  const [editingMilestone, setEditingMilestone] = useState<ProjectMilestone | null>(null);
  const [milestonePhase, setMilestonePhase] = useState(`Phase ${project.timeline.length + 1}`);
  const [milestoneTitle, setMilestoneTitle] = useState('');
  const [milestoneDescription, setMilestoneDescription] = useState('');
  const [milestoneStatus, setMilestoneStatus] = useState<ProjectMilestone['status']>('Upcoming');
  const [milestoneStartDate, setMilestoneStartDate] = useState('Next Week');
  const [milestoneDueDate, setMilestoneDueDate] = useState('In 3 Weeks');
  const [milestoneProgress, setMilestoneProgress] = useState(0);
  const [milestoneDeliverables, setMilestoneDeliverables] = useState<string[]>(['User Testing Protocol', 'Design Spec Review']);
  const [deliverableInput, setDeliverableInput] = useState('');
  const [quickDeliverableInputs, setQuickDeliverableInputs] = useState<{ [milestoneId: string]: string }>({});

  // New File Form
  const [newFileName, setNewFileName] = useState('');
  const [newFileType, setNewFileType] = useState<ProjectFile['type']>('Figma');
  const [newFileSize, setNewFileSize] = useState('14.2 MB');
  const [newFileSnippet, setNewFileSnippet] = useState('');

  // New Member Form
  const [newMemberName, setNewMemberName] = useState('');
  const [newMemberRole, setNewMemberRole] = useState('UI/UX Designer');
  const [newMemberEmail, setNewMemberEmail] = useState('');

  // Run Agent Form
  const [selectedAgentName, setSelectedAgentName] = useState(AGENTS[0]?.name || 'UX Design Reviewer');
  const [agentPrompt, setAgentPrompt] = useState(`Review the interface and flows for ${project.title}. Identify high-priority UX recommendations.`);
  const [isExecutingAgent, setIsExecutingAgent] = useState(false);

  // Created Files View & Filter state
  const [fileViewMode, setFileViewMode] = useState<'grid' | 'list'>('grid');
  const [fileSearch, setFileSearch] = useState('');
  const [fileTypeFilter, setFileTypeFilter] = useState<'All' | ProjectFile['type']>('All');
  const [fileSourceFilter, setFileSourceFilter] = useState<'All' | 'AI' | 'Manual' | 'URL'>('All');
  const [fileSortBy, setFileSortBy] = useState<'date-desc' | 'date-asc' | 'name-asc' | 'size-desc'>('date-desc');

  // Agent Results View & Filter state
  const [agentViewMode, setAgentViewMode] = useState<'grid' | 'list'>('grid');
  const [agentSearch, setAgentSearch] = useState('');
  const [agentFilter, setAgentFilter] = useState('All');
  const [agentStatusFilter, setAgentStatusFilter] = useState<'All' | ProjectAgentResult['status']>('All');
  const [agentSortBy, setAgentSortBy] = useState<'date-desc' | 'date-asc' | 'name-asc'>('date-desc');
  const [copiedResultId, setCopiedResultId] = useState<string | null>(null);

  // Import from URL Form State
  const [isImportUrlOpen, setIsImportUrlOpen] = useState(false);
  const [importUrl, setImportUrl] = useState('');
  const [importFileName, setImportFileName] = useState('');
  const [importFileType, setImportFileType] = useState<ProjectFile['type']>('Figma');
  const [importNotes, setImportNotes] = useState('');
  const [isImporting, setIsImporting] = useState(false);

  // Auto-detect file type and name from URL
  const handleUrlChange = (url: string) => {
    setImportUrl(url);
    const lower = url.toLowerCase();
    if (lower.includes('figma.com')) {
      setImportFileType('Figma');
      if (!importFileName || importFileName === 'Untitled_File' || importFileName.endsWith('.fig')) {
        const parts = url.split('/');
        const candidate = parts[parts.length - 1]?.split('?')[0];
        setImportFileName(candidate ? `${candidate}.fig` : 'Figma_Design_Prototype.fig');
      }
    } else if (lower.endsWith('.json') || lower.includes('token') || lower.includes('.json?')) {
      setImportFileType('JSON');
      if (!importFileName || importFileName === 'Untitled_File' || importFileName.endsWith('.json')) {
        setImportFileName('Design_Tokens.json');
      }
    } else if (lower.endsWith('.md') || lower.includes('spec') || lower.includes('readme')) {
      setImportFileType('Markdown');
      if (!importFileName || importFileName === 'Untitled_File' || importFileName.endsWith('.md')) {
        setImportFileName('Design_Specification.md');
      }
    } else if (lower.endsWith('.sketch')) {
      setImportFileType('Sketch');
      if (!importFileName || importFileName === 'Untitled_File' || importFileName.endsWith('.sketch')) {
        setImportFileName('UI_Kit.sketch');
      }
    } else if (lower.endsWith('.csv')) {
      setImportFileType('CSV');
      if (!importFileName || importFileName === 'Untitled_File' || importFileName.endsWith('.csv')) {
        setImportFileName('User_Testing_Feedback.csv');
      }
    } else if (lower.endsWith('.pdf')) {
      setImportFileType('PDF');
      if (!importFileName || importFileName === 'Untitled_File' || importFileName.endsWith('.pdf')) {
        setImportFileName('UX_Research_Report.pdf');
      }
    } else if (lower.endsWith('.zip')) {
      setImportFileType('ZIP');
      if (!importFileName || importFileName === 'Untitled_File' || importFileName.endsWith('.zip')) {
        setImportFileName('Export_Bundle.zip');
      }
    }
  };

  const handleImportFromUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (!importUrl.trim()) return;

    setIsImporting(true);

    setTimeout(() => {
      let hostname = 'remote-url';
      try {
        hostname = new URL(importUrl.trim()).hostname;
      } catch (err) {
        // fallback
      }

      const fileName = importFileName.trim() || `Imported_${importFileType}_File`;
      
      const newFile: ProjectFile = {
        id: `f-url-${Date.now()}`,
        name: fileName,
        type: importFileType,
        size: importFileType === 'Figma' ? '24.8 MB' : importFileType === 'JSON' ? '68 KB' : importFileType === 'Markdown' ? '32 KB' : '4.2 MB',
        date: 'Just now',
        createdBy: `URL Import (${hostname})`,
        sourceUrl: importUrl.trim(),
        contentSnippet: importNotes.trim() || `Linked directly from: ${importUrl.trim()}`
      };

      const newActivity: ProjectActivityItem = {
        id: `act-${Date.now()}`,
        actor: 'You',
        actorType: 'user',
        avatar: 'https://picsum.photos/40/40?random=99',
        action: `imported file "${newFile.name}" from ${hostname}`,
        time: 'Just now',
        details: `Remote URL: ${importUrl.trim()}`
      };

      onUpdateProject({
        ...project,
        files: [newFile, ...project.files],
        recentActivity: [newActivity, ...project.recentActivity]
      });

      setIsImporting(false);
      setIsImportUrlOpen(false);
      setImportUrl('');
      setImportFileName('');
      setImportNotes('');
    }, 500);
  };

  const handleDeleteFile = (fileId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const fileToDelete = project.files.find(f => f.id === fileId);
    if (!fileToDelete) return;
    
    onUpdateProject({
      ...project,
      files: project.files.filter(f => f.id !== fileId),
      recentActivity: [
        {
          id: `act-${Date.now()}`,
          actor: 'You',
          actorType: 'user',
          avatar: 'https://picsum.photos/40/40?random=99',
          action: `removed file "${fileToDelete.name}" from project`,
          time: 'Just now'
        },
        ...project.recentActivity
      ]
    });
  };

  // Activity comment
  const [quickComment, setQuickComment] = useState('');

  const handleAddFile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFileName.trim()) return;

    const file: ProjectFile = {
      id: `f-${Date.now()}`,
      name: newFileName.trim(),
      type: newFileType,
      size: newFileSize || '2.4 MB',
      date: 'Just now',
      createdBy: 'You',
      contentSnippet: newFileSnippet.trim() || undefined
    };

    const newActivity: ProjectActivityItem = {
      id: `act-${Date.now()}`,
      actor: 'You',
      actorType: 'user',
      avatar: 'https://picsum.photos/40/40?random=99',
      action: `uploaded new file "${file.name}"`,
      time: 'Just now'
    };

    onUpdateProject({
      ...project,
      files: [file, ...project.files],
      recentActivity: [newActivity, ...project.recentActivity]
    });

    setIsAddFileOpen(false);
    setNewFileName('');
    setNewFileSnippet('');
  };

  const handleAddMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMemberName.trim()) return;

    const member: ProjectTeamMember = {
      id: `m-${Date.now()}`,
      name: newMemberName.trim(),
      role: newMemberRole,
      email: newMemberEmail.trim() || `${newMemberName.toLowerCase().replace(/\s+/g, '.')}@company.design`,
      avatar: `https://picsum.photos/40/40?random=${project.teamMembers.length + 30}`,
      status: 'Active',
      tasksCount: 2
    };

    const newActivity: ProjectActivityItem = {
      id: `act-${Date.now()}`,
      actor: 'You',
      actorType: 'user',
      avatar: 'https://picsum.photos/40/40?random=99',
      action: `added ${member.name} (${member.role}) to the project team`,
      time: 'Just now'
    };

    onUpdateProject({
      ...project,
      teamMembers: [...project.teamMembers, member],
      recentActivity: [newActivity, ...project.recentActivity]
    });

    setIsAddMemberOpen(false);
    setNewMemberName('');
    setNewMemberEmail('');
  };

  const handleRunAgentForProject = () => {
    setIsExecutingAgent(true);
    setTimeout(() => {
      const chosenAgent = AGENTS.find(a => a.name === selectedAgentName) || AGENTS[0];
      
      const newResult: ProjectAgentResult = {
        id: `res-${Date.now()}`,
        agentName: chosenAgent.name,
        agentIcon: chosenAgent.icon,
        agentBg: chosenAgent.iconBg,
        runDate: 'Just now',
        summary: `Synthesized UX intelligence for ${project.title}. Identified key touchpoint optimizations.`,
        status: 'Completed',
        fullResult: `### AI Agent Deliverable: ${chosenAgent.name}\n**Project:** ${project.title} (${project.category})\n**Run Timestamp:** Just now\n\n#### Prompt Context\n> "${agentPrompt}"\n\n#### Executive Findings\n1. **High Priority Action:** Streamline user navigation pathways to minimize interaction cost.\n2. **Consistency Audit:** Token hierarchy aligns with design system conventions with 0 major regressions.\n3. **Accessibility (WCAG 2.1 AA):** Color contrast ratios verified across mobile and desktop breakpoints.\n\n*Generated by ${chosenAgent.name} using active project specifications.*`
      };

      const newFile: ProjectFile = {
        id: `f-agent-${Date.now()}`,
        name: `${chosenAgent.name.replace(/\s+/g, '_')}_Deliverable.md`,
        type: 'Markdown',
        size: '142 KB',
        date: 'Just now',
        createdBy: `${chosenAgent.name} Agent`,
        isAIGenerated: true,
        contentSnippet: newResult.summary
      };

      const newActivity: ProjectActivityItem = {
        id: `act-${Date.now()}`,
        actor: chosenAgent.name,
        actorType: 'agent',
        icon: chosenAgent.icon,
        action: `generated new UX deliverable "${newFile.name}"`,
        time: 'Just now',
        details: newResult.summary
      };

      onUpdateProject({
        ...project,
        agentResults: [newResult, ...project.agentResults],
        files: [newFile, ...project.files],
        recentActivity: [newActivity, ...project.recentActivity]
      });

      setIsExecutingAgent(false);
      setIsRunAgentOpen(false);
      setSelectedResult(newResult);
    }, 800);
  };

  const handleDeleteAgentResult = (resultId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const resultToDelete = project.agentResults.find(r => r.id === resultId);
    if (!resultToDelete) return;

    onUpdateProject({
      ...project,
      agentResults: project.agentResults.filter(r => r.id !== resultId),
      recentActivity: [
        {
          id: `act-${Date.now()}`,
          actor: 'You',
          actorType: 'user',
          avatar: 'https://picsum.photos/40/40?random=99',
          action: `removed AI deliverable from "${resultToDelete.agentName}"`,
          time: 'Just now'
        },
        ...project.recentActivity
      ]
    });
  };

  const handleUpdateAgentResultStatus = (resultId: string, newStatus: ProjectAgentResult['status'], e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    onUpdateProject({
      ...project,
      agentResults: project.agentResults.map(r => r.id === resultId ? { ...r, status: newStatus } : r)
    });
  };

  const handleCopyResultContent = (result: ProjectAgentResult, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    navigator.clipboard.writeText(result.fullResult || result.summary);
    setCopiedResultId(result.id);
    setTimeout(() => {
      setCopiedResultId(prev => (prev === result.id ? null : prev));
    }, 2000);
  };

  const openAddMilestoneModal = () => {
    setEditingMilestone(null);
    setMilestonePhase(`Phase ${project.timeline.length + 1}`);
    setMilestoneTitle('');
    setMilestoneDescription('');
    setMilestoneStatus('Upcoming');
    setMilestoneStartDate('Next Week');
    setMilestoneDueDate('In 3 Weeks');
    setMilestoneProgress(0);
    setMilestoneDeliverables(['Deliverable Checklist Item 1', 'Deliverable Checklist Item 2']);
    setDeliverableInput('');
    setIsAddMilestoneOpen(true);
  };

  const openEditMilestoneModal = (m: ProjectMilestone) => {
    setEditingMilestone(m);
    setMilestonePhase(m.phase);
    setMilestoneTitle(m.title);
    setMilestoneDescription(m.description);
    setMilestoneStatus(m.status);
    setMilestoneStartDate(m.startDate);
    setMilestoneDueDate(m.dueDate);
    setMilestoneProgress(m.progress);
    setMilestoneDeliverables(m.deliverables || []);
    setDeliverableInput('');
    setIsAddMilestoneOpen(true);
  };

  const handleSaveMilestone = (e: React.FormEvent) => {
    e.preventDefault();
    if (!milestoneTitle.trim()) return;

    let updatedTimeline: ProjectMilestone[];
    const isEdit = Boolean(editingMilestone);

    if (isEdit && editingMilestone) {
      updatedTimeline = project.timeline.map(m => {
        if (m.id === editingMilestone.id) {
          return {
            ...m,
            phase: milestonePhase.trim() || m.phase,
            title: milestoneTitle.trim(),
            description: milestoneDescription.trim() || 'Custom milestone objectives and deliverables.',
            status: milestoneStatus,
            startDate: milestoneStartDate.trim() || m.startDate,
            dueDate: milestoneDueDate.trim() || m.dueDate,
            progress: milestoneProgress,
            deliverables: milestoneDeliverables.length > 0 ? milestoneDeliverables : ['Final Review']
          };
        }
        return m;
      });
    } else {
      const newMilestone: ProjectMilestone = {
        id: `t-${Date.now()}`,
        phase: milestonePhase.trim() || `Phase ${project.timeline.length + 1}`,
        title: milestoneTitle.trim(),
        description: milestoneDescription.trim() || 'Custom milestone objectives and deliverables.',
        status: milestoneStatus,
        startDate: milestoneStartDate.trim() || 'Upcoming',
        dueDate: milestoneDueDate.trim() || 'TBD',
        progress: milestoneProgress,
        deliverables: milestoneDeliverables.length > 0 ? milestoneDeliverables : ['Initial Spec Review'],
        completedDeliverables: milestoneProgress === 100 ? (milestoneDeliverables.length > 0 ? milestoneDeliverables : ['Initial Spec Review']) : []
      };
      updatedTimeline = [...project.timeline, newMilestone];
    }

    // Recalculate overall project progress
    const totalProgress = updatedTimeline.reduce((acc, curr) => acc + curr.progress, 0);
    const avgProgress = updatedTimeline.length > 0 ? Math.round(totalProgress / updatedTimeline.length) : project.progress;

    const newActivity: ProjectActivityItem = {
      id: `act-${Date.now()}`,
      actor: 'You',
      actorType: 'user',
      avatar: 'https://picsum.photos/40/40?random=99',
      action: isEdit 
        ? `updated timeline milestone "${milestoneTitle.trim()}"` 
        : `created new timeline milestone "${milestoneTitle.trim()}" (${milestonePhase})`,
      time: 'Just now',
      details: `${milestoneDeliverables.length} deliverables assigned • Due: ${milestoneDueDate.trim()}`
    };

    onUpdateProject({
      ...project,
      progress: avgProgress,
      timeline: updatedTimeline,
      recentActivity: [newActivity, ...project.recentActivity]
    });

    setIsAddMilestoneOpen(false);
  };

  const handleDeleteMilestone = (milestoneId: string) => {
    const target = project.timeline.find(m => m.id === milestoneId);
    if (!target) return;
    if (window.confirm(`Are you sure you want to remove milestone "${target.title}"?`)) {
      const updatedTimeline = project.timeline.filter(m => m.id !== milestoneId);
      const totalProgress = updatedTimeline.reduce((acc, curr) => acc + curr.progress, 0);
      const avgProgress = updatedTimeline.length > 0 ? Math.round(totalProgress / updatedTimeline.length) : 0;

      onUpdateProject({
        ...project,
        progress: avgProgress,
        timeline: updatedTimeline,
        recentActivity: [
          {
            id: `act-${Date.now()}`,
            actor: 'You',
            actorType: 'user',
            avatar: 'https://picsum.photos/40/40?random=99',
            action: `removed milestone "${target.title}" from timeline`,
            time: 'Just now'
          },
          ...project.recentActivity
        ]
      });
    }
  };

  const handleToggleDeliverable = (milestoneId: string, deliverableIndexOrText: number | string) => {
    const updatedTimeline = project.timeline.map(m => {
      if (m.id === milestoneId) {
        let deliverableText = typeof deliverableIndexOrText === 'string' 
          ? deliverableIndexOrText 
          : m.deliverables[deliverableIndexOrText];
        
        const currentCompleted = m.completedDeliverables || (m.progress >= 100 ? [...m.deliverables] : []);
        const isCompleted = currentCompleted.includes(deliverableText);
        const newCompleted = isCompleted 
          ? currentCompleted.filter(d => d !== deliverableText)
          : [...currentCompleted, deliverableText];

        const totalDelivs = m.deliverables.length || 1;
        const newProgress = Math.round((newCompleted.length / totalDelivs) * 100);
        const newStatus: ProjectMilestone['status'] = 
          newProgress === 100 ? 'Completed' : newProgress > 0 ? 'In Progress' : 'Upcoming';

        return {
          ...m,
          completedDeliverables: newCompleted,
          progress: newProgress,
          status: newStatus
        };
      }
      return m;
    });

    const totalProgress = updatedTimeline.reduce((acc, curr) => acc + curr.progress, 0);
    const avgProgress = updatedTimeline.length > 0 ? Math.round(totalProgress / updatedTimeline.length) : project.progress;

    onUpdateProject({
      ...project,
      progress: avgProgress,
      timeline: updatedTimeline
    });
  };

  const handleAddDeliverableToMilestone = (milestoneId: string) => {
    const text = quickDeliverableInputs[milestoneId]?.trim();
    if (!text) return;

    const updatedTimeline = project.timeline.map(m => {
      if (m.id === milestoneId) {
        const deliverables = [...(m.deliverables || []), text];
        return {
          ...m,
          deliverables
        };
      }
      return m;
    });

    onUpdateProject({
      ...project,
      timeline: updatedTimeline
    });

    setQuickDeliverableInputs({
      ...quickDeliverableInputs,
      [milestoneId]: ''
    });
  };

  const handleUpdateMilestoneStatus = (milestoneId: string, newStatus: ProjectMilestone['status']) => {
    const updatedTimeline = project.timeline.map(m => {
      if (m.id === milestoneId) {
        const newProgress = newStatus === 'Completed' ? 100 : newStatus === 'Upcoming' ? 0 : (m.progress || 50);
        const newCompleted = newStatus === 'Completed' ? [...m.deliverables] : newStatus === 'Upcoming' ? [] : (m.completedDeliverables || []);
        return {
          ...m,
          status: newStatus,
          progress: newProgress,
          completedDeliverables: newCompleted
        };
      }
      return m;
    });

    const totalProgress = updatedTimeline.reduce((acc, curr) => acc + curr.progress, 0);
    const avgProgress = updatedTimeline.length > 0 ? Math.round(totalProgress / updatedTimeline.length) : project.progress;

    onUpdateProject({
      ...project,
      progress: avgProgress,
      timeline: updatedTimeline
    });
  };

  const handleAddQuickComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickComment.trim()) return;

    const newActivity: ProjectActivityItem = {
      id: `act-${Date.now()}`,
      actor: 'You',
      actorType: 'user',
      avatar: 'https://picsum.photos/40/40?random=99',
      action: quickComment.trim(),
      time: 'Just now'
    };

    onUpdateProject({
      ...project,
      recentActivity: [newActivity, ...project.recentActivity]
    });
    setQuickComment('');
  };

  const getFileIcon = (type: ProjectFile['type']) => {
    switch (type) {
      case 'Figma': return 'fa-brands fa-figma text-purple-600 bg-purple-50';
      case 'Sketch': return 'fa-solid fa-gem text-amber-500 bg-amber-50';
      case 'Markdown': return 'fa-solid fa-file-lines text-blue-600 bg-blue-50';
      case 'JSON': return 'fa-solid fa-code text-emerald-600 bg-emerald-50';
      case 'ZIP': return 'fa-solid fa-file-zipper text-indigo-600 bg-indigo-50';
      case 'CSV': return 'fa-solid fa-table text-teal-600 bg-teal-50';
      case 'PDF': return 'fa-solid fa-file-pdf text-rose-600 bg-rose-50';
      default: return 'fa-solid fa-file text-gray-500 bg-gray-50';
    }
  };

  return (
    <div className="animate-in fade-in slide-in-from-right-8 duration-500 pb-12">
      {/* Header Navigation */}
      <div className="flex items-center justify-between mb-6">
        <button 
          onClick={onBack} 
          className="flex items-center text-sm font-semibold text-gray-600 hover:text-indigo-600 transition-colors bg-white px-3.5 py-2 rounded-xl border border-gray-200 shadow-sm"
        >
          <i className="fa-solid fa-arrow-left mr-2 text-xs"></i>
          Back to All Projects
        </button>

        <div className="flex items-center gap-2.5">
          <button 
            onClick={() => setIsRunAgentOpen(true)}
            className="px-3.5 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white rounded-xl text-xs font-semibold flex items-center shadow-md shadow-indigo-200 transition-all hover:scale-[1.02]"
          >
            <i className="fa-solid fa-robot mr-1.5"></i>
            Run AI Agent
          </button>
          <button 
            onClick={() => setIsImportUrlOpen(true)}
            className="px-3.5 py-2 bg-white hover:bg-gray-50 text-indigo-700 border border-indigo-200 rounded-xl text-xs font-semibold flex items-center shadow-sm transition-colors"
          >
            <i className="fa-solid fa-link mr-1.5 text-indigo-600"></i>
            Import from URL
          </button>
          <button 
            onClick={() => setIsAddFileOpen(true)}
            className="px-3.5 py-2 bg-white hover:bg-gray-50 text-gray-700 border border-gray-200 rounded-xl text-xs font-semibold flex items-center shadow-sm transition-colors"
          >
            <i className="fa-solid fa-cloud-arrow-up mr-1.5 text-indigo-600"></i>
            Add File
          </button>
          <button 
            onClick={openAddMilestoneModal}
            className="px-3.5 py-2 bg-white hover:bg-gray-50 text-emerald-700 border border-emerald-200 rounded-xl text-xs font-semibold flex items-center shadow-sm transition-colors"
          >
            <i className="fa-solid fa-timeline mr-1.5 text-emerald-600"></i>
            Add Milestone
          </button>
          <button 
            onClick={() => setIsAddMemberOpen(true)}
            className="px-3.5 py-2 bg-white hover:bg-gray-50 text-gray-700 border border-gray-200 rounded-xl text-xs font-semibold flex items-center shadow-sm transition-colors"
          >
            <i className="fa-solid fa-user-plus mr-1.5 text-purple-600"></i>
            Add Member
          </button>
        </div>
      </div>

      {/* Project Banner Card */}
      <div className="bg-white rounded-2xl border border-gray-200 p-6 md:p-8 mb-6 shadow-sm relative overflow-hidden">
        <div className={`absolute top-0 left-0 w-full h-2.5 ${project.color}`}></div>
        
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
          <div className="max-w-2xl">
            <div className="flex flex-wrap items-center gap-2.5 mb-2">
              <h1 className="text-2xl md:text-3xl font-extrabold text-gray-900 tracking-tight">{project.title}</h1>
              <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                project.status === 'Completed' ? 'bg-green-100 text-green-700' :
                project.status === 'Review' ? 'bg-purple-100 text-purple-700' :
                project.status === 'Planning' ? 'bg-amber-100 text-amber-700' :
                'bg-blue-100 text-blue-700'
              }`}>
                {project.status}
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-gray-100 text-gray-700">
                {project.category}
              </span>
            </div>
            <p className="text-sm text-gray-600 leading-relaxed mb-3">{project.description}</p>
            <div className="flex flex-wrap items-center gap-4 text-xs text-gray-400 font-medium">
              <span><i className="fa-solid fa-clock mr-1"></i> {project.date}</span>
              <span>•</span>
              <span><i className="fa-solid fa-layer-group mr-1"></i> {project.screensCount} Screens</span>
              <span>•</span>
              <span><i className="fa-solid fa-cubes mr-1"></i> {project.componentsCount} Components</span>
            </div>
          </div>

          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 w-full lg:w-auto">
            <div 
              onClick={() => setActiveTab('files')}
              className="p-3 bg-gray-50 hover:bg-indigo-50/60 rounded-xl border border-gray-100 text-center cursor-pointer transition-colors"
            >
              <div className="text-lg font-bold text-gray-900">{project.files.length}</div>
              <div className="text-[11px] text-gray-500 font-medium flex items-center justify-center gap-1">
                <i className="fa-solid fa-folder text-indigo-600 text-xs"></i> Files
              </div>
            </div>

            <div 
              onClick={() => setActiveTab('agents')}
              className="p-3 bg-gray-50 hover:bg-purple-50/60 rounded-xl border border-gray-100 text-center cursor-pointer transition-colors"
            >
              <div className="text-lg font-bold text-gray-900">{project.agentResults.length}</div>
              <div className="text-[11px] text-gray-500 font-medium flex items-center justify-center gap-1">
                <i className="fa-solid fa-robot text-purple-600 text-xs"></i> AI Runs
              </div>
            </div>

            <div 
              onClick={() => setActiveTab('team')}
              className="p-3 bg-gray-50 hover:bg-blue-50/60 rounded-xl border border-gray-100 text-center cursor-pointer transition-colors"
            >
              <div className="text-lg font-bold text-gray-900">{project.teamMembers.length}</div>
              <div className="text-[11px] text-gray-500 font-medium flex items-center justify-center gap-1">
                <i className="fa-solid fa-users text-blue-600 text-xs"></i> Team
              </div>
            </div>

            <div 
              onClick={() => setActiveTab('timeline')}
              className="p-3 bg-gray-50 hover:bg-emerald-50/60 rounded-xl border border-gray-100 text-center cursor-pointer transition-colors"
            >
              <div className="text-lg font-bold text-indigo-600">{project.progress}%</div>
              <div className="text-[11px] text-gray-500 font-medium flex items-center justify-center gap-1">
                <i className="fa-solid fa-timeline text-emerald-600 text-xs"></i> Progress
              </div>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center overflow-x-auto scrollbar-hide border-t border-gray-100 mt-6 pt-4 gap-2">
          {[
            { id: 'overview', label: 'Overview', icon: 'fa-chart-pie', badge: null },
            { id: 'files', label: 'Created Files', icon: 'fa-folder', badge: project.files.length },
            { id: 'agents', label: 'AI Agents & Results', icon: 'fa-robot', badge: project.agentResults.length },
            { id: 'timeline', label: 'Timeline & Milestones', icon: 'fa-timeline', badge: project.timeline.length },
            { id: 'team', label: 'Team Members', icon: 'fa-users', badge: project.teamMembers.length },
            { id: 'activity', label: 'Recent Activity', icon: 'fa-clock-rotate-left', badge: project.recentActivity.length }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap flex items-center gap-2 ${
                activeTab === tab.id
                  ? 'bg-gray-900 text-white shadow-md'
                  : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
              }`}
            >
              <i className={`fa-solid ${tab.icon} text-xs`}></i>
              {tab.label}
              {tab.badge !== null && (
                <span className={`px-1.5 py-0.2 rounded-full text-[10px] ${
                  activeTab === tab.id ? 'bg-white/20 text-white' : 'bg-gray-200 text-gray-700'
                }`}>
                  {tab.badge}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* TAB 1: OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-in fade-in">
          {/* Main 2-column content */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* Created Files Section */}
            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  <h3 className="text-base font-bold text-gray-900">Created Files</h3>
                  <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-gray-100 text-gray-700">
                    {project.files.length}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => setIsImportUrlOpen(true)}
                    className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold hover:underline flex items-center"
                  >
                    <i className="fa-solid fa-link mr-1"></i> Import URL
                  </button>
                  <span className="text-gray-300">|</span>
                  <button 
                    onClick={() => setIsAddFileOpen(true)}
                    className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold hover:underline flex items-center"
                  >
                    <i className="fa-solid fa-plus mr-1"></i> Add File
                  </button>
                  <span className="text-gray-300">|</span>
                  <button 
                    onClick={() => setActiveTab('files')}
                    className="text-xs text-gray-500 hover:text-gray-800 font-semibold hover:underline"
                  >
                    View All
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {project.files.slice(0, 4).map(file => (
                  <div 
                    key={file.id}
                    onClick={() => setSelectedFile(file)}
                    className="p-3.5 rounded-xl border border-gray-200 hover:border-indigo-300 hover:shadow-md transition-all cursor-pointer bg-white group"
                  >
                    <div className="flex items-start space-x-3">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 text-base ${getFileIcon(file.type)}`}>
                        <i className={`fa-solid ${getFileIcon(file.type).split(' ')[0]}`}></i>
                      </div>
                      <div className="flex-grow min-w-0">
                        <div className="flex items-center justify-between">
                          <h4 className="text-xs font-bold text-gray-900 truncate group-hover:text-indigo-600 transition-colors" title={file.name}>
                            {file.name}
                          </h4>
                          {file.isAIGenerated && (
                            <span className="px-1.5 py-0.5 bg-purple-50 text-purple-700 rounded text-[9px] font-bold flex-shrink-0 ml-1">
                              AI
                            </span>
                          )}
                        </div>
                        <div className="flex items-center justify-between mt-1 text-[11px] text-gray-400">
                          <span>{file.size}</span>
                          <span>{file.date}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* AI Agents & Results Section */}
            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  <h3 className="text-base font-bold text-gray-900">AI Agents & Results</h3>
                  <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-purple-50 text-purple-700">
                    {project.agentResults.length} Deliverables
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => setIsRunAgentOpen(true)}
                    className="text-xs text-purple-600 hover:text-purple-800 font-semibold hover:underline flex items-center"
                  >
                    <i className="fa-solid fa-play mr-1 text-[10px]"></i> Run Agent
                  </button>
                  <span className="text-gray-300">|</span>
                  <button 
                    onClick={() => setActiveTab('agents')}
                    className="text-xs text-gray-500 hover:text-gray-800 font-semibold hover:underline"
                  >
                    View All
                  </button>
                </div>
              </div>

              <div className="space-y-3">
                {project.agentResults.map(result => (
                  <div 
                    key={result.id}
                    className="p-4 rounded-xl border border-gray-100 hover:border-purple-200 bg-gray-50/50 hover:bg-purple-50/20 transition-all flex flex-col md:flex-row justify-between items-start md:items-center gap-3"
                  >
                    <div className="flex items-start space-x-3.5">
                      <div className={`w-10 h-10 ${result.agentBg} rounded-xl flex items-center justify-center flex-shrink-0 shadow-sm text-white`}>
                        <i className={`fa-solid ${result.agentIcon} text-sm`}></i>
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-bold text-gray-900">{result.agentName}</h4>
                          <span className="px-2 py-0.5 text-[10px] font-semibold rounded-full bg-green-100 text-green-700">
                            {result.status}
                          </span>
                        </div>
                        <p className="text-xs text-gray-600 mt-1 line-clamp-1">{result.summary}</p>
                        <span className="text-[10px] text-gray-400 mt-0.5 inline-block">Executed {result.runDate}</span>
                      </div>
                    </div>

                    <button 
                      onClick={() => setSelectedResult(result)}
                      className="px-3 py-1.5 bg-white border border-gray-200 hover:border-purple-300 hover:text-purple-600 text-gray-700 rounded-lg text-xs font-semibold transition-all flex items-center self-end md:self-center shadow-sm"
                    >
                      <i className="fa-solid fa-file-invoice mr-1.5 text-xs text-purple-600"></i>
                      View Deliverable
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Timeline Roadmap Preview */}
            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  <h3 className="text-base font-bold text-gray-900">Project Timeline</h3>
                  <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700">
                    {project.timeline.filter(t => t.status === 'Completed').length} of {project.timeline.length} Milestones Done
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={openAddMilestoneModal}
                    className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold hover:underline flex items-center"
                  >
                    <i className="fa-solid fa-plus mr-1"></i> Add Milestone
                  </button>
                  <span className="text-gray-300">|</span>
                  <button 
                    onClick={() => setActiveTab('timeline')}
                    className="text-xs text-gray-500 hover:text-gray-800 font-semibold hover:underline"
                  >
                    Manage
                  </button>
                </div>
              </div>

              <div className="space-y-4">
                {project.timeline.slice(0, 3).map((milestone, idx) => (
                  <div key={milestone.id} className="p-3.5 bg-gray-50 rounded-xl border border-gray-100">
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="flex items-center space-x-2">
                        <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">{milestone.phase}</span>
                        <h4 className="text-xs font-bold text-gray-900">{milestone.title}</h4>
                      </div>
                      <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                        milestone.status === 'Completed' ? 'bg-green-100 text-green-700' :
                        milestone.status === 'In Progress' ? 'bg-blue-100 text-blue-700' :
                        'bg-gray-100 text-gray-600'
                      }`}>
                        {milestone.status}
                      </span>
                    </div>
                    
                    <div className="w-full bg-gray-200 rounded-full h-1.5 my-2 overflow-hidden">
                      <div 
                        className={`h-1.5 rounded-full transition-all duration-500 ${
                          milestone.status === 'Completed' ? 'bg-green-500' : 'bg-indigo-600'
                        }`} 
                        style={{ width: `${milestone.progress}%` }}
                      ></div>
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-gray-500">
                      <span>Due: {milestone.dueDate}</span>
                      <span>{milestone.deliverables.length} Deliverables</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>

          {/* Sidebar Column: Team & Activity */}
          <div className="space-y-6">
            
            {/* Team Members Card */}
            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-base font-bold text-gray-900">Team Members ({project.teamMembers.length})</h3>
                <button 
                  onClick={() => setIsAddMemberOpen(true)}
                  className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold hover:underline flex items-center"
                >
                  <i className="fa-solid fa-plus mr-1"></i> Add
                </button>
              </div>

              <div className="space-y-3">
                {project.teamMembers.map(member => (
                  <div key={member.id} className="flex items-center justify-between p-2 rounded-xl hover:bg-gray-50 transition-colors">
                    <div className="flex items-center space-x-3">
                      <div className="relative">
                        <img src={member.avatar} alt={member.name} className="w-9 h-9 rounded-full object-cover border border-gray-200" />
                        <span className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full border-2 border-white ${
                          member.status === 'Active' ? 'bg-green-500' :
                          member.status === 'In Meeting' ? 'bg-amber-500' : 'bg-gray-400'
                        }`}></span>
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-gray-900">{member.name}</h4>
                        <p className="text-[11px] text-gray-500">{member.role}</p>
                      </div>
                    </div>
                    <span className="text-[10px] font-semibold text-gray-400 bg-gray-100 px-2 py-0.5 rounded-md">
                      {member.tasksCount} tasks
                    </span>
                  </div>
                ))}
              </div>

              <button 
                onClick={() => setActiveTab('team')}
                className="w-full mt-4 py-2 text-xs font-semibold text-gray-700 bg-gray-50 hover:bg-gray-100 rounded-xl transition-colors border border-gray-200"
              >
                View Full Team Directory
              </button>
            </div>

            {/* Recent Activity Card */}
            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-base font-bold text-gray-900">Recent Activity</h3>
                <button 
                  onClick={() => setActiveTab('activity')}
                  className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold hover:underline"
                >
                  View All
                </button>
              </div>

              <div className="space-y-4">
                {project.recentActivity.slice(0, 4).map((activity, i) => (
                  <div key={activity.id} className="flex gap-3 text-xs">
                    {activity.actorType === 'agent' ? (
                      <div className="w-7 h-7 rounded-lg bg-purple-100 text-purple-600 flex items-center justify-center flex-shrink-0 text-xs">
                        <i className={`fa-solid ${activity.icon || 'fa-robot'}`}></i>
                      </div>
                    ) : (
                      <img src={activity.avatar || 'https://picsum.photos/40/40'} className="w-7 h-7 rounded-full object-cover flex-shrink-0" alt={activity.actor} />
                    )}
                    <div className="flex-grow">
                      <p className="text-gray-800 leading-tight">
                        <strong className="text-gray-900">{activity.actor}</strong> {activity.action}
                      </p>
                      <span className="text-[10px] text-gray-400 mt-0.5 block">{activity.time}</span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Quick Comment Box */}
              <form onSubmit={handleAddQuickComment} className="mt-4 pt-3 border-t border-gray-100 flex gap-2">
                <input 
                  type="text" 
                  value={quickComment}
                  onChange={(e) => setQuickComment(e.target.value)}
                  placeholder="Post team note or status update..."
                  className="w-full px-3 py-1.5 text-xs bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                <button type="submit" className="p-1.5 bg-indigo-600 text-white rounded-lg text-xs hover:bg-indigo-700">
                  <i className="fa-solid fa-paper-plane"></i>
                </button>
              </form>
            </div>

          </div>
        </div>
      )}

      {/* TAB 2: CREATED FILES */}
      {activeTab === 'files' && (() => {
        const filteredAndSortedFiles = project.files.filter(file => {
          if (fileSearch.trim()) {
            const q = fileSearch.toLowerCase();
            const matchName = file.name.toLowerCase().includes(q);
            const matchSnippet = file.contentSnippet?.toLowerCase().includes(q);
            const matchCreator = file.createdBy.toLowerCase().includes(q);
            if (!matchName && !matchSnippet && !matchCreator) return false;
          }

          if (fileTypeFilter !== 'All' && file.type !== fileTypeFilter) {
            return false;
          }

          if (fileSourceFilter === 'AI' && !file.isAIGenerated) {
            return false;
          }
          if (fileSourceFilter === 'Manual' && (file.isAIGenerated || file.sourceUrl)) {
            return false;
          }
          if (fileSourceFilter === 'URL' && !file.sourceUrl) {
            return false;
          }

          return true;
        }).sort((a, b) => {
          if (fileSortBy === 'name-asc') {
            return a.name.localeCompare(b.name);
          }
          if (fileSortBy === 'size-desc') {
            const parseSize = (s: string) => {
              const num = parseFloat(s) || 0;
              if (s.toLowerCase().includes('gb')) return num * 1024 * 1024;
              if (s.toLowerCase().includes('mb')) return num * 1024;
              return num;
            };
            return parseSize(b.size) - parseSize(a.size);
          }
          if (fileSortBy === 'date-asc') {
            return a.id.localeCompare(b.id);
          }
          return b.id.localeCompare(a.id);
        });

        const isFiltered = Boolean(fileSearch || fileTypeFilter !== 'All' || fileSourceFilter !== 'All');

        return (
          <div className="space-y-5 animate-in fade-in">
            {/* Top Action Bar */}
            <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 bg-white p-5 rounded-2xl border border-gray-200 shadow-sm">
              <div>
                <div className="flex items-center gap-2.5">
                  <h3 className="text-lg font-bold text-gray-900">Created Files & Artifacts</h3>
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-50 text-indigo-700">
                    {project.files.length} total
                  </span>
                </div>
                <p className="text-xs text-gray-500 mt-1">Design specs, code tokens, export bundles, and documentation generated for {project.title}.</p>
              </div>

              <div className="flex flex-wrap items-center gap-2.5 w-full lg:w-auto">
                <button 
                  onClick={() => setIsRunAgentOpen(true)}
                  className="px-3.5 py-2 bg-purple-50 text-purple-700 hover:bg-purple-100 border border-purple-200 rounded-xl text-xs font-semibold flex items-center shadow-xs transition-colors"
                >
                  <i className="fa-solid fa-wand-magic-sparkles mr-1.5"></i>
                  Generate with AI
                </button>
                <button 
                  id="import-from-url-btn"
                  onClick={() => setIsImportUrlOpen(true)}
                  className="px-3.5 py-2 bg-white text-indigo-700 hover:bg-indigo-50/70 border border-indigo-200 rounded-xl text-xs font-semibold flex items-center shadow-xs transition-colors"
                >
                  <i className="fa-solid fa-link mr-1.5 text-indigo-600"></i>
                  Import from URL
                </button>
                <button 
                  onClick={() => setIsAddFileOpen(true)}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold flex items-center shadow-md shadow-indigo-100 transition-all"
                >
                  <i className="fa-solid fa-plus mr-1.5"></i>
                  Upload File
                </button>
              </div>
            </div>

            {/* Filter and View Mode Controls Toolbar */}
            <div className="bg-white p-4 rounded-2xl border border-gray-200 shadow-sm space-y-3">
              <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
                {/* Search Bar */}
                <div className="relative flex-1 max-w-md">
                  <input 
                    type="text" 
                    placeholder="Search files by name, type, author, or notes..." 
                    value={fileSearch}
                    onChange={(e) => setFileSearch(e.target.value)}
                    className="w-full pl-9 pr-8 py-2 bg-gray-50 border border-gray-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                  />
                  <i className="fa-solid fa-search absolute left-3 top-2.5 text-gray-400 text-xs"></i>
                  {fileSearch && (
                    <button onClick={() => setFileSearch('')} className="absolute right-2.5 top-2 text-gray-400 hover:text-gray-600 text-xs">
                      <i className="fa-solid fa-times"></i>
                    </button>
                  )}
                </div>

                {/* Filter and Sort Dropdowns */}
                <div className="flex flex-wrap items-center gap-2">
                  {/* File Type Filter */}
                  <select 
                    value={fileTypeFilter}
                    onChange={(e) => setFileTypeFilter(e.target.value as any)}
                    className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-xs font-medium text-gray-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="All">All Types</option>
                    <option value="Figma">Figma (.fig)</option>
                    <option value="Sketch">Sketch (.sketch)</option>
                    <option value="Markdown">Markdown (.md)</option>
                    <option value="JSON">Tokens (.json)</option>
                    <option value="ZIP">Archive (.zip)</option>
                    <option value="CSV">Matrix (.csv)</option>
                    <option value="PDF">Report (.pdf)</option>
                    <option value="Wireframe">Wireframe</option>
                  </select>

                  {/* Source Filter */}
                  <select 
                    value={fileSourceFilter}
                    onChange={(e) => setFileSourceFilter(e.target.value as any)}
                    className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-xs font-medium text-gray-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="All">All Sources</option>
                    <option value="AI">AI Generated</option>
                    <option value="Manual">Team Uploads</option>
                    <option value="URL">Imported via URL</option>
                  </select>

                  {/* Sort Order */}
                  <select 
                    value={fileSortBy}
                    onChange={(e) => setFileSortBy(e.target.value as any)}
                    className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-xs font-medium text-gray-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="date-desc">Newest First</option>
                    <option value="date-asc">Oldest First</option>
                    <option value="name-asc">Name (A-Z)</option>
                    <option value="size-desc">Size (Largest)</option>
                  </select>

                  {/* View Mode Toggle (Grid vs List) */}
                  <div className="flex items-center bg-gray-100 p-0.5 rounded-xl border border-gray-200">
                    <button 
                      onClick={() => setFileViewMode('grid')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                        fileViewMode === 'grid' 
                          ? 'bg-white text-gray-900 shadow-xs' 
                          : 'text-gray-500 hover:text-gray-900'
                      }`}
                      title="Grid View"
                    >
                      <i className="fa-solid fa-table-cells-large text-xs"></i>
                      <span className="hidden sm:inline">Grid</span>
                    </button>
                    <button 
                      onClick={() => setFileViewMode('list')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                        fileViewMode === 'list' 
                          ? 'bg-white text-gray-900 shadow-xs' 
                          : 'text-gray-500 hover:text-gray-900'
                      }`}
                      title="List View"
                    >
                      <i className="fa-solid fa-list text-xs"></i>
                      <span className="hidden sm:inline">List</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Status bar: Counts and Clear button */}
              <div className="flex items-center justify-between text-xs text-gray-500 pt-1 border-t border-gray-100">
                <div className="flex items-center gap-2">
                  <span>Showing <strong>{filteredAndSortedFiles.length}</strong> of {project.files.length} files</span>
                  {isFiltered && (
                    <span className="text-indigo-600 font-medium">(Filtered)</span>
                  )}
                </div>

                {isFiltered && (
                  <button 
                    onClick={() => {
                      setFileSearch('');
                      setFileTypeFilter('All');
                      setFileSourceFilter('All');
                      setFileSortBy('date-desc');
                    }}
                    className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold hover:underline flex items-center gap-1"
                  >
                    <i className="fa-solid fa-rotate-left text-[10px]"></i>
                    Reset Filters
                  </button>
                )}
              </div>
            </div>

            {/* Empty State */}
            {filteredAndSortedFiles.length === 0 ? (
              <div className="bg-white rounded-2xl border border-gray-200 p-12 text-center shadow-sm">
                <div className="w-14 h-14 rounded-2xl bg-gray-100 text-gray-400 flex items-center justify-center mx-auto mb-3">
                  <i className="fa-solid fa-folder-open text-2xl"></i>
                </div>
                <h4 className="text-base font-bold text-gray-900 mb-1">No files match your filters</h4>
                <p className="text-xs text-gray-500 max-w-sm mx-auto mb-4">Try clearing your search query or reset type filters to see all project deliverables.</p>
                <div className="flex items-center justify-center gap-2">
                  <button 
                    onClick={() => {
                      setFileSearch('');
                      setFileTypeFilter('All');
                      setFileSourceFilter('All');
                    }}
                    className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-xs font-semibold transition-colors"
                  >
                    Clear All Filters
                  </button>
                  <button 
                    onClick={() => setIsImportUrlOpen(true)}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-colors"
                  >
                    <i className="fa-solid fa-link mr-1.5"></i>
                    Import from URL
                  </button>
                </div>
              </div>
            ) : fileViewMode === 'list' ? (
              /* --- LIST VIEW --- */
              <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-sm">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-gray-50/80 border-b border-gray-200 text-[11px] font-bold text-gray-500 uppercase tracking-wider">
                        <th className="py-3.5 px-4">File Name & Details</th>
                        <th className="py-3.5 px-4">Type</th>
                        <th className="py-3.5 px-4">Size</th>
                        <th className="py-3.5 px-4">Origin / Creator</th>
                        <th className="py-3.5 px-4">Date</th>
                        <th className="py-3.5 px-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100 text-xs text-gray-700">
                      {filteredAndSortedFiles.map((file) => (
                        <tr 
                          key={file.id}
                          className="hover:bg-indigo-50/20 transition-colors group cursor-pointer"
                          onClick={() => setSelectedFile(file)}
                        >
                          <td className="py-3.5 px-4">
                            <div className="flex items-center space-x-3">
                              <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 text-sm shadow-2xs ${getFileIcon(file.type)}`}>
                                <i className={`fa-solid ${getFileIcon(file.type).split(' ')[0]}`}></i>
                              </div>
                              <div className="min-w-0 max-w-xs sm:max-w-md">
                                <div className="flex items-center gap-2">
                                  <span className="font-bold text-gray-900 group-hover:text-indigo-600 transition-colors truncate" title={file.name}>
                                    {file.name}
                                  </span>
                                  {file.sourceUrl && (
                                    <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-blue-100 text-blue-700 flex items-center gap-1" title={file.sourceUrl}>
                                      <i className="fa-solid fa-link text-[8px]"></i>
                                      URL
                                    </span>
                                  )}
                                </div>
                                {file.contentSnippet && (
                                  <p className="text-[11px] text-gray-400 truncate max-w-sm mt-0.5 font-mono">
                                    {file.contentSnippet}
                                  </p>
                                )}
                              </div>
                            </div>
                          </td>

                          <td className="py-3.5 px-4">
                            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-gray-100 text-gray-700">
                              {file.type}
                            </span>
                          </td>

                          <td className="py-3.5 px-4 font-mono text-gray-600 text-[11px]">
                            {file.size}
                          </td>

                          <td className="py-3.5 px-4">
                            {file.isAIGenerated ? (
                              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-purple-100 text-purple-700 flex items-center gap-1 w-fit">
                                <i className="fa-solid fa-wand-magic-sparkles text-[9px]"></i>
                                AI Generated
                              </span>
                            ) : file.sourceUrl ? (
                              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-medium bg-blue-50 text-blue-700 flex items-center gap-1 w-fit">
                                <i className="fa-solid fa-globe text-[9px]"></i>
                                {file.createdBy}
                              </span>
                            ) : (
                              <span className="text-gray-600 text-xs">
                                {file.createdBy}
                              </span>
                            )}
                          </td>

                          <td className="py-3.5 px-4 text-gray-500 whitespace-nowrap text-[11px]">
                            {file.date}
                          </td>

                          <td className="py-3.5 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                            <div className="flex items-center justify-end space-x-1.5">
                              <button 
                                onClick={() => setSelectedFile(file)}
                                className="p-1.5 hover:bg-gray-100 rounded-lg text-gray-500 hover:text-indigo-600 transition-colors"
                                title="Inspect Snippet"
                              >
                                <i className="fa-solid fa-eye text-xs"></i>
                              </button>
                              
                              {file.sourceUrl && (
                                <button 
                                  onClick={() => {
                                    navigator.clipboard.writeText(file.sourceUrl!);
                                    alert(`Copied URL for ${file.name} to clipboard!\n${file.sourceUrl}`);
                                  }}
                                  className="p-1.5 hover:bg-gray-100 rounded-lg text-gray-500 hover:text-blue-600 transition-colors"
                                  title="Copy Source URL"
                                >
                                  <i className="fa-solid fa-link text-xs"></i>
                                </button>
                              )}

                              <button 
                                onClick={() => alert(`Downloading ${file.name}...`)}
                                className="p-1.5 hover:bg-gray-100 rounded-lg text-gray-500 hover:text-indigo-600 transition-colors"
                                title="Download File"
                              >
                                <i className="fa-solid fa-download text-xs"></i>
                              </button>

                              <button 
                                onClick={(e) => handleDeleteFile(file.id, e)}
                                className="p-1.5 hover:bg-rose-50 rounded-lg text-gray-400 hover:text-rose-600 transition-colors"
                                title="Remove File"
                              >
                                <i className="fa-solid fa-trash text-xs"></i>
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : (
              /* --- GRID VIEW --- */
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredAndSortedFiles.map(file => (
                  <div 
                    key={file.id} 
                    className="bg-white rounded-2xl border border-gray-200 p-5 hover:border-indigo-300 hover:shadow-md transition-all flex flex-col justify-between group"
                  >
                    <div>
                      <div className="flex items-start justify-between mb-3">
                        <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-xl shadow-sm ${getFileIcon(file.type)}`}>
                          <i className={`fa-solid ${getFileIcon(file.type).split(' ')[0]}`}></i>
                        </div>
                        <div className="flex items-center space-x-1">
                          {file.isAIGenerated && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-100 text-purple-700">
                              AI Generated
                            </span>
                          )}
                          {file.sourceUrl && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-700 flex items-center gap-1">
                              <i className="fa-solid fa-link text-[8px]"></i>
                              URL
                            </span>
                          )}
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-gray-100 text-gray-700">
                            {file.type}
                          </span>
                        </div>
                      </div>

                      <h4 
                        onClick={() => setSelectedFile(file)}
                        className="text-sm font-bold text-gray-900 group-hover:text-indigo-600 transition-colors truncate cursor-pointer" 
                        title={file.name}
                      >
                        {file.name}
                      </h4>
                      {file.contentSnippet && (
                        <p className="text-xs text-gray-500 mt-1 line-clamp-2 leading-relaxed bg-gray-50 p-2 rounded-lg font-mono text-[11px]">
                          {file.contentSnippet}
                        </p>
                      )}
                    </div>

                    <div className="pt-4 border-t border-gray-100 mt-4 flex items-center justify-between text-xs text-gray-500">
                      <div>
                        <span className="font-semibold text-gray-700">{file.size}</span> • {file.date}
                        <div className="text-[10px] text-gray-400 mt-0.5 truncate max-w-[140px]">
                          By {file.createdBy}
                        </div>
                      </div>
                      <div className="flex items-center space-x-1">
                        <button 
                          onClick={() => setSelectedFile(file)}
                          className="p-2 hover:bg-gray-100 rounded-lg text-gray-600 hover:text-indigo-600 transition-colors"
                          title="Inspect Snippet"
                        >
                          <i className="fa-solid fa-eye text-xs"></i>
                        </button>
                        
                        {file.sourceUrl && (
                          <button 
                            onClick={() => {
                              navigator.clipboard.writeText(file.sourceUrl!);
                              alert(`Copied URL for ${file.name} to clipboard!\n${file.sourceUrl}`);
                            }}
                            className="p-2 hover:bg-gray-100 rounded-lg text-gray-600 hover:text-blue-600 transition-colors"
                            title="Copy Source URL"
                          >
                            <i className="fa-solid fa-link text-xs"></i>
                          </button>
                        )}

                        <button 
                          onClick={() => alert(`Downloading ${file.name}...`)}
                          className="p-2 hover:bg-gray-100 rounded-lg text-gray-600 hover:text-indigo-600 transition-colors"
                          title="Download File"
                        >
                          <i className="fa-solid fa-download text-xs"></i>
                        </button>

                        <button 
                          onClick={(e) => handleDeleteFile(file.id, e)}
                          className="p-2 hover:bg-rose-50 rounded-lg text-gray-400 hover:text-rose-600 transition-colors"
                          title="Delete File"
                        >
                          <i className="fa-solid fa-trash text-xs"></i>
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      })()}

      {/* TAB 3: AI AGENTS & RESULTS */}
      {activeTab === 'agents' && (() => {
        // Unique agent names for dropdown
        const availableAgentNames = Array.from(new Set(project.agentResults.map(r => r.agentName)));

        // Filter and sort results
        const filteredAndSortedResults = project.agentResults
          .filter(result => {
            // Text search
            if (agentSearch.trim()) {
              const q = agentSearch.toLowerCase().trim();
              const matchName = result.agentName.toLowerCase().includes(q);
              const matchSummary = result.summary.toLowerCase().includes(q);
              const matchFull = result.fullResult.toLowerCase().includes(q);
              if (!matchName && !matchSummary && !matchFull) return false;
            }

            // Agent name filter
            if (agentFilter !== 'All' && result.agentName !== agentFilter) {
              return false;
            }

            // Status filter
            if (agentStatusFilter !== 'All' && result.status !== agentStatusFilter) {
              return false;
            }

            return true;
          })
          .sort((a, b) => {
            if (agentSortBy === 'name-asc') {
              return a.agentName.localeCompare(b.agentName);
            }
            if (agentSortBy === 'date-asc') {
              return a.runDate.localeCompare(b.runDate);
            }
            return 0; // default date-desc preserve current array order
          });

        const isFiltered = agentSearch.trim() !== '' || agentFilter !== 'All' || agentStatusFilter !== 'All' || agentSortBy !== 'date-desc';

        return (
          <div className="space-y-6 animate-in fade-in">
            {/* Header Action Bar */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-5 rounded-2xl border border-gray-200 shadow-sm">
              <div>
                <div className="flex items-center gap-2.5">
                  <h3 className="text-lg font-bold text-gray-900">Project AI Agents & Deliverables</h3>
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-purple-50 text-purple-700">
                    {project.agentResults.length} Deliverables
                  </span>
                </div>
                <p className="text-xs text-gray-500 mt-1">Intelligent research, heuristic reviews, microcopy, and wireframe runs for {project.title}.</p>
              </div>
              <button 
                onClick={() => setIsRunAgentOpen(true)}
                className="px-4 py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white rounded-xl text-xs font-semibold flex items-center shadow-md shadow-indigo-200 transition-all hover:scale-[1.02]"
              >
                <i className="fa-solid fa-play mr-2 text-[10px]"></i>
                Run New Agent for this Project
              </button>
            </div>

            {/* Filter and View Toolbar */}
            <div className="bg-white p-4 rounded-2xl border border-gray-200 shadow-sm space-y-3">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
                {/* Search Input */}
                <div className="relative flex-1">
                  <i className="fa-solid fa-magnifying-glass absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 text-xs"></i>
                  <input 
                    type="text"
                    value={agentSearch}
                    onChange={(e) => setAgentSearch(e.target.value)}
                    placeholder="Search by agent name, summary, deliverable findings..."
                    className="w-full pl-9 pr-8 py-2 bg-gray-50 border border-gray-200 rounded-xl text-xs text-gray-800 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
                  />
                  {agentSearch && (
                    <button 
                      onClick={() => setAgentSearch('')}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 text-xs p-1"
                    >
                      <i className="fa-solid fa-circle-xmark"></i>
                    </button>
                  )}
                </div>

                {/* Filter and Sort Selectors */}
                <div className="flex flex-wrap items-center gap-2">
                  {/* Agent Filter */}
                  <div className="flex items-center gap-1.5">
                    <span className="text-[11px] font-semibold text-gray-500 hidden sm:inline">Agent:</span>
                    <select 
                      value={agentFilter}
                      onChange={(e) => setAgentFilter(e.target.value)}
                      className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-xs font-medium text-gray-700 focus:outline-none focus:ring-2 focus:ring-purple-500 max-w-[150px] truncate"
                    >
                      <option value="All">All Agents</option>
                      {availableAgentNames.map(name => (
                        <option key={name} value={name}>{name}</option>
                      ))}
                    </select>
                  </div>

                  {/* Status Filter */}
                  <div className="flex items-center gap-1.5">
                    <span className="text-[11px] font-semibold text-gray-500 hidden sm:inline">Status:</span>
                    <select 
                      value={agentStatusFilter}
                      onChange={(e) => setAgentStatusFilter(e.target.value as any)}
                      className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-xs font-medium text-gray-700 focus:outline-none focus:ring-2 focus:ring-purple-500"
                    >
                      <option value="All">All Statuses</option>
                      <option value="Completed">Completed</option>
                      <option value="In Review">In Review</option>
                      <option value="Applied">Applied</option>
                    </select>
                  </div>

                  {/* Sort Order */}
                  <div className="flex items-center gap-1.5">
                    <span className="text-[11px] font-semibold text-gray-500 hidden sm:inline">Sort:</span>
                    <select 
                      value={agentSortBy}
                      onChange={(e) => setAgentSortBy(e.target.value as any)}
                      className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-xs font-medium text-gray-700 focus:outline-none focus:ring-2 focus:ring-purple-500"
                    >
                      <option value="date-desc">Newest First</option>
                      <option value="date-asc">Oldest First</option>
                      <option value="name-asc">Agent Name (A-Z)</option>
                    </select>
                  </div>

                  {/* View Mode Toggle (Grid vs List) */}
                  <div className="flex items-center bg-gray-100 p-0.5 rounded-xl border border-gray-200 ml-auto sm:ml-0">
                    <button 
                      onClick={() => setAgentViewMode('grid')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                        agentViewMode === 'grid' 
                          ? 'bg-white text-gray-900 shadow-xs' 
                          : 'text-gray-500 hover:text-gray-900'
                      }`}
                      title="Grid View"
                    >
                      <i className="fa-solid fa-table-cells-large text-xs"></i>
                      <span className="hidden sm:inline">Grid</span>
                    </button>
                    <button 
                      onClick={() => setAgentViewMode('list')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                        agentViewMode === 'list' 
                          ? 'bg-white text-gray-900 shadow-xs' 
                          : 'text-gray-500 hover:text-gray-900'
                      }`}
                      title="List View"
                    >
                      <i className="fa-solid fa-list text-xs"></i>
                      <span className="hidden sm:inline">List</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Status bar: Counts and Clear button */}
              <div className="flex items-center justify-between text-xs text-gray-500 pt-1 border-t border-gray-100">
                <div className="flex items-center gap-2">
                  <span>Showing <strong>{filteredAndSortedResults.length}</strong> of {project.agentResults.length} deliverables</span>
                  {isFiltered && (
                    <span className="text-purple-600 font-medium">(Filtered)</span>
                  )}
                </div>

                {isFiltered && (
                  <button 
                    onClick={() => {
                      setAgentSearch('');
                      setAgentFilter('All');
                      setAgentStatusFilter('All');
                      setAgentSortBy('date-desc');
                    }}
                    className="text-xs text-purple-600 hover:text-purple-800 font-semibold hover:underline flex items-center gap-1"
                  >
                    <i className="fa-solid fa-rotate-left text-[10px]"></i>
                    Reset Filters
                  </button>
                )}
              </div>
            </div>

            {/* Empty State */}
            {filteredAndSortedResults.length === 0 ? (
              <div className="bg-white rounded-2xl border border-gray-200 p-12 text-center shadow-sm">
                <div className="w-14 h-14 rounded-2xl bg-purple-50 text-purple-500 flex items-center justify-center mx-auto mb-3">
                  <i className="fa-solid fa-robot text-2xl"></i>
                </div>
                <h4 className="text-base font-bold text-gray-900 mb-1">No deliverables match your filters</h4>
                <p className="text-xs text-gray-500 max-w-sm mx-auto mb-4">Try clearing your search query or reset status and agent filters to view all deliverables.</p>
                <div className="flex items-center justify-center gap-2">
                  <button 
                    onClick={() => {
                      setAgentSearch('');
                      setAgentFilter('All');
                      setAgentStatusFilter('All');
                      setAgentSortBy('date-desc');
                    }}
                    className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-xs font-semibold transition-colors"
                  >
                    Clear All Filters
                  </button>
                  <button 
                    onClick={() => setIsRunAgentOpen(true)}
                    className="px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-all"
                  >
                    <i className="fa-solid fa-play mr-1.5 text-[10px]"></i>
                    Run New Agent
                  </button>
                </div>
              </div>
            ) : agentViewMode === 'list' ? (
              /* --- LIST VIEW --- */
              <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-sm">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-gray-50/80 border-b border-gray-200 text-[11px] font-bold text-gray-500 uppercase tracking-wider">
                        <th className="py-3.5 px-4">Agent & Deliverable</th>
                        <th className="py-3.5 px-4">Summary & Insights</th>
                        <th className="py-3.5 px-4">Status</th>
                        <th className="py-3.5 px-4">Run Date</th>
                        <th className="py-3.5 px-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100 text-xs text-gray-700">
                      {filteredAndSortedResults.map((result) => (
                        <tr 
                          key={result.id}
                          className="hover:bg-purple-50/20 transition-colors group cursor-pointer"
                          onClick={() => setSelectedResult(result)}
                        >
                          <td className="py-3.5 px-4">
                            <div className="flex items-center space-x-3">
                              <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 text-white text-sm shadow-2xs ${result.agentBg}`}>
                                <i className={`fa-solid ${result.agentIcon}`}></i>
                              </div>
                              <div className="min-w-0 max-w-xs">
                                <span className="font-bold text-gray-900 group-hover:text-purple-600 transition-colors block truncate" title={result.agentName}>
                                  {result.agentName}
                                </span>
                                <span className="text-[10px] text-purple-600 font-medium flex items-center gap-1">
                                  <i className="fa-solid fa-shield-check text-[9px]"></i>
                                  Verified Output
                                </span>
                              </div>
                            </div>
                          </td>

                          <td className="py-3.5 px-4 max-w-md">
                            <p className="text-xs text-gray-800 line-clamp-2 leading-relaxed">
                              {result.summary}
                            </p>
                            <span className="text-[10px] font-mono text-gray-400 mt-0.5 block truncate">
                              {result.fullResult.replace(/\n/g, ' ').slice(0, 80)}...
                            </span>
                          </td>

                          <td className="py-3.5 px-4 whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                            <select
                              value={result.status}
                              onChange={(e) => handleUpdateAgentResultStatus(result.id, e.target.value as any, e as any)}
                              className={`px-2.5 py-1 rounded-full text-xs font-bold border transition-colors cursor-pointer focus:outline-none ${
                                result.status === 'Applied' ? 'bg-indigo-50 border-indigo-200 text-indigo-700' :
                                result.status === 'Completed' ? 'bg-green-50 border-green-200 text-green-700' :
                                'bg-amber-50 border-amber-200 text-amber-700'
                              }`}
                            >
                              <option value="Completed">Completed</option>
                              <option value="In Review">In Review</option>
                              <option value="Applied">Applied</option>
                            </select>
                          </td>

                          <td className="py-3.5 px-4 text-gray-500 whitespace-nowrap text-[11px]">
                            {result.runDate}
                          </td>

                          <td className="py-3.5 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                            <div className="flex items-center justify-end space-x-1.5">
                              <button 
                                onClick={() => setSelectedResult(result)}
                                className="px-2.5 py-1.5 hover:bg-purple-50 rounded-lg text-purple-700 hover:text-purple-900 font-semibold transition-colors flex items-center gap-1 text-xs"
                                title="Inspect Full Report"
                              >
                                <i className="fa-solid fa-eye text-xs"></i>
                                <span className="hidden sm:inline">Inspect</span>
                              </button>

                              <button 
                                onClick={(e) => handleCopyResultContent(result, e)}
                                className="p-1.5 hover:bg-gray-100 rounded-lg text-gray-500 hover:text-gray-900 transition-colors"
                                title="Copy Deliverable Content"
                              >
                                <i className={`fa-solid ${copiedResultId === result.id ? 'fa-check text-green-600' : 'fa-copy text-xs'}`}></i>
                              </button>

                              <button 
                                onClick={(e) => handleDeleteAgentResult(result.id, e)}
                                className="p-1.5 hover:bg-rose-50 rounded-lg text-gray-400 hover:text-rose-600 transition-colors"
                                title="Delete Deliverable"
                              >
                                <i className="fa-solid fa-trash text-xs"></i>
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : (
              /* --- GRID VIEW --- */
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {filteredAndSortedResults.map(result => (
                  <div 
                    key={result.id}
                    className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm hover:border-purple-300 hover:shadow-md transition-all flex flex-col justify-between group"
                  >
                    <div>
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center space-x-3">
                          <div className={`w-12 h-12 ${result.agentBg} rounded-xl flex items-center justify-center text-white text-lg shadow-sm`}>
                            <i className={`fa-solid ${result.agentIcon}`}></i>
                          </div>
                          <div>
                            <h4 className="text-base font-bold text-gray-900 group-hover:text-purple-600 transition-colors">{result.agentName}</h4>
                            <span className="text-xs text-gray-400">Run: {result.runDate}</span>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-2" onClick={(e) => e.stopPropagation()}>
                          <select
                            value={result.status}
                            onChange={(e) => handleUpdateAgentResultStatus(result.id, e.target.value as any, e as any)}
                            className={`px-2.5 py-0.5 rounded-full text-xs font-bold border cursor-pointer focus:outline-none ${
                              result.status === 'Applied' ? 'bg-indigo-50 border-indigo-200 text-indigo-700' :
                              result.status === 'Completed' ? 'bg-green-50 border-green-200 text-green-700' :
                              'bg-amber-50 border-amber-200 text-amber-700'
                            }`}
                          >
                            <option value="Completed">Completed</option>
                            <option value="In Review">In Review</option>
                            <option value="Applied">Applied</option>
                          </select>

                          <button 
                            onClick={(e) => handleDeleteAgentResult(result.id, e)}
                            className="p-1 hover:bg-rose-50 text-gray-300 hover:text-rose-500 rounded-md transition-colors"
                            title="Delete Deliverable"
                          >
                            <i className="fa-solid fa-trash text-xs"></i>
                          </button>
                        </div>
                      </div>

                      <p className="text-xs text-gray-700 leading-relaxed mb-4 bg-gray-50 p-3 rounded-xl border border-gray-100">
                        {result.summary}
                      </p>

                      <div className="bg-slate-900 text-slate-200 p-3.5 rounded-xl font-mono text-[11px] max-h-36 overflow-y-auto leading-relaxed">
                        <pre className="whitespace-pre-wrap font-sans text-xs">{result.fullResult.slice(0, 240)}...</pre>
                      </div>
                    </div>

                    <div className="pt-4 border-t border-gray-100 mt-5 flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <span className="text-xs text-purple-600 font-semibold flex items-center">
                          <i className="fa-solid fa-shield-check mr-1.5"></i> Verified Deliverable
                        </span>
                        <button 
                          onClick={(e) => handleCopyResultContent(result, e)}
                          className="text-xs text-gray-500 hover:text-gray-800 transition-colors flex items-center gap-1 font-medium ml-2 px-2 py-1 rounded-lg hover:bg-gray-100"
                          title="Copy Full Result to Clipboard"
                        >
                          <i className={`fa-solid ${copiedResultId === result.id ? 'fa-check text-green-600' : 'fa-copy'}`}></i>
                          <span>{copiedResultId === result.id ? 'Copied' : 'Copy'}</span>
                        </button>
                      </div>

                      <button 
                        onClick={() => setSelectedResult(result)}
                        className="px-4 py-2 bg-purple-50 hover:bg-purple-100 text-purple-700 rounded-xl text-xs font-semibold transition-colors flex items-center group-hover:bg-purple-600 group-hover:text-white"
                      >
                        Inspect Full Report
                        <i className="fa-solid fa-arrow-right ml-1.5 text-[10px]"></i>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      })()}

      {/* TAB 4: TIMELINE & MILESTONES */}
      {activeTab === 'timeline' && (
        <div className="space-y-6 animate-in fade-in">
          {/* Header Action Bar */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-5 rounded-2xl border border-gray-200 shadow-sm">
            <div>
              <div className="flex items-center gap-2.5">
                <h3 className="text-lg font-bold text-gray-900">Project Timeline & Milestones</h3>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-50 text-indigo-700">
                  {project.timeline.length} Milestones
                </span>
              </div>
              <p className="text-xs text-gray-500 mt-1">Phased design roadmap, sprint targets, deliverable checklists, and handoffs.</p>
            </div>

            <div className="flex flex-wrap items-center gap-2.5 w-full sm:w-auto">
              <div className="flex items-center gap-2 text-xs font-semibold px-3 py-1.5 bg-gray-50 border border-gray-200 rounded-xl text-gray-700">
                <span>Progress:</span>
                <span className="text-indigo-600 font-bold">{project.progress}%</span>
              </div>

              <button 
                id="create-milestone-btn"
                onClick={openAddMilestoneModal}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold flex items-center shadow-md shadow-indigo-100 transition-all hover:scale-[1.02]"
              >
                <i className="fa-solid fa-plus mr-1.5"></i>
                Create Milestone
              </button>
            </div>
          </div>

          {project.timeline.length === 0 ? (
            <div className="bg-white rounded-2xl border border-gray-200 p-12 text-center shadow-sm">
              <div className="w-14 h-14 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto mb-3">
                <i className="fa-solid fa-timeline text-2xl"></i>
              </div>
              <h4 className="text-base font-bold text-gray-900 mb-1">No milestones defined yet</h4>
              <p className="text-xs text-gray-500 max-w-sm mx-auto mb-4">Start your roadmap by creating the first project milestone and sprint deliverable checklist.</p>
              <button 
                onClick={openAddMilestoneModal}
                className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-semibold hover:bg-indigo-700 shadow-sm"
              >
                <i className="fa-solid fa-plus mr-1.5"></i>
                Create Milestone
              </button>
            </div>
          ) : (
            <div className="relative pl-6 md:pl-8 border-l-2 border-indigo-100 space-y-8 my-4 ml-4">
              {project.timeline.map((milestone, idx) => {
                const completedCount = (milestone.completedDeliverables || (milestone.progress >= 100 ? milestone.deliverables : [])).length;
                const totalCount = milestone.deliverables.length;

                return (
                  <div key={milestone.id} className="relative group">
                    {/* Node icon */}
                    <div className={`absolute -left-[37px] md:-left-[45px] top-1.5 w-8 h-8 rounded-full border-4 border-white shadow-sm flex items-center justify-center text-xs font-bold transition-transform group-hover:scale-110 ${
                      milestone.status === 'Completed' ? 'bg-green-500 text-white' :
                      milestone.status === 'In Progress' ? 'bg-indigo-600 text-white animate-pulse' :
                      'bg-gray-200 text-gray-600'
                    }`}>
                      {milestone.status === 'Completed' ? <i className="fa-solid fa-check"></i> : idx + 1}
                    </div>

                    {/* Milestone Card */}
                    <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm hover:shadow-md transition-all">
                      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-3">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="px-2.5 py-0.5 rounded-md text-[10px] font-extrabold uppercase tracking-wider bg-indigo-50 text-indigo-700">
                            {milestone.phase}
                          </span>
                          <h4 className="text-base font-bold text-gray-900">{milestone.title}</h4>
                        </div>

                        <div className="flex items-center gap-2 text-xs">
                          <span className="text-gray-400 font-medium">
                            <i className="fa-regular fa-calendar mr-1 text-[11px]"></i>
                            {milestone.startDate} — {milestone.dueDate}
                          </span>

                          {/* Quick status selector */}
                          <select 
                            value={milestone.status}
                            onChange={(e) => handleUpdateMilestoneStatus(milestone.id, e.target.value as any)}
                            className={`px-2.5 py-1 rounded-full text-xs font-bold border-0 cursor-pointer focus:ring-2 focus:ring-indigo-500 ${
                              milestone.status === 'Completed' ? 'bg-green-100 text-green-700' :
                              milestone.status === 'In Progress' ? 'bg-blue-100 text-blue-700' :
                              'bg-gray-100 text-gray-600'
                            }`}
                          >
                            <option value="Upcoming">Upcoming</option>
                            <option value="In Progress">In Progress</option>
                            <option value="Completed">Completed</option>
                          </select>

                          {/* Edit / Delete actions */}
                          <button 
                            onClick={() => openEditMilestoneModal(milestone)}
                            className="p-1.5 hover:bg-gray-100 rounded-lg text-gray-400 hover:text-indigo-600 transition-colors"
                            title="Edit Milestone"
                          >
                            <i className="fa-solid fa-pen-to-square text-xs"></i>
                          </button>
                          <button 
                            onClick={() => handleDeleteMilestone(milestone.id)}
                            className="p-1.5 hover:bg-rose-50 rounded-lg text-gray-400 hover:text-rose-600 transition-colors"
                            title="Delete Milestone"
                          >
                            <i className="fa-solid fa-trash text-xs"></i>
                          </button>
                        </div>
                      </div>

                      <p className="text-xs text-gray-600 mb-4 leading-relaxed">{milestone.description}</p>

                      {/* Progress bar */}
                      <div className="mb-4">
                        <div className="flex justify-between text-xs font-semibold text-gray-500 mb-1.5">
                          <span>Milestone Completion</span>
                          <span className="text-indigo-600 font-bold">{milestone.progress}%</span>
                        </div>
                        <div className="w-full bg-gray-100 rounded-full h-2 overflow-hidden">
                          <div 
                            className={`h-2 rounded-full transition-all duration-500 ${
                              milestone.status === 'Completed' ? 'bg-green-500' : 'bg-indigo-600'
                            }`} 
                            style={{ width: `${milestone.progress}%` }}
                          ></div>
                        </div>
                      </div>

                      {/* Deliverables checklist */}
                      <div className="pt-3 border-t border-gray-100">
                        <div className="flex items-center justify-between mb-2.5">
                          <h5 className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">
                            Deliverables Checklist ({completedCount} of {totalCount} completed)
                          </h5>
                          <span className="text-[10px] text-gray-400 font-medium">Click item to toggle completion</span>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {milestone.deliverables.map((deliv, dIdx) => {
                            const isDone = (milestone.completedDeliverables || (milestone.progress >= 100 ? milestone.deliverables : [])).includes(deliv);
                            return (
                              <div 
                                key={dIdx} 
                                onClick={() => handleToggleDeliverable(milestone.id, deliv)}
                                className={`flex items-center space-x-2 text-xs p-2.5 rounded-xl cursor-pointer border transition-all ${
                                  isDone 
                                    ? 'bg-green-50/60 border-green-200 text-green-900' 
                                    : 'bg-gray-50/80 border-gray-200 hover:border-indigo-200 hover:bg-indigo-50/20 text-gray-800'
                                }`}
                              >
                                <i className={`fa-solid ${isDone ? 'fa-circle-check text-green-600' : 'fa-circle text-gray-300'} text-xs`}></i>
                                <span className={`flex-grow truncate ${isDone ? 'line-through text-gray-500' : 'font-medium'}`}>
                                  {deliv}
                                </span>
                              </div>
                            );
                          })}
                        </div>

                        {/* Inline Deliverable Adder */}
                        <form 
                          onSubmit={(e) => {
                            e.preventDefault();
                            handleAddDeliverableToMilestone(milestone.id);
                          }}
                          className="flex items-center gap-2 mt-3"
                        >
                          <input 
                            type="text" 
                            placeholder="+ Add deliverable item to checklist..."
                            value={quickDeliverableInputs[milestone.id] || ''}
                            onChange={(e) => setQuickDeliverableInputs({
                              ...quickDeliverableInputs,
                              [milestone.id]: e.target.value
                            })}
                            className="flex-grow px-3 py-1.5 text-xs bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 font-sans"
                          />
                          <button 
                            type="submit"
                            className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1"
                          >
                            <i className="fa-solid fa-plus text-[10px]"></i>
                            <span>Add</span>
                          </button>
                        </form>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 5: TEAM MEMBERS */}
      {activeTab === 'team' && (
        <div className="space-y-6 animate-in fade-in">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-4 rounded-2xl border border-gray-200 shadow-sm">
            <div>
              <h3 className="text-lg font-bold text-gray-900">Project Team & Contributors</h3>
              <p className="text-xs text-gray-500">Designers, engineers, researchers, and AI collaborators working on {project.title}.</p>
            </div>
            <button 
              onClick={() => setIsAddMemberOpen(true)}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold flex items-center shadow-md transition-all"
            >
              <i className="fa-solid fa-user-plus mr-1.5"></i>
              Add Team Member
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {project.teamMembers.map(member => (
              <div 
                key={member.id}
                className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between mb-4">
                    <div className="relative">
                      <img src={member.avatar} alt={member.name} className="w-16 h-16 rounded-2xl object-cover border-2 border-gray-100 shadow-sm" />
                      <span className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white ${
                        member.status === 'Active' ? 'bg-green-500' :
                        member.status === 'In Meeting' ? 'bg-amber-500' : 'bg-gray-400'
                      }`} title={member.status}></span>
                    </div>
                    <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                      member.status === 'Active' ? 'bg-green-100 text-green-700' :
                      member.status === 'In Meeting' ? 'bg-amber-100 text-amber-700' : 'bg-gray-100 text-gray-600'
                    }`}>
                      {member.status}
                    </span>
                  </div>

                  <h4 className="text-base font-bold text-gray-900">{member.name}</h4>
                  <p className="text-xs font-medium text-indigo-600 mt-0.5">{member.role}</p>
                  <p className="text-xs text-gray-400 mt-1">{member.email}</p>
                </div>

                <div className="pt-4 border-t border-gray-100 mt-5 flex items-center justify-between text-xs text-gray-500">
                  <span>Assigned Tasks: <strong>{member.tasksCount}</strong></span>
                  <button 
                    onClick={() => alert(`Direct messaging ${member.name}...`)}
                    className="text-xs text-indigo-600 hover:underline font-semibold"
                  >
                    Message
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 6: RECENT ACTIVITY */}
      {activeTab === 'activity' && (
        <div className="space-y-6 animate-in fade-in">
          <div className="bg-white p-4 rounded-2xl border border-gray-200 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h3 className="text-lg font-bold text-gray-900">Project Activity Audit Log</h3>
              <p className="text-xs text-gray-500">Real-time chronicle of user interactions, file updates, and AI agent runs.</p>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-gray-500">{project.recentActivity.length} Events Logged</span>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm divide-y divide-gray-100">
            {project.recentActivity.map(activity => (
              <div key={activity.id} className="py-4 first:pt-0 last:pb-0 flex items-start space-x-4">
                {activity.actorType === 'agent' ? (
                  <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-600 flex items-center justify-center flex-shrink-0 text-sm shadow-sm">
                    <i className={`fa-solid ${activity.icon || 'fa-robot'}`}></i>
                  </div>
                ) : (
                  <img src={activity.avatar || 'https://picsum.photos/40/40'} alt={activity.actor} className="w-10 h-10 rounded-full object-cover flex-shrink-0 border border-gray-200" />
                )}
                <div className="flex-grow">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-gray-900">
                      {activity.actor} <span className="font-normal text-gray-600">{activity.action}</span>
                    </h4>
                    <span className="text-[11px] text-gray-400">{activity.time}</span>
                  </div>
                  {activity.details && (
                    <p className="text-xs text-gray-500 mt-1 bg-gray-50 p-2.5 rounded-lg border border-gray-100">
                      {activity.details}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* --- MODAL 1: VIEW AI DELIVERABLE REPORT --- */}
      {selectedResult && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl overflow-hidden border border-gray-100 flex flex-col max-h-[90vh]">
            <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50/80">
              <div className="flex items-center space-x-3">
                <div className={`w-9 h-9 ${selectedResult.agentBg} rounded-xl flex items-center justify-center text-white text-sm shadow-sm`}>
                  <i className={`fa-solid ${selectedResult.agentIcon}`}></i>
                </div>
                <div>
                  <h3 className="text-base font-bold text-gray-900">{selectedResult.agentName}</h3>
                  <p className="text-xs text-gray-500">Run for {project.title} • {selectedResult.runDate}</p>
                </div>
              </div>
              <button onClick={() => setSelectedResult(null)} className="text-gray-400 hover:text-gray-600">
                <i className="fa-solid fa-times text-base"></i>
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-4">
              <div className="bg-purple-50 border border-purple-100 p-3.5 rounded-xl">
                <span className="text-xs font-bold text-purple-700 uppercase tracking-wider block mb-1">Summary</span>
                <p className="text-xs text-purple-900 leading-relaxed">{selectedResult.summary}</p>
              </div>

              <div className="bg-slate-900 text-slate-100 p-5 rounded-xl font-mono text-xs leading-relaxed shadow-inner overflow-x-auto">
                <pre className="whitespace-pre-wrap font-sans text-xs">{selectedResult.fullResult}</pre>
              </div>
            </div>

            <div className="px-6 py-3.5 bg-gray-50 border-t border-gray-100 flex justify-between items-center text-xs">
              <button 
                onClick={() => {
                  navigator.clipboard.writeText(selectedResult.fullResult);
                  alert('Copied deliverable to clipboard!');
                }}
                className="text-gray-600 hover:text-gray-900 font-semibold flex items-center gap-1.5"
              >
                <i className="fa-solid fa-copy"></i> Copy Content
              </button>
              <button 
                onClick={() => setSelectedResult(null)}
                className="px-4 py-2 bg-indigo-600 text-white font-semibold rounded-xl hover:bg-indigo-700"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* --- MODAL 2: VIEW FILE SNIPPET --- */}
      {selectedFile && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden border border-gray-100">
            <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50/80">
              <div className="flex items-center space-x-2.5">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm ${getFileIcon(selectedFile.type)}`}>
                  <i className={`fa-solid ${getFileIcon(selectedFile.type).split(' ')[0]}`}></i>
                </div>
                <div>
                  <h3 className="text-sm font-bold text-gray-900 truncate max-w-xs">{selectedFile.name}</h3>
                  <p className="text-[11px] text-gray-500">{selectedFile.size} • {selectedFile.type}</p>
                </div>
              </div>
              <button onClick={() => setSelectedFile(null)} className="text-gray-400 hover:text-gray-600">
                <i className="fa-solid fa-times text-base"></i>
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div className="text-xs text-gray-600 flex flex-wrap items-center gap-3">
                <span>Created by: <strong>{selectedFile.createdBy}</strong></span>
                <span>•</span>
                <span>Date: {selectedFile.date}</span>
                {selectedFile.isAIGenerated && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-100 text-purple-700">
                    AI Generated
                  </span>
                )}
              </div>

              {selectedFile.sourceUrl && (
                <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-xl text-xs flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 truncate">
                    <i className="fa-solid fa-link text-blue-600 flex-shrink-0"></i>
                    <span className="truncate font-mono text-[11px] text-blue-900">{selectedFile.sourceUrl}</span>
                  </div>
                  <button 
                    onClick={() => {
                      navigator.clipboard.writeText(selectedFile.sourceUrl!);
                      alert('Copied URL to clipboard!');
                    }}
                    className="text-blue-700 hover:text-blue-900 font-bold text-[10px] uppercase tracking-wider whitespace-nowrap bg-white px-2 py-1 rounded border border-blue-200 shadow-2xs"
                  >
                    Copy
                  </button>
                </div>
              )}

              <div className="bg-gray-50 p-4 rounded-xl border border-gray-200 font-mono text-xs text-gray-800 whitespace-pre-wrap leading-relaxed max-h-60 overflow-y-auto">
                {selectedFile.contentSnippet || `[Binary File Content: ${selectedFile.name}]\nFormat: ${selectedFile.type}\nStatus: Verified and synced with project design repository.`}
              </div>
            </div>
            <div className="px-6 py-3.5 bg-gray-50 border-t border-gray-100 flex justify-between items-center gap-2">
              <button 
                onClick={(e) => {
                  setSelectedFile(null);
                  handleDeleteFile(selectedFile.id, e);
                }}
                className="text-xs font-semibold text-rose-600 hover:text-rose-800 flex items-center gap-1.5"
              >
                <i className="fa-solid fa-trash text-[11px]"></i>
                Delete File
              </button>

              <div className="flex items-center gap-2">
                {selectedFile.sourceUrl && (
                  <button 
                    onClick={() => {
                      navigator.clipboard.writeText(selectedFile.sourceUrl!);
                      alert('Copied link: ' + selectedFile.sourceUrl);
                    }}
                    className="px-3 py-2 bg-white border border-gray-300 text-gray-700 rounded-xl text-xs font-semibold hover:bg-gray-100"
                  >
                    <i className="fa-solid fa-arrow-up-right-from-square mr-1 text-[10px]"></i>
                    Copy Link
                  </button>
                )}
                <button 
                  onClick={() => alert(`Downloading ${selectedFile.name}...`)}
                  className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-semibold hover:bg-indigo-700 shadow-sm"
                >
                  <i className="fa-solid fa-download mr-1.5"></i> Download
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* --- MODAL 3: ADD FILE --- */}
      {isAddFileOpen && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden border border-gray-100">
            <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50/80">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-600 flex items-center justify-center">
                  <i className="fa-solid fa-cloud-arrow-up text-sm"></i>
                </div>
                <h3 className="text-base font-bold text-gray-900">Upload Project File</h3>
              </div>
              <button onClick={() => setIsAddFileOpen(false)} className="text-gray-400 hover:text-gray-600">
                <i className="fa-solid fa-times text-base"></i>
              </button>
            </div>

            <form onSubmit={handleAddFile} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1">File Name *</label>
                <input 
                  type="text" 
                  required
                  value={newFileName}
                  onChange={(e) => setNewFileName(e.target.value)}
                  placeholder="e.g., Checkout_Micro_Flow.fig"
                  className="w-full px-3 py-2 text-xs border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1">File Type</label>
                  <select 
                    value={newFileType}
                    onChange={(e) => setNewFileType(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                  >
                    <option value="Figma">Figma (.fig)</option>
                    <option value="Sketch">Sketch (.sketch)</option>
                    <option value="Markdown">Markdown (.md)</option>
                    <option value="JSON">Tokens (.json)</option>
                    <option value="ZIP">Export (.zip)</option>
                    <option value="CSV">Test Matrix (.csv)</option>
                    <option value="PDF">Report (.pdf)</option>
                    <option value="Wireframe">Wireframe (.txt)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1">File Size</label>
                  <input 
                    type="text" 
                    value={newFileSize}
                    onChange={(e) => setNewFileSize(e.target.value)}
                    placeholder="e.g., 8.4 MB"
                    className="w-full px-3 py-2 text-xs border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1">Description / Content Snippet</label>
                <textarea 
                  rows={2}
                  value={newFileSnippet}
                  onChange={(e) => setNewFileSnippet(e.target.value)}
                  placeholder="Brief note on what this file contains..."
                  className="w-full px-3 py-2 text-xs border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none font-sans"
                />
              </div>

              <div className="pt-2 text-xs text-gray-500 bg-gray-50 p-2.5 rounded-xl border border-gray-100 flex items-center justify-between">
                <span>Want to link remote assets instead?</span>
                <button
                  type="button"
                  onClick={() => {
                    setIsAddFileOpen(false);
                    setIsImportUrlOpen(true);
                  }}
                  className="text-indigo-600 font-semibold hover:underline"
                >
                  Import from URL
                </button>
              </div>

              <div className="pt-3 border-t border-gray-100 flex justify-end gap-2">
                <button 
                  type="button" 
                  onClick={() => setIsAddFileOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-gray-600 hover:bg-gray-100 rounded-xl"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl"
                >
                  Add File
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --- MODAL: IMPORT FROM URL --- */}
      {isImportUrlOpen && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden border border-gray-100">
            <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50/80">
              <div className="flex items-center space-x-2.5">
                <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-600 flex items-center justify-center">
                  <i className="fa-solid fa-link text-sm"></i>
                </div>
                <div>
                  <h3 className="text-base font-bold text-gray-900">Import File from URL</h3>
                  <p className="text-[11px] text-gray-500">Link Figma designs, GitHub tokens, specs, or remote assets</p>
                </div>
              </div>
              <button onClick={() => setIsImportUrlOpen(false)} className="text-gray-400 hover:text-gray-600">
                <i className="fa-solid fa-times text-base"></i>
              </button>
            </div>

            <form onSubmit={handleImportFromUrl} className="p-6 space-y-4">
              {/* Presets */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-600 mb-2">
                  Quick Presets
                </label>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => handleUrlChange('https://www.figma.com/design/4de55822/Mobile_Banking_V2_Prototypes')}
                    className="p-2 border border-purple-200 hover:border-purple-400 bg-purple-50/50 hover:bg-purple-50 text-purple-900 rounded-xl text-left transition-colors flex items-center gap-2"
                  >
                    <i className="fa-brands fa-figma text-purple-600"></i>
                    <span className="truncate font-semibold">Figma UI Kit</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleUrlChange('https://raw.githubusercontent.com/design-tokens/core/main/tokens.json')}
                    className="p-2 border border-emerald-200 hover:border-emerald-400 bg-emerald-50/50 hover:bg-emerald-50 text-emerald-900 rounded-xl text-left transition-colors flex items-center gap-2"
                  >
                    <i className="fa-solid fa-code text-emerald-600"></i>
                    <span className="truncate font-semibold">GitHub Tokens (.json)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleUrlChange('https://raw.githubusercontent.com/design-specs/specs/main/product_requirements.md')}
                    className="p-2 border border-blue-200 hover:border-blue-400 bg-blue-50/50 hover:bg-blue-50 text-blue-900 rounded-xl text-left transition-colors flex items-center gap-2"
                  >
                    <i className="fa-solid fa-file-lines text-blue-600"></i>
                    <span className="truncate font-semibold">Design Spec (.md)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleUrlChange('https://raw.githubusercontent.com/ux-research/data/main/participant_matrix.csv')}
                    className="p-2 border border-teal-200 hover:border-teal-400 bg-teal-50/50 hover:bg-teal-50 text-teal-900 rounded-xl text-left transition-colors flex items-center gap-2"
                  >
                    <i className="fa-solid fa-table text-teal-600"></i>
                    <span className="truncate font-semibold">Research Matrix (.csv)</span>
                  </button>
                </div>
              </div>

              {/* URL Input */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1">
                  File Source URL *
                </label>
                <div className="relative">
                  <input 
                    type="url" 
                    required
                    value={importUrl}
                    onChange={(e) => handleUrlChange(e.target.value)}
                    placeholder="https://www.figma.com/design/... or https://..."
                    className="w-full pl-9 pr-4 py-2.5 text-xs border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
                  />
                  <i className="fa-solid fa-globe absolute left-3 top-3 text-gray-400 text-xs"></i>
                </div>
                {importUrl && (
                  <p className="text-[10px] text-gray-500 mt-1 flex items-center gap-1">
                    <i className="fa-solid fa-check text-green-500"></i>
                    Detected file format: <strong className="text-indigo-600">{importFileType}</strong>
                  </p>
                )}
              </div>

              {/* File Name & Type */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1">
                    File Name *
                  </label>
                  <input 
                    type="text" 
                    required
                    value={importFileName}
                    onChange={(e) => setImportFileName(e.target.value)}
                    placeholder="e.g., Master_UI_Spec.fig"
                    className="w-full px-3 py-2 text-xs border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1">
                    File Type
                  </label>
                  <select 
                    value={importFileType}
                    onChange={(e) => setImportFileType(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                  >
                    <option value="Figma">Figma (.fig)</option>
                    <option value="Sketch">Sketch (.sketch)</option>
                    <option value="Markdown">Markdown (.md)</option>
                    <option value="JSON">Tokens (.json)</option>
                    <option value="ZIP">Export (.zip)</option>
                    <option value="CSV">Test Matrix (.csv)</option>
                    <option value="PDF">Report (.pdf)</option>
                    <option value="Wireframe">Wireframe (.txt)</option>
                  </select>
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1">
                  Import Notes / Description
                </label>
                <textarea 
                  rows={2}
                  value={importNotes}
                  onChange={(e) => setImportNotes(e.target.value)}
                  placeholder="Optional notes about what this external asset contains..."
                  className="w-full px-3 py-2 text-xs border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none font-sans"
                />
              </div>

              <div className="pt-3 border-t border-gray-100 flex items-center justify-between">
                <span className="text-[11px] text-gray-400">
                  <i className="fa-solid fa-shield-halved mr-1 text-gray-400"></i>
                  File will be synced with project
                </span>

                <div className="flex items-center gap-2">
                  <button 
                    type="button" 
                    onClick={() => setIsImportUrlOpen(false)}
                    disabled={isImporting}
                    className="px-4 py-2 text-xs font-semibold text-gray-600 hover:bg-gray-100 rounded-xl"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit" 
                    disabled={isImporting || !importUrl.trim()}
                    className="px-5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-md shadow-indigo-100 transition-all flex items-center"
                  >
                    {isImporting ? (
                      <>
                        <i className="fa-solid fa-circle-notch fa-spin mr-1.5"></i>
                        Importing...
                      </>
                    ) : (
                      <>
                        <i className="fa-solid fa-link mr-1.5"></i>
                        Import File
                      </>
                    )}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --- MODAL 4: ADD TEAM MEMBER --- */}
      {isAddMemberOpen && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden border border-gray-100">
            <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50/80">
              <h3 className="text-base font-bold text-gray-900">Add Team Member</h3>
              <button onClick={() => setIsAddMemberOpen(false)} className="text-gray-400 hover:text-gray-600">
                <i className="fa-solid fa-times text-base"></i>
              </button>
            </div>

            <form onSubmit={handleAddMember} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1">Full Name *</label>
                <input 
                  type="text" 
                  required
                  value={newMemberName}
                  onChange={(e) => setNewMemberName(e.target.value)}
                  placeholder="e.g., Jonathan Bell"
                  className="w-full px-3 py-2 text-xs border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1">Role *</label>
                <select 
                  value={newMemberRole}
                  onChange={(e) => setNewMemberRole(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                >
                  <option value="Lead Product Designer">Lead Product Designer</option>
                  <option value="UI/UX Designer">UI/UX Designer</option>
                  <option value="UX Researcher">UX Researcher</option>
                  <option value="Design Systems Engineer">Design Systems Engineer</option>
                  <option value="Frontend Developer">Frontend Developer</option>
                  <option value="Product Manager">Product Manager</option>
                  <option value="QA & Accessibility Specialist">QA & Accessibility Specialist</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1">Work Email</label>
                <input 
                  type="email" 
                  value={newMemberEmail}
                  onChange={(e) => setNewMemberEmail(e.target.value)}
                  placeholder="e.g., j.bell@company.design"
                  className="w-full px-3 py-2 text-xs border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="pt-3 border-t border-gray-100 flex justify-end gap-2">
                <button 
                  type="button" 
                  onClick={() => setIsAddMemberOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-gray-600 hover:bg-gray-100 rounded-xl"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl"
                >
                  Add Member
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --- MODAL 5: RUN AGENT FOR THIS PROJECT --- */}
      {isRunAgentOpen && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden border border-gray-100">
            <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50/80">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-lg bg-purple-100 text-purple-600 flex items-center justify-center">
                  <i className="fa-solid fa-robot text-sm"></i>
                </div>
                <h3 className="text-base font-bold text-gray-900">Run AI Agent for {project.title}</h3>
              </div>
              <button onClick={() => setIsRunAgentOpen(false)} className="text-gray-400 hover:text-gray-600">
                <i className="fa-solid fa-times text-base"></i>
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1.5">
                  Select AI Agent (15 Available)
                </label>
                <select 
                  value={selectedAgentName}
                  onChange={(e) => setSelectedAgentName(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                >
                  {AGENTS.map(a => (
                    <option key={a.id} value={a.name}>
                      {a.name} — {a.tags.map(t => t.label).join(', ')}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1.5">
                  Project Request / Context
                </label>
                <textarea 
                  rows={3}
                  value={agentPrompt}
                  onChange={(e) => setAgentPrompt(e.target.value)}
                  className="w-full p-3 text-xs border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 font-sans"
                />
              </div>

              <div className="p-3 bg-purple-50 rounded-xl border border-purple-100 text-xs text-purple-800">
                <i className="fa-solid fa-circle-info mr-1 text-purple-600"></i>
                Results will automatically save into this project's <strong>Created Files</strong>, <strong>AI Results</strong>, and <strong>Recent Activity</strong>.
              </div>

              <div className="pt-3 border-t border-gray-100 flex justify-end gap-2">
                <button 
                  type="button" 
                  onClick={() => setIsRunAgentOpen(false)}
                  disabled={isExecutingAgent}
                  className="px-4 py-2 text-xs font-semibold text-gray-600 hover:bg-gray-100 rounded-xl"
                >
                  Cancel
                </button>
                <button 
                  type="button" 
                  onClick={handleRunAgentForProject}
                  disabled={isExecutingAgent || !agentPrompt.trim()}
                  className="px-5 py-2 text-xs font-semibold text-white bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 rounded-xl shadow-md transition-all flex items-center"
                >
                  {isExecutingAgent ? (
                    <>
                      <i className="fa-solid fa-circle-notch fa-spin mr-1.5"></i>
                      Processing...
                    </>
                  ) : (
                    <>
                      <i className="fa-solid fa-play mr-1.5 text-[10px]"></i>
                      Execute Agent
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* --- MODAL 6: CREATE / EDIT TIMELINE MILESTONE --- */}
      {isAddMilestoneOpen && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-xl overflow-hidden border border-gray-100 max-h-[90vh] flex flex-col">
            <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50/80">
              <div className="flex items-center space-x-2.5">
                <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-600 flex items-center justify-center">
                  <i className="fa-solid fa-timeline text-sm"></i>
                </div>
                <div>
                  <h3 className="text-base font-bold text-gray-900">
                    {editingMilestone ? 'Edit Milestone' : 'Create Timeline Milestone'}
                  </h3>
                  <p className="text-[11px] text-gray-500">Phased roadmap, deadlines, and deliverable checklist</p>
                </div>
              </div>
              <button onClick={() => setIsAddMilestoneOpen(false)} className="text-gray-400 hover:text-gray-600">
                <i className="fa-solid fa-times text-base"></i>
              </button>
            </div>

            <form onSubmit={handleSaveMilestone} className="p-6 space-y-4 overflow-y-auto flex-grow">
              {/* Quick Phase Presets */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-600 mb-1.5">
                  Phase / Tag Preset
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    `Phase ${project.timeline.length + 1}`,
                    'Sprint 1',
                    'Sprint 2',
                    'Discovery',
                    'Wireframes',
                    'Visual Design',
                    'Dev Handoff'
                  ].map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setMilestonePhase(preset)}
                      className={`px-2.5 py-1 text-xs rounded-lg font-semibold transition-colors ${
                        milestonePhase === preset 
                          ? 'bg-indigo-600 text-white shadow-2xs' 
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      {preset}
                    </button>
                  ))}
                </div>
              </div>

              {/* Phase & Title */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1">
                    Phase Label *
                  </label>
                  <input 
                    type="text" 
                    required
                    value={milestonePhase}
                    onChange={(e) => setMilestonePhase(e.target.value)}
                    placeholder="e.g., Phase 4"
                    className="w-full px-3 py-2 text-xs border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1">
                    Milestone Title *
                  </label>
                  <input 
                    type="text" 
                    required
                    value={milestoneTitle}
                    onChange={(e) => setMilestoneTitle(e.target.value)}
                    placeholder="e.g., Usability Testing & Design Polish"
                    className="w-full px-3 py-2 text-xs border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 font-semibold text-gray-900"
                  />
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1">
                  Milestone Objectives & Scope
                </label>
                <textarea 
                  rows={2}
                  value={milestoneDescription}
                  onChange={(e) => setMilestoneDescription(e.target.value)}
                  placeholder="Outline the core goals and team deliverables for this milestone..."
                  className="w-full px-3 py-2 text-xs border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none font-sans"
                />
              </div>

              {/* Dates & Status */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1">
                    Start Date
                  </label>
                  <input 
                    type="text" 
                    value={milestoneStartDate}
                    onChange={(e) => setMilestoneStartDate(e.target.value)}
                    placeholder="e.g., Oct 28"
                    className="w-full px-3 py-2 text-xs border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1">
                    Due Date
                  </label>
                  <input 
                    type="text" 
                    value={milestoneDueDate}
                    onChange={(e) => setMilestoneDueDate(e.target.value)}
                    placeholder="e.g., Nov 14"
                    className="w-full px-3 py-2 text-xs border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1">
                    Status
                  </label>
                  <select 
                    value={milestoneStatus}
                    onChange={(e) => {
                      const newStat = e.target.value as ProjectMilestone['status'];
                      setMilestoneStatus(newStat);
                      if (newStat === 'Completed') setMilestoneProgress(100);
                      if (newStat === 'Upcoming' && milestoneProgress === 100) setMilestoneProgress(0);
                    }}
                    className="w-full px-3 py-2 text-xs border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                  >
                    <option value="Upcoming">Upcoming</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Completed">Completed</option>
                  </select>
                </div>
              </div>

              {/* Progress Slider */}
              <div>
                <div className="flex justify-between items-center text-xs font-bold text-gray-700 mb-1">
                  <label className="uppercase tracking-wider">Initial Completion</label>
                  <span className="text-indigo-600">{milestoneProgress}%</span>
                </div>
                <input 
                  type="range" 
                  min="0" 
                  max="100" 
                  step="5"
                  value={milestoneProgress}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    setMilestoneProgress(val);
                    if (val === 100) setMilestoneStatus('Completed');
                    else if (val > 0 && milestoneStatus === 'Upcoming') setMilestoneStatus('In Progress');
                  }}
                  className="w-full accent-indigo-600 cursor-pointer"
                />
              </div>

              {/* Deliverable Checklist Builder */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1.5">
                  Deliverables Checklist ({milestoneDeliverables.length} items)
                </label>

                {/* Add deliverable input */}
                <div className="flex gap-2 mb-2">
                  <input 
                    type="text" 
                    placeholder="e.g., Interactive Figma Prototype"
                    value={deliverableInput}
                    onChange={(e) => setDeliverableInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        if (deliverableInput.trim()) {
                          setMilestoneDeliverables([...milestoneDeliverables, deliverableInput.trim()]);
                          setDeliverableInput('');
                        }
                      }
                    }}
                    className="flex-grow px-3 py-2 text-xs border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                  <button 
                    type="button"
                    onClick={() => {
                      if (deliverableInput.trim()) {
                        setMilestoneDeliverables([...milestoneDeliverables, deliverableInput.trim()]);
                        setDeliverableInput('');
                      }
                    }}
                    className="px-3.5 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-xl text-xs font-semibold"
                  >
                    Add
                  </button>
                </div>

                {/* Quick suggestions */}
                <div className="flex flex-wrap gap-1 mb-3">
                  {[
                    '+ User Research Report',
                    '+ Wireframe Artboards',
                    '+ Design System Tokens',
                    '+ High-Fi Mockups',
                    '+ Usability Audit (WCAG)'
                  ].map((suggestion) => (
                    <button
                      key={suggestion}
                      type="button"
                      onClick={() => {
                        const clean = suggestion.replace(/^\+\s*/, '');
                        if (!milestoneDeliverables.includes(clean)) {
                          setMilestoneDeliverables([...milestoneDeliverables, clean]);
                        }
                      }}
                      className="px-2 py-0.5 bg-gray-50 hover:bg-gray-100 text-gray-600 rounded text-[10px] font-medium transition-colors"
                    >
                      {suggestion}
                    </button>
                  ))}
                </div>

                {/* Deliverables List */}
                <div className="space-y-1.5 max-h-36 overflow-y-auto">
                  {milestoneDeliverables.map((deliv, index) => (
                    <div 
                      key={index}
                      className="flex items-center justify-between px-3 py-2 bg-gray-50 rounded-xl text-xs text-gray-800 border border-gray-100"
                    >
                      <span className="flex items-center gap-2 truncate">
                        <i className="fa-solid fa-check text-indigo-600 text-[10px]"></i>
                        <span className="truncate">{deliv}</span>
                      </span>
                      <button
                        type="button"
                        onClick={() => setMilestoneDeliverables(milestoneDeliverables.filter((_, i) => i !== index))}
                        className="text-gray-400 hover:text-rose-600 p-1 transition-colors"
                        title="Remove deliverable"
                      >
                        <i className="fa-solid fa-times text-xs"></i>
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="pt-3 border-t border-gray-100 flex items-center justify-end space-x-2">
                <button 
                  type="button" 
                  onClick={() => setIsAddMilestoneOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-gray-600 hover:bg-gray-100 rounded-xl"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="px-5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-md shadow-indigo-100 transition-all flex items-center gap-1.5"
                >
                  <i className="fa-solid fa-check text-xs"></i>
                  {editingMilestone ? 'Save Changes' : 'Create Milestone'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};

// --- Projects View ---
export const ProjectsView: React.FC = () => {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [projects, setProjects] = useState<Project[]>(PROJECTS);

  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');

  // New Project Form State
  const [newTitle, setNewTitle] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newCategory, setNewCategory] = useState('Web App');
  const [newStatus, setNewStatus] = useState<Project['status']>('In Progress');
  const [newColor, setNewColor] = useState('bg-indigo-500');

  const colorOptions = [
    { label: 'Indigo', value: 'bg-indigo-500' },
    { label: 'Blue', value: 'bg-blue-500' },
    { label: 'Purple', value: 'bg-purple-500' },
    { label: 'Pink', value: 'bg-pink-500' },
    { label: 'Emerald', value: 'bg-emerald-500' },
    { label: 'Orange', value: 'bg-orange-500' },
    { label: 'Slate', value: 'bg-slate-700' },
  ];

  const handleUpdateProject = (updated: Project) => {
    setProjects(projects.map(p => p.id === updated.id ? updated : p));
    setSelectedProject(updated);
  };

  const handleCreateProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const newProject: Project = {
      id: Date.now(),
      title: newTitle.trim(),
      description: newDescription.trim() || 'Custom UX design project initialized with AI agents, files, timeline, and team roster.',
      category: newCategory,
      status: newStatus,
      color: newColor,
      date: 'Just now',
      progress: 15,
      screensCount: 1,
      componentsCount: 4,
      files: [
        {
          id: `f-${Date.now()}-1`,
          name: `${newTitle.trim().replace(/\s+/g, '_')}_Master.fig`,
          type: 'Figma',
          size: '12.4 MB',
          date: 'Just now',
          createdBy: 'You'
        },
        {
          id: `f-${Date.now()}-2`,
          name: 'Project_Design_Brief.md',
          type: 'Markdown',
          size: '48 KB',
          date: 'Just now',
          createdBy: 'You',
          contentSnippet: `Initial project brief for ${newTitle.trim()} (${newCategory}).`
        },
        {
          id: `f-${Date.now()}-3`,
          name: 'Design_Tokens.json',
          type: 'JSON',
          size: '34 KB',
          date: 'Just now',
          createdBy: 'UX Documenter Agent',
          isAIGenerated: true,
          contentSnippet: 'Generated initial color, spacing, and typography tokens.'
        }
      ],
      recentActivity: [
        {
          id: `act-${Date.now()}-1`,
          actor: 'You',
          actorType: 'user',
          avatar: 'https://picsum.photos/40/40?random=99',
          action: `created new project "${newTitle.trim()}"`,
          time: 'Just now',
          details: `Initialized with ${newCategory} category and standard design system workspace.`
        },
        {
          id: `act-${Date.now()}-2`,
          actor: 'UX Documenter',
          actorType: 'agent',
          icon: 'fa-file-lines',
          action: 'generated initial design tokens & brief template',
          time: 'Just now'
        }
      ],
      agentResults: [
        {
          id: `res-${Date.now()}-1`,
          agentName: 'UX Design Reviewer',
          agentIcon: 'fa-magnifying-glass-chart',
          agentBg: 'bg-gradient-to-br from-indigo-500 to-purple-600',
          runDate: 'Just now',
          summary: 'Scanned initial requirements and generated recommended UX checklist.',
          status: 'Completed',
          fullResult: `### Initial UX Checklist: ${newTitle.trim()}\n\n1. Define primary user personas.\n2. Map key conversion paths.\n3. Verify WCAG AA color accessibility.`
        }
      ],
      teamMembers: [
        {
          id: `m-${Date.now()}-1`,
          name: 'You',
          role: 'Lead Product Designer',
          avatar: 'https://picsum.photos/40/40?random=99',
          email: 'you@company.design',
          status: 'Active',
          tasksCount: 3
        }
      ],
      timeline: [
        {
          id: `t-${Date.now()}-1`,
          phase: 'Phase 1',
          title: 'Research & Discovery',
          description: 'Market research, user interviews, and competitive analysis',
          status: 'In Progress',
          startDate: 'This Week',
          dueDate: 'Next Week',
          progress: 35,
          deliverables: ['User Personas', 'Problem Statement Document']
        },
        {
          id: `t-${Date.now()}-2`,
          phase: 'Phase 2',
          title: 'Information Architecture & Wireframes',
          description: 'User flows, wireframe schemas, and navigation maps',
          status: 'Upcoming',
          startDate: 'In 2 weeks',
          dueDate: 'In 3 weeks',
          progress: 0,
          deliverables: ['Wireframe Layouts', 'Low-Fi Prototype']
        },
        {
          id: `t-${Date.now()}-3`,
          phase: 'Phase 3',
          title: 'High-Fidelity UI & Tokens',
          description: 'Component system, responsive UI screens, and tokens',
          status: 'Upcoming',
          startDate: 'In 4 weeks',
          dueDate: 'In 5 weeks',
          progress: 0,
          deliverables: ['Figma Design System', 'Component Specs']
        },
        {
          id: `t-${Date.now()}-4`,
          phase: 'Phase 4',
          title: 'Testing & Developer Hand-off',
          description: 'UAT testing, usability reviews, and asset hand-off',
          status: 'Upcoming',
          startDate: 'In 6 weeks',
          dueDate: 'In 7 weeks',
          progress: 0,
          deliverables: ['UAT Test Suite', 'Production Assets Export']
        }
      ]
    };

    setProjects([newProject, ...projects]);
    setIsCreateModalOpen(false);

    // Reset Form
    setNewTitle('');
    setNewDescription('');
    setNewCategory('Web App');
    setNewStatus('In Progress');
    setNewColor('bg-indigo-500');
  };

  if (selectedProject) {
    return (
      <ProjectDetailView 
        project={selectedProject} 
        onBack={() => setSelectedProject(null)} 
        onUpdateProject={handleUpdateProject}
      />
    );
  }

  const filteredProjects = projects.filter(project => {
    const matchesSearch = project.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          (project.description && project.description.toLowerCase().includes(searchQuery.toLowerCase())) ||
                          (project.category && project.category.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesStatus = statusFilter === 'All' || project.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <ViewLayout 
      title="Projects" 
      description="Active design projects, prototypes, AI deliverables, and team workspaces."
      action={
        <div className="flex items-center gap-3">
          <button 
            id="create-new-project-btn"
            onClick={() => setIsCreateModalOpen(true)}
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2.5 rounded-xl text-sm font-semibold flex items-center shadow-md shadow-indigo-200 transition-all hover:scale-[1.02] active:scale-[0.98]"
          >
            <i className="fa-solid fa-plus mr-2 text-xs"></i>
            Create New
          </button>
        </div>
      }
    >
        {/* Controls & Filter Bar */}
        <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4 bg-white p-2.5 rounded-xl border border-gray-200 shadow-sm">
          <div className="flex items-center overflow-x-auto w-full md:w-auto pb-1 md:pb-0 scrollbar-hide px-1 gap-1">
            {['All', 'In Progress', 'Review', 'Planning', 'Completed'].map((status) => (
              <button 
                key={status}
                onClick={() => setStatusFilter(status)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                  statusFilter === status 
                    ? 'bg-gray-900 text-white shadow-sm' 
                    : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
                }`}
              >
                {status}
              </button>
            ))}
          </div>

          <div className="relative w-full md:w-72 px-1">
            <input 
              type="text" 
              placeholder="Search projects by title or category..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-1.5 bg-gray-50 border border-gray-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
            />
            <i className="fa-solid fa-search absolute left-3.5 top-2.5 text-gray-400 text-xs"></i>
            {searchQuery && (
              <button onClick={() => setSearchQuery('')} className="absolute right-3 top-2 text-gray-400 hover:text-gray-600 text-xs">
                <i className="fa-solid fa-times"></i>
              </button>
            )}
          </div>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProjects.map((project, idx) => (
                <div 
                    key={project.id || idx} 
                    onClick={() => setSelectedProject(project)}
                    className="bg-white rounded-2xl border border-gray-200 overflow-hidden hover:shadow-xl hover:border-indigo-300 transition-all cursor-pointer group flex flex-col justify-between"
                >
                    <div>
                      {/* Card Cover Banner */}
                      <div className={`h-32 ${project.color} bg-opacity-20 relative overflow-hidden`}>
                          <div className={`absolute inset-0 ${project.color} opacity-30`}></div>
                          <div className="absolute inset-0 flex items-center justify-center">
                              <i className="fa-solid fa-folder-open text-4xl text-white opacity-70 group-hover:scale-110 transition-transform"></i>
                          </div>
                          {project.category && (
                            <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-sm px-2.5 py-0.5 rounded-md text-[10px] font-bold text-gray-800 uppercase tracking-wider shadow-sm">
                              {project.category}
                            </div>
                          )}
                          <span className={`absolute top-3 right-3 text-[10px] font-bold px-2 py-0.5 rounded-full shadow-sm ${
                            project.status === 'Completed' ? 'bg-green-100 text-green-700' : 
                            project.status === 'Review' ? 'bg-purple-100 text-purple-700' :
                            project.status === 'Planning' ? 'bg-amber-100 text-amber-700' :
                            'bg-blue-100 text-blue-700'
                          }`}>
                            {project.status}
                          </span>
                      </div>

                      {/* Card Content */}
                      <div className="p-5">
                        <div className="flex justify-between items-start mb-1.5">
                            <h3 className="font-extrabold text-gray-900 group-hover:text-indigo-600 transition-colors text-base line-clamp-1">{project.title}</h3>
                            <i className="fa-solid fa-ellipsis text-gray-400 hover:text-gray-600 p-1"></i>
                        </div>
                        <p className="text-xs text-gray-600 mb-4 line-clamp-2 leading-relaxed">{project.description}</p>

                        {/* All 5 Elements Counters Badge Bar */}
                        <div className="grid grid-cols-3 gap-2 p-2.5 bg-gray-50 rounded-xl mb-4 text-[11px] font-semibold text-gray-600">
                          <div className="text-center">
                            <div className="text-gray-900 font-bold">{project.files?.length || 0}</div>
                            <div className="text-[10px] text-gray-400">Files</div>
                          </div>
                          <div className="text-center border-x border-gray-200">
                            <div className="text-purple-600 font-bold">{project.agentResults?.length || 0}</div>
                            <div className="text-[10px] text-gray-400">AI Results</div>
                          </div>
                          <div className="text-center">
                            <div className="text-indigo-600 font-bold">{project.progress || 0}%</div>
                            <div className="text-[10px] text-gray-400">Timeline</div>
                          </div>
                        </div>

                        {/* Recent Activity snippet */}
                        {project.recentActivity && project.recentActivity[0] && (
                          <div className="text-[11px] text-gray-500 bg-indigo-50/40 p-2 rounded-lg mb-3 flex items-center space-x-1.5 truncate">
                            <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 flex-shrink-0"></span>
                            <span className="truncate"><strong>{project.recentActivity[0].actor}:</strong> {project.recentActivity[0].action}</span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Card Footer: Team avatars and date */}
                    <div className="px-5 py-3 border-t border-gray-100 bg-gray-50/50 flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="flex -space-x-2">
                          {(project.teamMembers || []).slice(0, 3).map((m, i) => (
                            <img key={i} src={m.avatar} className="w-6 h-6 rounded-full border-2 border-white object-cover" alt={m.name} title={`${m.name} (${m.role})`} />
                          ))}
                        </div>
                        <span className="text-[11px] text-gray-400 font-medium">
                          {(project.teamMembers || []).length} members
                        </span>
                      </div>
                      <span className="text-[11px] text-gray-400">{project.date}</span>
                    </div>
                </div>
            ))}

            {/* Quick Create Card in Grid */}
            <div 
                onClick={() => setIsCreateModalOpen(true)}
                className="border-2 border-dashed border-gray-200 rounded-2xl p-8 flex flex-col items-center justify-center cursor-pointer hover:border-indigo-300 hover:bg-indigo-50/50 transition-all text-gray-400 hover:text-indigo-600 group min-h-[300px]"
            >
                <div className="w-14 h-14 rounded-2xl bg-gray-100 group-hover:bg-indigo-100 flex items-center justify-center mb-3 transition-colors shadow-sm">
                  <i className="fa-solid fa-plus text-xl text-gray-400 group-hover:text-indigo-600 transition-colors"></i>
                </div>
                <span className="font-bold text-sm text-gray-800 group-hover:text-indigo-600 mb-1">Create New Project</span>
                <span className="text-xs text-gray-400 text-center max-w-xs">Includes files, activity, AI agents, team, and timeline roadmap</span>
            </div>
        </div>

        {/* Create Project Modal */}
        {isCreateModalOpen && (
          <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 backdrop-blur-sm p-4 animate-in fade-in duration-200">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden transform transition-all border border-gray-100">
              <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50/80">
                <div className="flex items-center space-x-2.5">
                  <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-600 flex items-center justify-center">
                    <i className="fa-solid fa-folder-plus text-sm"></i>
                  </div>
                  <h3 className="text-lg font-bold text-gray-900">Create New Project</h3>
                </div>
                <button 
                  onClick={() => setIsCreateModalOpen(false)}
                  className="w-8 h-8 rounded-lg flex items-center justify-center text-gray-400 hover:text-gray-600 hover:bg-gray-100 transition-colors"
                >
                  <i className="fa-solid fa-times text-base"></i>
                </button>
              </div>

              <form onSubmit={handleCreateProject} className="p-6 space-y-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1.5">
                    Project Title *
                  </label>
                  <input 
                    type="text" 
                    required
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    placeholder="e.g., Mobile Banking App V2"
                    className="w-full px-3.5 py-2.5 border border-gray-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1.5">
                    Description
                  </label>
                  <textarea 
                    rows={2}
                    value={newDescription}
                    onChange={(e) => setNewDescription(e.target.value)}
                    placeholder="Brief summary of the project goals, audience, and scope..."
                    className="w-full px-3.5 py-2.5 border border-gray-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all resize-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1.5">
                      Category
                    </label>
                    <select 
                      value={newCategory}
                      onChange={(e) => setNewCategory(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                    >
                      <option value="Web App">Web App</option>
                      <option value="Mobile iOS">Mobile iOS</option>
                      <option value="Mobile Android">Mobile Android</option>
                      <option value="Design System">Design System</option>
                      <option value="Marketing">Marketing</option>
                      <option value="UX Research">UX Research</option>
                      <option value="Admin Suite">Admin Suite</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1.5">
                      Status
                    </label>
                    <select 
                      value={newStatus}
                      onChange={(e) => setNewStatus(e.target.value as any)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                    >
                      <option value="Planning">Planning</option>
                      <option value="In Progress">In Progress</option>
                      <option value="Review">Review</option>
                      <option value="Completed">Completed</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1.5">
                    Accent Color
                  </label>
                  <div className="flex items-center gap-2.5">
                    {colorOptions.map((c) => (
                      <button
                        key={c.value}
                        type="button"
                        onClick={() => setNewColor(c.value)}
                        className={`w-7 h-7 rounded-full ${c.value} transition-transform flex items-center justify-center ${
                          newColor === c.value ? 'ring-2 ring-offset-2 ring-indigo-600 scale-110' : 'hover:scale-105'
                        }`}
                        title={c.label}
                      >
                        {newColor === c.value && <i className="fa-solid fa-check text-white text-[10px]"></i>}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="pt-4 border-t border-gray-100 flex items-center justify-end space-x-3">
                  <button 
                    type="button"
                    onClick={() => setIsCreateModalOpen(false)}
                    className="px-4 py-2 text-sm font-medium text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-xl transition-colors"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    className="px-5 py-2 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-md shadow-indigo-200 transition-all"
                  >
                    Create Project
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
    </ViewLayout>
  );
};

// --- Analytics View ---
export const AnalyticsView: React.FC = () => (
    <ViewLayout title="Analytics" description="Insights into your design system usage and AI performance.">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm h-80">
          <h3 className="text-lg font-bold text-gray-900 mb-4">AI Success Rate</h3>
          <PerformanceChart />
        </div>
        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm h-80">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Daily Output</h3>
          <OutputChart />
        </div>
      </div>
      <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
         <h3 className="text-lg font-bold text-gray-900 mb-4">Detailed Metrics</h3>
         <table className="min-w-full">
            <thead>
                <tr className="border-b border-gray-100 text-left">
                    <th className="pb-3 text-xs font-semibold text-gray-500 uppercase">Metric</th>
                    <th className="pb-3 text-xs font-semibold text-gray-500 uppercase">Current</th>
                    <th className="pb-3 text-xs font-semibold text-gray-500 uppercase">Previous</th>
                    <th className="pb-3 text-xs font-semibold text-gray-500 uppercase">Change</th>
                </tr>
            </thead>
            <tbody className="text-sm">
                {[
                    { name: "Components Generated", current: "1,240", prev: "980", change: "+26%" },
                    { name: "Time Saved (Hours)", current: "142", prev: "110", change: "+29%" },
                    { name: "User Satisfaction", current: "4.8/5", prev: "4.6/5", change: "+4%" },
                    { name: "Design Consistency Score", current: "92%", prev: "85%", change: "+7%" },
                ].map((row, idx) => (
                    <tr key={idx} className="border-b border-gray-50 last:border-0 hover:bg-gray-50">
                        <td className="py-3 font-medium text-gray-900">{row.name}</td>
                        <td className="py-3 text-gray-600">{row.current}</td>
                        <td className="py-3 text-gray-400">{row.prev}</td>
                        <td className="py-3 text-green-600">{row.change}</td>
                    </tr>
                ))}
            </tbody>
         </table>
      </div>
    </ViewLayout>
);

// --- Auto-Generate View ---
export const AutoGenerateView: React.FC = () => (
    <ViewLayout title="Auto-Generate" description="Generate UI designs and components from text descriptions.">
        <div className="flex flex-col lg:flex-row gap-6 h-[calc(100vh-200px)]">
            <div className="w-full lg:w-1/3 flex flex-col gap-4">
                 <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm flex-grow flex flex-col">
                    <h3 className="text-sm font-bold text-gray-900 mb-3">Prompt</h3>
                    <textarea 
                        className="w-full flex-grow bg-gray-50 border border-gray-200 rounded-lg p-4 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none mb-4" 
                        placeholder="Describe the UI you want to generate. E.g., 'A mobile login screen with social auth buttons and a gradient background'."
                    ></textarea>
                     <h3 className="text-sm font-bold text-gray-900 mb-3">Settings</h3>
                     <div className="space-y-3 mb-6">
                        <select className="w-full bg-gray-50 border border-gray-200 rounded-lg p-2.5 text-sm">
                            <option>Style: Modern Minimal</option>
                            <option>Style: Brutalist</option>
                            <option>Style: Glassmorphism</option>
                        </select>
                        <select className="w-full bg-gray-50 border border-gray-200 rounded-lg p-2.5 text-sm">
                            <option>Device: Mobile (iOS)</option>
                            <option>Device: Desktop</option>
                            <option>Device: Tablet</option>
                        </select>
                     </div>
                    <button className="w-full bg-indigo-600 text-white py-3 rounded-lg font-medium hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-200">
                        <i className="fa-solid fa-wand-magic-sparkles mr-2"></i>
                        Generate Design
                    </button>
                 </div>
            </div>
            <div className="w-full lg:w-2/3 bg-gray-100 rounded-xl border border-gray-200 flex items-center justify-center relative overflow-hidden">
                <div className="absolute inset-0 grid grid-cols-[repeat(20,minmax(0,1fr))] grid-rows-[repeat(20,minmax(0,1fr))] opacity-5">
                     {[...Array(400)].map((_, i) => <div key={i} className="border-r border-b border-gray-400"></div>)}
                </div>
                <div className="text-center p-8 bg-white/50 backdrop-blur-sm rounded-2xl border border-white/50 shadow-xl">
                    <div className="w-16 h-16 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl">
                         <i className="fa-solid fa-image"></i>
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900">Ready to Create</h3>
                    <p className="text-gray-500 mt-2 max-w-sm">Enter your prompt on the left to start generating high-fidelity UI designs instantly.</p>
                </div>
            </div>
        </div>
    </ViewLayout>
);

// --- Suggestions View ---
export const SuggestionsView: React.FC = () => (
    <ViewLayout title="Design Suggestions" description="AI-powered improvements for your current projects.">
        <div className="space-y-4">
             {[
                 { title: "Contrast Issue Detected", desc: "The primary button text has insufficient contrast ratio (3.5:1). Recommended: #FFFFFF.", type: "Accessibility", color: "text-red-600 bg-red-50", icon: "fa-eye" },
                 { title: "Inconsistent Spacing", desc: "Card padding varies between 16px and 24px. Standardize to 20px.", type: "Layout", color: "text-orange-600 bg-orange-50", icon: "fa-ruler-combined" },
                 { title: "Typo in Header", desc: "Found potential typo 'Desing' in the main hero section.", type: "Content", color: "text-yellow-600 bg-yellow-50", icon: "fa-spell-check" },
             ].map((item, idx) => (
                 <div key={idx} className="bg-white p-5 rounded-xl border border-gray-200 flex items-start space-x-4 shadow-sm">
                     <div className={`w-10 h-10 rounded-lg ${item.color} flex items-center justify-center flex-shrink-0`}>
                         <i className={`fa-solid ${item.icon}`}></i>
                     </div>
                     <div className="flex-grow">
                         <div className="flex justify-between items-start">
                             <h3 className="text-base font-bold text-gray-900">{item.title}</h3>
                             <button className="text-indigo-600 text-sm font-medium hover:underline">Apply Fix</button>
                         </div>
                         <p className="text-sm text-gray-600 mt-1">{item.desc}</p>
                         <span className="inline-block mt-2 text-xs font-medium text-gray-400 bg-gray-50 px-2 py-1 rounded">
                             {item.type}
                         </span>
                     </div>
                 </div>
             ))}
        </div>
    </ViewLayout>
);

// ==========================================
// --- KNOWLEDGE VIEW (Documents, Whiteboards & Frameworks) ---
// ==========================================
interface KnowledgeViewProps {
  onNavigateToAgents?: () => void;
}

export const KnowledgeView: React.FC<KnowledgeViewProps> = ({ onNavigateToAgents }) => {
  const [items, setItems] = useState<KnowledgeItem[]>(KNOWLEDGE_ITEMS);
  const [activeType, setActiveType] = useState<'all' | 'document' | 'whiteboard' | 'framework'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [sortBy, setSortBy] = useState<'recent' | 'title' | 'popular'>('recent');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  // Modals & Inspectors
  const [selectedDocument, setSelectedDocument] = useState<KnowledgeItem | null>(null);
  const [selectedWhiteboard, setSelectedWhiteboard] = useState<KnowledgeItem | null>(null);
  const [selectedFramework, setSelectedFramework] = useState<KnowledgeItem | null>(null);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Whiteboard In-Modal Sticky Creation state
  const [newStickyText, setNewStickyText] = useState<{ [colName: string]: string }>({});
  const [newStickyColor, setNewStickyColor] = useState<'yellow' | 'pink' | 'blue' | 'green' | 'purple' | 'orange'>('yellow');

  // New Knowledge Item Form state
  const [newItemType, setNewItemType] = useState<KnowledgeType>('document');
  const [newItemTitle, setNewItemTitle] = useState('');
  const [newItemCategory, setNewItemCategory] = useState('Design System');
  const [newItemDescription, setNewItemDescription] = useState('');
  const [newItemTags, setNewItemTags] = useState('Tokens, Accessibility');
  const [newItemFormat, setNewItemFormat] = useState<'Markdown' | 'Spec' | 'Guide' | 'Report'>('Spec');
  const [newItemContent, setNewItemContent] = useState('# New Design Document\n\n## Overview\nEnter detailed specification here...');
  const [newItemCanvasType, setNewItemCanvasType] = useState<'User Journey' | 'Affinity Map' | 'Sprint Board' | 'Mind Map' | 'Architecture'>('Affinity Map');

  // Extract unique categories
  const categories = ['All', ...Array.from(new Set(items.map(item => item.category)))];

  // Counts
  const countAll = items.length;
  const countDocs = items.filter(i => i.type === 'document').length;
  const countWhiteboards = items.filter(i => i.type === 'whiteboard').length;
  const countFrameworks = items.filter(i => i.type === 'framework').length;

  // Filter & Sort
  const filteredItems = items
    .filter(item => {
      if (activeType !== 'all' && item.type !== activeType) return false;
      if (selectedCategory !== 'All' && item.category !== selectedCategory) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchTitle = item.title.toLowerCase().includes(q);
        const matchDesc = item.description.toLowerCase().includes(q);
        const matchCategory = item.category.toLowerCase().includes(q);
        const matchAuthor = item.author.name.toLowerCase().includes(q);
        const matchTags = item.tags.some(t => t.toLowerCase().includes(q));
        const matchContent = item.documentContent?.toLowerCase().includes(q) || false;
        if (!matchTitle && !matchDesc && !matchCategory && !matchAuthor && !matchTags && !matchContent) {
          return false;
        }
      }
      return true;
    })
    .sort((a, b) => {
      if (sortBy === 'title') {
        return a.title.localeCompare(b.title);
      }
      if (sortBy === 'popular') {
        const popA = (a.stickyCount || 0) + (a.isFeatured ? 20 : 0);
        const popB = (b.stickyCount || 0) + (b.isFeatured ? 20 : 0);
        return popB - popA;
      }
      return 0; // recent preserves default array order
    });

  const isFiltered = activeType !== 'all' || selectedCategory !== 'All' || searchQuery.trim() !== '' || sortBy !== 'recent';

  // Copy helper
  const handleCopyContent = (text: string, id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => {
      setCopiedId(prev => prev === id ? null : prev);
    }, 2000);
  };

  // Upvote sticky note in active whiteboard
  const handleVoteSticky = (whiteboardId: string, stickyId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setItems(prevItems =>
      prevItems.map(item => {
        if (item.id === whiteboardId && item.stickyNotes) {
          const updatedStickyNotes = item.stickyNotes.map(sn =>
            sn.id === stickyId ? { ...sn, votes: (sn.votes || 0) + 1 } : sn
          );
          return { ...item, stickyNotes: updatedStickyNotes };
        }
        return item;
      })
    );

    // Also update selected modal if open
    setSelectedWhiteboard(prev => {
      if (!prev || prev.id !== whiteboardId || !prev.stickyNotes) return prev;
      return {
        ...prev,
        stickyNotes: prev.stickyNotes.map(sn =>
          sn.id === stickyId ? { ...sn, votes: (sn.votes || 0) + 1 } : sn
        )
      };
    });
  };

  // Add sticky note to whiteboard column
  const handleAddStickyNote = (whiteboardId: string, column: string) => {
    const text = (newStickyText[column] || '').trim();
    if (!text) return;

    const newNote: StickyNote = {
      id: `sn-${Date.now()}`,
      color: newStickyColor,
      text,
      author: 'You (Designer)',
      column,
      votes: 1
    };

    setItems(prevItems =>
      prevItems.map(item => {
        if (item.id === whiteboardId) {
          const currentNotes = item.stickyNotes || [];
          return {
            ...item,
            stickyCount: (item.stickyCount || currentNotes.length) + 1,
            stickyNotes: [...currentNotes, newNote]
          };
        }
        return item;
      })
    );

    setSelectedWhiteboard(prev => {
      if (!prev || prev.id !== whiteboardId) return prev;
      const currentNotes = prev.stickyNotes || [];
      return {
        ...prev,
        stickyCount: (prev.stickyCount || currentNotes.length) + 1,
        stickyNotes: [...currentNotes, newNote]
      };
    });

    setNewStickyText(prev => ({ ...prev, [column]: '' }));
  };

  // Create new knowledge item
  const handleCreateKnowledgeItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemTitle.trim()) return;

    const parsedTags = newItemTags.split(',').map(t => t.trim()).filter(Boolean);

    let createdItem: KnowledgeItem;

    if (newItemType === 'document') {
      createdItem = {
        id: `doc-${Date.now()}`,
        type: 'document',
        title: newItemTitle.trim(),
        description: newItemDescription.trim() || 'Comprehensive design specification and guidelines.',
        category: newItemCategory,
        author: {
          name: 'You (Workspace Lead)',
          avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
          role: 'Staff Product Designer'
        },
        updatedAt: 'Just now',
        tags: parsedTags.length > 0 ? parsedTags : ['Custom', 'Documentation'],
        isFeatured: false,
        readTime: '4 min read',
        documentFormat: newItemFormat,
        documentContent: newItemContent.trim()
      };
    } else if (newItemType === 'whiteboard') {
      const defaultCols = ['Backlog & Context', 'User Pain Points', 'Opportunities', 'Action Items'];
      createdItem = {
        id: `wb-${Date.now()}`,
        type: 'whiteboard',
        title: newItemTitle.trim(),
        description: newItemDescription.trim() || 'Collaborative whiteboard canvas for cross-functional alignment.',
        category: newItemCategory,
        author: {
          name: 'You (Workspace Lead)',
          avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
          role: 'Staff Product Designer'
        },
        updatedAt: 'Just now',
        tags: parsedTags.length > 0 ? parsedTags : ['Whiteboard', 'Workshop'],
        isFeatured: false,
        stickyCount: 4,
        collaboratorsCount: 1,
        canvasType: newItemCanvasType,
        boardColumns: defaultCols,
        stickyNotes: [
          { id: `sn-${Date.now()}-1`, color: 'yellow', text: 'Initial problem discovery notes', author: 'You', column: defaultCols[0], votes: 1 },
          { id: `sn-${Date.now()}-2`, color: 'pink', text: 'Identified friction in customer handoff', author: 'You', column: defaultCols[1], votes: 1 },
          { id: `sn-${Date.now()}-3`, color: 'green', text: 'Automate verification via AI agent', author: 'You', column: defaultCols[2], votes: 2 },
          { id: `sn-${Date.now()}-4`, color: 'blue', text: 'Schedule prototype validation test', author: 'You', column: defaultCols[3], votes: 1 }
        ]
      };
    } else {
      createdItem = {
        id: `fw-${Date.now()}`,
        type: 'framework',
        title: newItemTitle.trim(),
        description: newItemDescription.trim() || 'Standardized UX methodology for research and evaluation.',
        category: newItemCategory,
        author: {
          name: 'You (Workspace Lead)',
          avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
          role: 'Staff Product Designer'
        },
        updatedAt: 'Just now',
        tags: parsedTags.length > 0 ? parsedTags : ['Framework', 'Methodology'],
        isFeatured: false,
        frameworkCategory: 'Methodology',
        stepsCount: 3,
        recommendedAgents: ['UX Design Reviewer', 'User Persona Generator'],
        templateSnippet: `### ${newItemTitle.trim()}\n1. Phase 1: Exploration & Context\n2. Phase 2: Design Execution\n3. Phase 3: Deliverable Verification`,
        steps: [
          { title: '1. Problem Formulation', description: 'Define the boundary and success metrics for the design exercise.', deliverables: ['Context Brief'] },
          { title: '2. Solution Generation', description: 'Synthesize interactive variants using our design tokens.', deliverables: ['Wireframe Mocks'] },
          { title: '3. Quality Verification', description: 'Run heuristic checks to ensure accessibility and token compliance.', deliverables: ['Review Audit'] }
        ]
      };
    }

    setItems([createdItem, ...items]);
    setIsCreateModalOpen(false);

    // Reset inputs
    setNewItemTitle('');
    setNewItemDescription('');
    setNewItemTags('Tokens, Accessibility');

    // Automatically inspect the newly created item
    if (createdItem.type === 'document') setSelectedDocument(createdItem);
    else if (createdItem.type === 'whiteboard') setSelectedWhiteboard(createdItem);
    else setSelectedFramework(createdItem);
  };

  // Delete item
  const handleDeleteItem = (itemId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (window.confirm('Are you sure you want to delete this knowledge artifact?')) {
      setItems(prev => prev.filter(i => i.id !== itemId));
      if (selectedDocument?.id === itemId) setSelectedDocument(null);
      if (selectedWhiteboard?.id === itemId) setSelectedWhiteboard(null);
      if (selectedFramework?.id === itemId) setSelectedFramework(null);
    }
  };

  const getStickyColorClass = (color: StickyNote['color']) => {
    switch (color) {
      case 'yellow': return 'bg-amber-100 text-amber-950 border-amber-300 shadow-amber-200/50';
      case 'pink': return 'bg-rose-100 text-rose-950 border-rose-300 shadow-rose-200/50';
      case 'green': return 'bg-emerald-100 text-emerald-950 border-emerald-300 shadow-emerald-200/50';
      case 'blue': return 'bg-sky-100 text-sky-950 border-sky-300 shadow-sky-200/50';
      case 'purple': return 'bg-purple-100 text-purple-950 border-purple-300 shadow-purple-200/50';
      case 'orange': return 'bg-orange-100 text-orange-950 border-orange-300 shadow-orange-200/50';
      default: return 'bg-amber-100 text-amber-950 border-amber-300 shadow-amber-200/50';
    }
  };

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 space-y-6">
      {/* Top Banner & Header */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-purple-950 rounded-3xl p-6 sm:p-8 text-white relative overflow-hidden shadow-xl border border-indigo-900/40">
        <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-radial from-purple-500/20 to-transparent pointer-events-none"></div>
        <div className="absolute -right-8 -bottom-8 text-white/5 text-9xl font-black pointer-events-none select-none">
          <i className="fa-solid fa-brain"></i>
        </div>

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="max-w-2xl">
            <div className="flex items-center space-x-2.5 mb-2.5">
              <span className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-purple-500/30 text-purple-200 border border-purple-400/30 flex items-center gap-1.5 backdrop-blur-md">
                <i className="fa-solid fa-sparkles text-[10px] text-amber-300"></i>
                Knowledge Hub
              </span>
              <span className="text-xs text-indigo-300/80 font-medium">
                {countAll} Total Artifacts
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
              Documents, Whiteboards & Frameworks
            </h1>
            <p className="text-sm text-indigo-200/80 mt-2 leading-relaxed">
              Explore standardized design specifications, collaborative journey whiteboards, and proven UX methodologies. Connect your artifacts directly with intelligent design agents.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => setIsCreateModalOpen(true)}
              className="px-4 py-2.5 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white font-semibold text-xs rounded-xl shadow-lg shadow-indigo-500/30 flex items-center gap-2 transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              <i className="fa-solid fa-plus text-xs"></i>
              <span>Create Knowledge Item</span>
            </button>
          </div>
        </div>

        {/* Primary Type Pills / Navigation Bar */}
        <div className="relative z-10 mt-8 pt-6 border-t border-white/10 flex flex-wrap items-center gap-2">
          <button
            onClick={() => setActiveType('all')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
              activeType === 'all'
                ? 'bg-white text-gray-900 shadow-md shadow-white/10'
                : 'bg-white/10 text-white/80 hover:bg-white/15 hover:text-white'
            }`}
          >
            <i className="fa-solid fa-shapes text-xs"></i>
            <span>All Knowledge</span>
            <span className={`px-2 py-0.5 rounded-full text-[10px] ${
              activeType === 'all' ? 'bg-indigo-100 text-indigo-800' : 'bg-white/20 text-white'
            }`}>
              {countAll}
            </span>
          </button>

          <button
            onClick={() => setActiveType('document')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
              activeType === 'document'
                ? 'bg-white text-gray-900 shadow-md shadow-white/10'
                : 'bg-white/10 text-white/80 hover:bg-white/15 hover:text-white'
            }`}
          >
            <i className="fa-solid fa-file-lines text-xs text-indigo-400"></i>
            <span>Documents</span>
            <span className={`px-2 py-0.5 rounded-full text-[10px] ${
              activeType === 'document' ? 'bg-indigo-100 text-indigo-800' : 'bg-white/20 text-white'
            }`}>
              {countDocs}
            </span>
          </button>

          <button
            onClick={() => setActiveType('whiteboard')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
              activeType === 'whiteboard'
                ? 'bg-white text-gray-900 shadow-md shadow-white/10'
                : 'bg-white/10 text-white/80 hover:bg-white/15 hover:text-white'
            }`}
          >
            <i className="fa-solid fa-chalkboard text-xs text-emerald-400"></i>
            <span>Whiteboards</span>
            <span className={`px-2 py-0.5 rounded-full text-[10px] ${
              activeType === 'whiteboard' ? 'bg-emerald-100 text-emerald-800' : 'bg-white/20 text-white'
            }`}>
              {countWhiteboards}
            </span>
          </button>

          <button
            onClick={() => setActiveType('framework')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
              activeType === 'framework'
                ? 'bg-white text-gray-900 shadow-md shadow-white/10'
                : 'bg-white/10 text-white/80 hover:bg-white/15 hover:text-white'
            }`}
          >
            <i className="fa-solid fa-cubes-stacked text-xs text-amber-400"></i>
            <span>Frameworks</span>
            <span className={`px-2 py-0.5 rounded-full text-[10px] ${
              activeType === 'framework' ? 'bg-amber-100 text-amber-800' : 'bg-white/20 text-white'
            }`}>
              {countFrameworks}
            </span>
          </button>
        </div>
      </div>

      {/* Filter, Search & View Controls Bar */}
      <div className="bg-white p-4 rounded-2xl border border-gray-200 shadow-sm space-y-3">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          {/* Search Box */}
          <div className="relative flex-1">
            <i className="fa-solid fa-magnifying-glass absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 text-xs"></i>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search documents, whiteboards, frameworks, tags, or authors..."
              className="w-full pl-9 pr-8 py-2 bg-gray-50 border border-gray-200 rounded-xl text-xs text-gray-800 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 text-xs p-1"
              >
                <i className="fa-solid fa-circle-xmark"></i>
              </button>
            )}
          </div>

          {/* Selectors and View Toggle */}
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Category Filter */}
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-semibold text-gray-500 hidden sm:inline">Category:</span>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-xs font-medium text-gray-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 max-w-[150px] truncate"
              >
                {categories.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>

            {/* Sort Order */}
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-semibold text-gray-500 hidden sm:inline">Sort:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-xs font-medium text-gray-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="recent">Recently Updated</option>
                <option value="title">Alphabetical (A-Z)</option>
                <option value="popular">Most Engaged</option>
              </select>
            </div>

            {/* Grid vs List Toggle */}
            <div className="flex items-center bg-gray-100 p-0.5 rounded-xl border border-gray-200 ml-auto sm:ml-0">
              <button
                onClick={() => setViewMode('grid')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                  viewMode === 'grid'
                    ? 'bg-white text-gray-900 shadow-xs'
                    : 'text-gray-500 hover:text-gray-900'
                }`}
                title="Grid Cards"
              >
                <i className="fa-solid fa-table-cells-large text-xs"></i>
                <span className="hidden sm:inline">Grid</span>
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                  viewMode === 'list'
                    ? 'bg-white text-gray-900 shadow-xs'
                    : 'text-gray-500 hover:text-gray-900'
                }`}
                title="Table List"
              >
                <i className="fa-solid fa-list text-xs"></i>
                <span className="hidden sm:inline">List</span>
              </button>
            </div>
          </div>
        </div>

        {/* Status Count and Reset */}
        <div className="flex items-center justify-between text-xs text-gray-500 pt-2 border-t border-gray-100">
          <div className="flex items-center gap-2">
            <span>
              Showing <strong>{filteredItems.length}</strong> of {items.length} artifacts
              {activeType !== 'all' && (
                <span className="text-indigo-600 font-semibold ml-1">({activeType}s)</span>
              )}
            </span>
            {isFiltered && (
              <span className="text-purple-600 font-medium">(Filtered)</span>
            )}
          </div>

          {isFiltered && (
            <button
              onClick={() => {
                setActiveType('all');
                setSearchQuery('');
                setSelectedCategory('All');
                setSortBy('recent');
              }}
              className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold hover:underline flex items-center gap-1"
            >
              <i className="fa-solid fa-rotate-left text-[10px]"></i>
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* Main Content Area: Empty State OR Grid OR List */}
      {filteredItems.length === 0 ? (
        <div className="bg-white rounded-3xl border border-gray-200 p-12 text-center shadow-sm">
          <div className="w-16 h-16 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto mb-4">
            <i className="fa-solid fa-folder-open text-2xl"></i>
          </div>
          <h3 className="text-lg font-bold text-gray-900 mb-1">No knowledge artifacts found</h3>
          <p className="text-xs text-gray-500 max-w-sm mx-auto mb-6">
            We couldn't find any documents, whiteboards, or frameworks matching your current search or filters.
          </p>
          <div className="flex items-center justify-center gap-3">
            <button
              onClick={() => {
                setActiveType('all');
                setSearchQuery('');
                setSelectedCategory('All');
                setSortBy('recent');
              }}
              className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold text-xs rounded-xl transition-colors"
            >
              Clear All Filters
            </button>
            <button
              onClick={() => setIsCreateModalOpen(true)}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-xl shadow-sm transition-colors"
            >
              <i className="fa-solid fa-plus mr-1.5"></i>
              Create New Item
            </button>
          </div>
        </div>
      ) : viewMode === 'grid' ? (
        /* ================= GRID VIEW ================= */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map(item => {
            if (item.type === 'document') {
              return (
                <div
                  key={item.id}
                  onClick={() => setSelectedDocument(item)}
                  className="bg-white rounded-2xl border border-gray-200 p-5 shadow-sm hover:border-indigo-300 hover:shadow-md transition-all flex flex-col justify-between group cursor-pointer relative"
                >
                  <div>
                    {/* Top Type & Badges */}
                    <div className="flex items-start justify-between mb-3.5">
                      <div className="flex items-center space-x-2.5">
                        <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-base shadow-xs group-hover:scale-105 transition-transform">
                          <i className="fa-solid fa-file-lines"></i>
                        </div>
                        <div>
                          <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-md">
                            Document • {item.documentFormat || 'Spec'}
                          </span>
                          <span className="text-[11px] text-gray-400 block mt-0.5">{item.readTime || '5 min read'}</span>
                        </div>
                      </div>

                      <div className="flex items-center space-x-1" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={(e) => handleCopyContent(item.documentContent || item.description, item.id, e)}
                          className="p-1.5 hover:bg-gray-100 rounded-lg text-gray-400 hover:text-gray-700 transition-colors"
                          title="Copy Document Text"
                        >
                          <i className={`fa-solid ${copiedId === item.id ? 'fa-check text-green-600' : 'fa-copy text-xs'}`}></i>
                        </button>
                        <button
                          onClick={(e) => handleDeleteItem(item.id, e)}
                          className="p-1.5 hover:bg-rose-50 rounded-lg text-gray-400 hover:text-rose-600 transition-colors"
                          title="Delete Document"
                        >
                          <i className="fa-solid fa-trash text-xs"></i>
                        </button>
                      </div>
                    </div>

                    <h3 className="text-base font-bold text-gray-900 group-hover:text-indigo-600 transition-colors line-clamp-1">
                      {item.title}
                    </h3>
                    <p className="text-xs text-gray-500 mt-1.5 line-clamp-2 leading-relaxed">
                      {item.description}
                    </p>

                    {/* Tags */}
                    <div className="flex flex-wrap gap-1.5 mt-3.5">
                      {item.tags.slice(0, 3).map((tag, idx) => (
                        <span key={idx} className="text-[10px] font-semibold bg-gray-100 text-gray-600 px-2 py-0.5 rounded-md">
                          #{tag}
                        </span>
                      ))}
                      {item.tags.length > 3 && (
                        <span className="text-[10px] text-gray-400 font-medium self-center">
                          +{item.tags.length - 3}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Card Footer */}
                  <div className="pt-4 border-t border-gray-100 mt-4 flex items-center justify-between text-xs text-gray-500">
                    <div className="flex items-center space-x-2">
                      <img src={item.author.avatar} alt={item.author.name} className="w-5 h-5 rounded-full object-cover" />
                      <span className="text-[11px] font-medium text-gray-700 truncate max-w-[110px]">{item.author.name}</span>
                    </div>

                    <span className="text-indigo-600 font-semibold text-xs flex items-center group-hover:translate-x-0.5 transition-transform">
                      Read Document <i className="fa-solid fa-arrow-right ml-1 text-[10px]"></i>
                    </span>
                  </div>
                </div>
              );
            }

            if (item.type === 'whiteboard') {
              return (
                <div
                  key={item.id}
                  onClick={() => setSelectedWhiteboard(item)}
                  className="bg-white rounded-2xl border border-gray-200 p-5 shadow-sm hover:border-emerald-300 hover:shadow-md transition-all flex flex-col justify-between group cursor-pointer relative"
                >
                  <div>
                    {/* Top Badges */}
                    <div className="flex items-start justify-between mb-3.5">
                      <div className="flex items-center space-x-2.5">
                        <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center text-base shadow-xs group-hover:scale-105 transition-transform">
                          <i className="fa-solid fa-chalkboard"></i>
                        </div>
                        <div>
                          <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
                            Whiteboard • {item.canvasType || 'Canvas'}
                          </span>
                          <span className="text-[11px] text-gray-400 block mt-0.5">
                            {item.stickyCount || item.stickyNotes?.length || 0} Sticky Notes
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center space-x-1" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={(e) => handleDeleteItem(item.id, e)}
                          className="p-1.5 hover:bg-rose-50 rounded-lg text-gray-400 hover:text-rose-600 transition-colors"
                          title="Delete Whiteboard"
                        >
                          <i className="fa-solid fa-trash text-xs"></i>
                        </button>
                      </div>
                    </div>

                    <h3 className="text-base font-bold text-gray-900 group-hover:text-emerald-700 transition-colors line-clamp-1">
                      {item.title}
                    </h3>
                    <p className="text-xs text-gray-500 mt-1.5 line-clamp-2 leading-relaxed">
                      {item.description}
                    </p>

                    {/* Canvas Sticky Mini-Preview Mockup */}
                    <div className="mt-3.5 bg-slate-50 border border-slate-200/80 rounded-xl p-2.5 flex items-center gap-2 overflow-x-hidden">
                      {(item.stickyNotes || []).slice(0, 3).map((sn, sIdx) => (
                        <div
                          key={sIdx}
                          className={`w-24 h-16 p-1.5 rounded-lg border text-[9px] leading-tight font-medium shadow-2xs flex flex-col justify-between overflow-hidden flex-shrink-0 ${getStickyColorClass(sn.color)}`}
                        >
                          <span className="line-clamp-2">{sn.text}</span>
                          <div className="flex justify-between items-center text-[8px] opacity-70">
                            <span>{sn.author.split(' ')[0]}</span>
                            <span>❤️ {sn.votes || 0}</span>
                          </div>
                        </div>
                      ))}
                      {(item.stickyNotes?.length || 0) > 3 && (
                        <div className="w-12 h-16 rounded-lg bg-white border border-dashed border-gray-300 flex items-center justify-center text-[10px] font-bold text-gray-400 flex-shrink-0">
                          +{item.stickyNotes!.length - 3}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Card Footer */}
                  <div className="pt-4 border-t border-gray-100 mt-4 flex items-center justify-between text-xs text-gray-500">
                    <div className="flex items-center space-x-2">
                      <img src={item.author.avatar} alt={item.author.name} className="w-5 h-5 rounded-full object-cover" />
                      <span className="text-[11px] font-medium text-gray-700 truncate max-w-[110px]">{item.author.name}</span>
                    </div>

                    <span className="text-emerald-700 font-semibold text-xs flex items-center group-hover:translate-x-0.5 transition-transform">
                      Open Canvas <i className="fa-solid fa-arrow-right ml-1 text-[10px]"></i>
                    </span>
                  </div>
                </div>
              );
            }

            // Framework Card
            return (
              <div
                key={item.id}
                onClick={() => setSelectedFramework(item)}
                className="bg-white rounded-2xl border border-gray-200 p-5 shadow-sm hover:border-amber-300 hover:shadow-md transition-all flex flex-col justify-between group cursor-pointer relative"
              >
                <div>
                  {/* Top Badges */}
                  <div className="flex items-start justify-between mb-3.5">
                    <div className="flex items-center space-x-2.5">
                      <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center text-base shadow-xs group-hover:scale-105 transition-transform">
                        <i className="fa-solid fa-cubes-stacked"></i>
                      </div>
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md">
                          Framework • {item.frameworkCategory || 'Methodology'}
                        </span>
                        <span className="text-[11px] text-gray-400 block mt-0.5">
                          {item.stepsCount || item.steps?.length || 4} Phased Steps
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center space-x-1" onClick={(e) => e.stopPropagation()}>
                      <button
                        onClick={(e) => handleCopyContent(item.templateSnippet || item.description, item.id, e)}
                        className="p-1.5 hover:bg-gray-100 rounded-lg text-gray-400 hover:text-gray-700 transition-colors"
                        title="Copy Framework Template"
                      >
                        <i className={`fa-solid ${copiedId === item.id ? 'fa-check text-green-600' : 'fa-copy text-xs'}`}></i>
                      </button>
                      <button
                        onClick={(e) => handleDeleteItem(item.id, e)}
                        className="p-1.5 hover:bg-rose-50 rounded-lg text-gray-400 hover:text-rose-600 transition-colors"
                        title="Delete Framework"
                      >
                        <i className="fa-solid fa-trash text-xs"></i>
                      </button>
                    </div>
                  </div>

                  <h3 className="text-base font-bold text-gray-900 group-hover:text-amber-700 transition-colors line-clamp-1">
                    {item.title}
                  </h3>
                  <p className="text-xs text-gray-500 mt-1.5 line-clamp-2 leading-relaxed">
                    {item.description}
                  </p>

                  {/* AI Agent Recommendation Badges */}
                  {item.recommendedAgents && item.recommendedAgents.length > 0 && (
                    <div className="mt-3.5 bg-purple-50/60 p-2.5 rounded-xl border border-purple-100">
                      <span className="text-[10px] font-bold text-purple-700 flex items-center gap-1 mb-1.5">
                        <i className="fa-solid fa-robot text-[9px]"></i> Compatible AI Agents:
                      </span>
                      <div className="flex flex-wrap gap-1">
                        {item.recommendedAgents.map((agentName, aIdx) => (
                          <span key={aIdx} className="text-[9px] font-medium bg-white text-purple-800 px-2 py-0.5 rounded border border-purple-200">
                            {agentName}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Card Footer */}
                <div className="pt-4 border-t border-gray-100 mt-4 flex items-center justify-between text-xs text-gray-500">
                  <div className="flex items-center space-x-2">
                    <img src={item.author.avatar} alt={item.author.name} className="w-5 h-5 rounded-full object-cover" />
                    <span className="text-[11px] font-medium text-gray-700 truncate max-w-[110px]">{item.author.name}</span>
                  </div>

                  <span className="text-amber-700 font-semibold text-xs flex items-center group-hover:translate-x-0.5 transition-transform">
                    Explore Framework <i className="fa-solid fa-arrow-right ml-1 text-[10px]"></i>
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* ================= LIST VIEW ================= */
        <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-gray-50/80 border-b border-gray-200 text-[11px] font-bold text-gray-500 uppercase tracking-wider">
                  <th className="py-3.5 px-4">Artifact & Title</th>
                  <th className="py-3.5 px-4">Type</th>
                  <th className="py-3.5 px-4">Category</th>
                  <th className="py-3.5 px-4">Author</th>
                  <th className="py-3.5 px-4">Updated</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 text-xs text-gray-700">
                {filteredItems.map(item => {
                  const isDoc = item.type === 'document';
                  const isWb = item.type === 'whiteboard';
                  const isFw = item.type === 'framework';

                  const handleRowClick = () => {
                    if (isDoc) setSelectedDocument(item);
                    else if (isWb) setSelectedWhiteboard(item);
                    else setSelectedFramework(item);
                  };

                  return (
                    <tr
                      key={item.id}
                      onClick={handleRowClick}
                      className="hover:bg-indigo-50/20 transition-colors group cursor-pointer"
                    >
                      <td className="py-3.5 px-4">
                        <div className="flex items-center space-x-3">
                          <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 text-sm shadow-2xs ${
                            isDoc ? 'bg-indigo-50 text-indigo-600' :
                            isWb ? 'bg-emerald-50 text-emerald-600' :
                            'bg-amber-50 text-amber-600'
                          }`}>
                            <i className={`fa-solid ${
                              isDoc ? 'fa-file-lines' :
                              isWb ? 'fa-chalkboard' :
                              'fa-cubes-stacked'
                            }`}></i>
                          </div>
                          <div className="min-w-0 max-w-sm sm:max-w-md">
                            <span className="font-bold text-gray-900 group-hover:text-indigo-600 transition-colors truncate block">
                              {item.title}
                            </span>
                            <span className="text-[11px] text-gray-400 truncate block mt-0.5">
                              {item.description}
                            </span>
                          </div>
                        </div>
                      </td>

                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                          isDoc ? 'bg-indigo-100 text-indigo-700' :
                          isWb ? 'bg-emerald-100 text-emerald-700' :
                          'bg-amber-100 text-amber-700'
                        }`}>
                          {isDoc ? 'Document' : isWb ? 'Whiteboard' : 'Framework'}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 whitespace-nowrap text-gray-600 text-xs">
                        {item.category}
                      </td>

                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <div className="flex items-center space-x-2">
                          <img src={item.author.avatar} alt={item.author.name} className="w-5 h-5 rounded-full object-cover" />
                          <span className="text-gray-700 font-medium text-xs">{item.author.name}</span>
                        </div>
                      </td>

                      <td className="py-3.5 px-4 whitespace-nowrap text-gray-400 text-[11px]">
                        {item.updatedAt}
                      </td>

                      <td className="py-3.5 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end space-x-1.5">
                          <button
                            onClick={handleRowClick}
                            className="px-2.5 py-1.5 bg-gray-100 hover:bg-indigo-50 hover:text-indigo-600 text-gray-700 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1"
                          >
                            <i className="fa-solid fa-eye text-xs"></i>
                            <span className="hidden sm:inline">View</span>
                          </button>

                          <button
                            onClick={(e) => handleCopyContent(
                              item.documentContent || item.templateSnippet || item.description,
                              item.id,
                              e
                            )}
                            className="p-1.5 hover:bg-gray-100 rounded-lg text-gray-400 hover:text-gray-700 transition-colors"
                            title="Copy Content"
                          >
                            <i className={`fa-solid ${copiedId === item.id ? 'fa-check text-green-600' : 'fa-copy text-xs'}`}></i>
                          </button>

                          <button
                            onClick={(e) => handleDeleteItem(item.id, e)}
                            className="p-1.5 hover:bg-rose-50 rounded-lg text-gray-400 hover:text-rose-600 transition-colors"
                            title="Delete"
                          >
                            <i className="fa-solid fa-trash text-xs"></i>
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ================= MODAL 1: DOCUMENT READER ================= */}
      {selectedDocument && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden border border-gray-100">
            {/* Modal Header */}
            <div className="p-6 border-b border-gray-100 flex items-start justify-between bg-gradient-to-r from-gray-50 to-indigo-50/30">
              <div className="flex items-start space-x-3.5">
                <div className="w-12 h-12 rounded-2xl bg-indigo-600 text-white flex items-center justify-center text-xl shadow-md shadow-indigo-200">
                  <i className="fa-solid fa-file-lines"></i>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-100 text-indigo-700">
                      {selectedDocument.documentFormat || 'Specification'}
                    </span>
                    <span className="text-xs text-gray-400">{selectedDocument.readTime}</span>
                  </div>
                  <h2 className="text-xl font-bold text-gray-900 mt-1">{selectedDocument.title}</h2>
                  <div className="flex items-center gap-2 mt-1 text-xs text-gray-500">
                    <span>By <strong>{selectedDocument.author.name}</strong> ({selectedDocument.author.role})</span>
                    <span>•</span>
                    <span>{selectedDocument.updatedAt}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={(e) => handleCopyContent(selectedDocument.documentContent || '', selectedDocument.id, e)}
                  className="px-3 py-1.5 bg-white border border-gray-200 hover:border-gray-300 rounded-xl text-xs font-semibold text-gray-700 shadow-xs flex items-center gap-1.5 transition-colors"
                >
                  <i className={`fa-solid ${copiedId === selectedDocument.id ? 'fa-check text-green-600' : 'fa-copy'}`}></i>
                  <span>{copiedId === selectedDocument.id ? 'Copied' : 'Copy Spec'}</span>
                </button>
                <button
                  onClick={() => setSelectedDocument(null)}
                  className="p-2 text-gray-400 hover:text-gray-700 rounded-xl hover:bg-gray-100 transition-colors"
                >
                  <i className="fa-solid fa-xmark text-lg"></i>
                </button>
              </div>
            </div>

            {/* Modal Body */}
            <div className="p-6 sm:p-8 overflow-y-auto flex-1 space-y-6">
              <div className="bg-gray-50 p-4 rounded-2xl border border-gray-200 text-xs text-gray-600 leading-relaxed">
                <strong className="text-gray-900">Summary: </strong>{selectedDocument.description}
              </div>

              <div className="prose max-w-none text-xs sm:text-sm text-gray-800 leading-relaxed font-sans bg-white p-4 rounded-xl border border-gray-100">
                <pre className="whitespace-pre-wrap font-sans text-xs leading-relaxed text-gray-800">
                  {selectedDocument.documentContent}
                </pre>
              </div>

              {/* Tags */}
              <div className="pt-4 border-t border-gray-100 flex flex-wrap gap-2">
                {selectedDocument.tags.map((tag, idx) => (
                  <span key={idx} className="px-2.5 py-1 rounded-lg text-xs font-medium bg-gray-100 text-gray-700">
                    #{tag}
                  </span>
                ))}
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-gray-50 border-t border-gray-100 flex justify-between items-center">
              <button
                onClick={() => alert(`Downloaded "${selectedDocument.title}.md" to your machine!`)}
                className="px-4 py-2 bg-white border border-gray-200 text-gray-700 rounded-xl text-xs font-semibold hover:bg-gray-100 transition-colors flex items-center gap-1.5"
              >
                <i className="fa-solid fa-download text-xs"></i>
                Download Markdown
              </button>
              <button
                onClick={() => setSelectedDocument(null)}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-colors"
              >
                Close Document
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL 2: INTERACTIVE WHITEBOARD CANVAS ================= */}
      {selectedWhiteboard && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/70 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl w-full max-w-6xl h-[92vh] flex flex-col shadow-2xl overflow-hidden border border-gray-100">
            {/* Whiteboard Top Toolbar */}
            <div className="p-4 sm:p-5 border-b border-gray-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 text-white">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500 text-white flex items-center justify-center text-lg shadow-sm">
                  <i className="fa-solid fa-chalkboard"></i>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      {selectedWhiteboard.canvasType || 'Journey Board'}
                    </span>
                    <span className="text-xs text-slate-400">
                      {selectedWhiteboard.stickyNotes?.length || 0} Sticky Notes
                    </span>
                  </div>
                  <h2 className="text-base sm:text-lg font-bold text-white">{selectedWhiteboard.title}</h2>
                </div>
              </div>

              {/* Canvas Controls */}
              <div className="flex items-center space-x-2">
                <div className="flex items-center bg-slate-800 rounded-xl p-1 border border-slate-700 text-xs">
                  <button onClick={() => alert('Canvas zoom set to 100%')} className="px-2 py-1 text-slate-300 hover:text-white" title="Reset Zoom">
                    100%
                  </button>
                  <button onClick={() => alert('Fit to screen')} className="p-1 text-slate-300 hover:text-white" title="Fit to Screen">
                    <i className="fa-solid fa-expand text-xs"></i>
                  </button>
                </div>

                <button
                  onClick={() => {
                    navigator.clipboard.writeText(window.location.href);
                    alert('Whiteboard canvas shareable link copied to clipboard!');
                  }}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <i className="fa-solid fa-share-nodes text-xs"></i>
                  <span>Share</span>
                </button>

                <button
                  onClick={() => setSelectedWhiteboard(null)}
                  className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
                >
                  <i className="fa-solid fa-xmark text-lg"></i>
                </button>
              </div>
            </div>

            {/* Whiteboard Canvas Board Container */}
            <div className="flex-1 overflow-x-auto overflow-y-auto p-6 bg-slate-100" style={{ backgroundImage: 'radial-gradient(#cbd5e1 1px, transparent 1px)', backgroundSize: '20px 20px' }}>
              <div className="flex gap-6 min-w-max pb-6">
                {(selectedWhiteboard.boardColumns || ['Backlog', 'In Discovery', 'Opportunities', 'Action Items']).map((colName) => {
                  const colNotes = (selectedWhiteboard.stickyNotes || []).filter(sn => sn.column === colName);

                  return (
                    <div
                      key={colName}
                      className="w-80 bg-white/90 backdrop-blur-md rounded-2xl border border-slate-200/90 shadow-sm flex flex-col p-4"
                    >
                      {/* Column Header */}
                      <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100">
                        <div className="flex items-center gap-2">
                          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800">{colName}</h4>
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-600">
                            {colNotes.length}
                          </span>
                        </div>
                      </div>

                      {/* Sticky Notes Stack */}
                      <div className="space-y-3 flex-1 overflow-y-auto max-h-[50vh] pr-1">
                        {colNotes.map((note) => (
                          <div
                            key={note.id}
                            className={`p-3.5 rounded-xl border text-xs font-medium shadow-sm transition-all hover:scale-[1.01] flex flex-col justify-between ${getStickyColorClass(note.color)}`}
                          >
                            <p className="leading-relaxed whitespace-pre-wrap">{note.text}</p>
                            <div className="pt-2.5 mt-2 border-t border-black/10 flex items-center justify-between text-[10px] opacity-80">
                              <span className="font-semibold">{note.author}</span>
                              <button
                                onClick={(e) => handleVoteSticky(selectedWhiteboard.id, note.id, e)}
                                className="px-2 py-0.5 bg-white/60 hover:bg-white rounded-md font-bold text-gray-800 transition-colors flex items-center gap-1 shadow-2xs"
                                title="Upvote Sticky Note"
                              >
                                <span>❤️</span>
                                <span>{note.votes || 0}</span>
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Add Sticky to Column Input */}
                      <div className="pt-3 mt-3 border-t border-slate-100">
                        <div className="flex items-center gap-1.5 mb-2">
                          <span className="text-[10px] font-semibold text-slate-400">Color:</span>
                          {(['yellow', 'pink', 'green', 'blue', 'orange', 'purple'] as const).map(c => (
                            <button
                              key={c}
                              onClick={() => setNewStickyColor(c)}
                              className={`w-4 h-4 rounded-full border ${
                                newStickyColor === c ? 'ring-2 ring-indigo-500 scale-110' : ''
                              } ${
                                c === 'yellow' ? 'bg-amber-300 border-amber-400' :
                                c === 'pink' ? 'bg-rose-300 border-rose-400' :
                                c === 'green' ? 'bg-emerald-300 border-emerald-400' :
                                c === 'blue' ? 'bg-sky-300 border-sky-400' :
                                c === 'orange' ? 'bg-orange-300 border-orange-400' :
                                'bg-purple-300 border-purple-400'
                              }`}
                              title={c}
                            />
                          ))}
                        </div>

                        <div className="flex items-center gap-2">
                          <input
                            type="text"
                            placeholder="Add sticky note..."
                            value={newStickyText[colName] || ''}
                            onChange={(e) => setNewStickyText({ ...newStickyText, [colName]: e.target.value })}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleAddStickyNote(selectedWhiteboard.id, colName);
                            }}
                            className="flex-1 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-gray-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                          />
                          <button
                            onClick={() => handleAddStickyNote(selectedWhiteboard.id, colName)}
                            className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-colors"
                          >
                            <i className="fa-solid fa-plus"></i>
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Modal Bottom Bar */}
            <div className="p-3 bg-white border-t border-gray-200 flex justify-between items-center text-xs text-gray-500 px-6">
              <span className="flex items-center gap-1.5">
                <i className="fa-solid fa-circle text-[8px] text-green-500 animate-pulse"></i>
                Live Collaborative Sync Active
              </span>
              <button
                onClick={() => setSelectedWhiteboard(null)}
                className="px-4 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold rounded-xl text-xs transition-colors"
              >
                Close Canvas
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL 3: FRAMEWORK DEEP-DIVE ================= */}
      {selectedFramework && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden border border-gray-100">
            {/* Header */}
            <div className="p-6 border-b border-gray-100 flex items-start justify-between bg-gradient-to-r from-amber-50/50 to-orange-50/30">
              <div className="flex items-start space-x-3.5">
                <div className="w-12 h-12 rounded-2xl bg-amber-500 text-white flex items-center justify-center text-xl shadow-md shadow-amber-200">
                  <i className="fa-solid fa-cubes-stacked"></i>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800">
                      {selectedFramework.frameworkCategory || 'Methodology'}
                    </span>
                    <span className="text-xs text-gray-400">
                      {selectedFramework.stepsCount || selectedFramework.steps?.length || 4} Phased Steps
                    </span>
                  </div>
                  <h2 className="text-xl font-bold text-gray-900 mt-1">{selectedFramework.title}</h2>
                  <p className="text-xs text-gray-500 mt-1">{selectedFramework.description}</p>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={(e) => handleCopyContent(selectedFramework.templateSnippet || selectedFramework.description, selectedFramework.id, e)}
                  className="px-3 py-1.5 bg-white border border-gray-200 hover:border-gray-300 rounded-xl text-xs font-semibold text-gray-700 shadow-xs flex items-center gap-1.5 transition-colors"
                >
                  <i className={`fa-solid ${copiedId === selectedFramework.id ? 'fa-check text-green-600' : 'fa-copy'}`}></i>
                  <span>{copiedId === selectedFramework.id ? 'Copied' : 'Copy Template'}</span>
                </button>
                <button
                  onClick={() => setSelectedFramework(null)}
                  className="p-2 text-gray-400 hover:text-gray-700 rounded-xl hover:bg-gray-100 transition-colors"
                >
                  <i className="fa-solid fa-xmark text-lg"></i>
                </button>
              </div>
            </div>

            {/* Body */}
            <div className="p-6 sm:p-8 overflow-y-auto flex-1 space-y-6">
              {/* Compatible Agents Action Banner */}
              {selectedFramework.recommendedAgents && selectedFramework.recommendedAgents.length > 0 && (
                <div className="bg-gradient-to-r from-purple-50 to-indigo-50 p-4 rounded-2xl border border-purple-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h4 className="text-xs font-bold text-purple-900 flex items-center gap-1.5">
                      <i className="fa-solid fa-wand-magic-sparkles text-purple-600"></i>
                      Run with Recommended AI Agents
                    </h4>
                    <p className="text-[11px] text-purple-700 mt-0.5">
                      These studio agents are pre-calibrated to execute this framework's deliverables.
                    </p>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedFramework.recommendedAgents.map((agentName, aIdx) => (
                      <button
                        key={aIdx}
                        onClick={() => {
                          setSelectedFramework(null);
                          if (onNavigateToAgents) onNavigateToAgents();
                        }}
                        className="px-2.5 py-1 bg-white hover:bg-purple-600 hover:text-white text-purple-800 text-[11px] font-semibold rounded-lg border border-purple-200 shadow-2xs transition-all flex items-center gap-1"
                      >
                        <i className="fa-solid fa-play text-[9px]"></i>
                        <span>{agentName}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Step-by-Step Methodology Cards */}
              <div className="space-y-4">
                <h4 className="text-xs font-bold uppercase tracking-wider text-gray-500">
                  Execution Phases & Action Items
                </h4>

                {(selectedFramework.steps || []).map((step, sIdx) => (
                  <div
                    key={sIdx}
                    className="p-5 rounded-2xl border border-gray-200 bg-white shadow-2xs hover:border-amber-200 transition-colors"
                  >
                    <div className="flex items-start justify-between">
                      <h5 className="text-sm font-bold text-gray-900">{step.title}</h5>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-50 text-amber-700">
                        Step {sIdx + 1}
                      </span>
                    </div>
                    <p className="text-xs text-gray-600 mt-2 leading-relaxed">
                      {step.description}
                    </p>

                    {step.deliverables && step.deliverables.length > 0 && (
                      <div className="mt-3 pt-3 border-t border-gray-100">
                        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1.5">
                          Standard Deliverables:
                        </span>
                        <div className="flex flex-wrap gap-1.5">
                          {step.deliverables.map((del, dIdx) => (
                            <span key={dIdx} className="text-[11px] bg-gray-50 text-gray-700 px-2 py-0.5 rounded border border-gray-200 font-medium flex items-center gap-1">
                              <i className="fa-solid fa-check text-[9px] text-green-600"></i>
                              {del}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {step.tips && (
                      <div className="mt-2.5 bg-amber-50/50 p-2 rounded-lg text-[11px] text-amber-900 border border-amber-100 flex items-start gap-1.5">
                        <i className="fa-solid fa-lightbulb text-amber-600 mt-0.5 text-xs"></i>
                        <span>{step.tips}</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 bg-gray-50 border-t border-gray-100 flex justify-end gap-2">
              <button
                onClick={() => setSelectedFramework(null)}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-colors"
              >
                Close Framework
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL 4: CREATE KNOWLEDGE ITEM ================= */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden border border-gray-100">
            {/* Header */}
            <div className="p-6 border-b border-gray-100 flex items-center justify-between bg-gradient-to-r from-gray-50 to-indigo-50/20">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 text-white flex items-center justify-center text-lg shadow-sm">
                  <i className="fa-solid fa-plus"></i>
                </div>
                <div>
                  <h3 className="text-base font-bold text-gray-900">Create Knowledge Artifact</h3>
                  <p className="text-xs text-gray-500">Add a document, whiteboard, or framework to your studio knowledge base.</p>
                </div>
              </div>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="p-2 text-gray-400 hover:text-gray-700 rounded-xl hover:bg-gray-100 transition-colors"
              >
                <i className="fa-solid fa-xmark text-lg"></i>
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleCreateKnowledgeItem} className="p-6 overflow-y-auto flex-1 space-y-4 text-xs">
              {/* Type Selection */}
              <div>
                <label className="font-bold text-gray-700 block mb-2">Select Artifact Type</label>
                <div className="grid grid-cols-3 gap-2.5">
                  <button
                    type="button"
                    onClick={() => setNewItemType('document')}
                    className={`p-3 rounded-xl border text-center transition-all ${
                      newItemType === 'document'
                        ? 'border-indigo-600 bg-indigo-50 text-indigo-900 font-bold shadow-xs'
                        : 'border-gray-200 hover:bg-gray-50 text-gray-600'
                    }`}
                  >
                    <i className="fa-solid fa-file-lines text-base mb-1 text-indigo-600 block"></i>
                    Document
                  </button>

                  <button
                    type="button"
                    onClick={() => setNewItemType('whiteboard')}
                    className={`p-3 rounded-xl border text-center transition-all ${
                      newItemType === 'whiteboard'
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-900 font-bold shadow-xs'
                        : 'border-gray-200 hover:bg-gray-50 text-gray-600'
                    }`}
                  >
                    <i className="fa-solid fa-chalkboard text-base mb-1 text-emerald-600 block"></i>
                    Whiteboard
                  </button>

                  <button
                    type="button"
                    onClick={() => setNewItemType('framework')}
                    className={`p-3 rounded-xl border text-center transition-all ${
                      newItemType === 'framework'
                        ? 'border-amber-600 bg-amber-50 text-amber-900 font-bold shadow-xs'
                        : 'border-gray-200 hover:bg-gray-50 text-gray-600'
                    }`}
                  >
                    <i className="fa-solid fa-cubes-stacked text-base mb-1 text-amber-600 block"></i>
                    Framework
                  </button>
                </div>
              </div>

              {/* Title */}
              <div>
                <label className="font-bold text-gray-700 block mb-1">Title</label>
                <input
                  type="text"
                  required
                  value={newItemTitle}
                  onChange={(e) => setNewItemTitle(e.target.value)}
                  placeholder="e.g. Navigation Token Spec, Sprint Ideation Board..."
                  className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                />
              </div>

              {/* Category & Tags Row */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-gray-700 block mb-1">Category</label>
                  <select
                    value={newItemCategory}
                    onChange={(e) => setNewItemCategory(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                  >
                    <option value="Design System">Design System</option>
                    <option value="Research">Research</option>
                    <option value="Usability">Usability</option>
                    <option value="Discovery">Discovery</option>
                    <option value="Methodology">Methodology</option>
                    <option value="Evaluation">Evaluation</option>
                    <option value="Content Strategy">Content Strategy</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold text-gray-700 block mb-1">Tags (comma separated)</label>
                  <input
                    type="text"
                    value={newItemTags}
                    onChange={(e) => setNewItemTags(e.target.value)}
                    placeholder="Tokens, Mobile, Accessibility..."
                    className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                  />
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="font-bold text-gray-700 block mb-1">Summary & Context</label>
                <textarea
                  rows={2}
                  value={newItemDescription}
                  onChange={(e) => setNewItemDescription(e.target.value)}
                  placeholder="Brief description of this artifact..."
                  className="w-full px-3.5 py-2 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                />
              </div>

              {/* Type-Specific Options */}
              {newItemType === 'document' && (
                <div className="space-y-3 pt-2 border-t border-gray-100">
                  <div>
                    <label className="font-bold text-gray-700 block mb-1">Document Format</label>
                    <select
                      value={newItemFormat}
                      onChange={(e) => setNewItemFormat(e.target.value as any)}
                      className="w-full px-3.5 py-2 bg-gray-50 border border-gray-200 rounded-xl text-xs"
                    >
                      <option value="Spec">Technical / Design Spec</option>
                      <option value="Report">Research & Usability Report</option>
                      <option value="Guide">Style & Writing Guide</option>
                      <option value="Markdown">Standard Markdown Document</option>
                    </select>
                  </div>

                  <div>
                    <label className="font-bold text-gray-700 block mb-1">Content (Markdown)</label>
                    <textarea
                      rows={5}
                      value={newItemContent}
                      onChange={(e) => setNewItemContent(e.target.value)}
                      className="w-full px-3.5 py-2 bg-gray-50 border border-gray-200 rounded-xl font-mono text-xs"
                    />
                  </div>
                </div>
              )}

              {newItemType === 'whiteboard' && (
                <div className="space-y-3 pt-2 border-t border-gray-100">
                  <div>
                    <label className="font-bold text-gray-700 block mb-1">Canvas Layout Template</label>
                    <select
                      value={newItemCanvasType}
                      onChange={(e) => setNewItemCanvasType(e.target.value as any)}
                      className="w-full px-3.5 py-2 bg-gray-50 border border-gray-200 rounded-xl text-xs"
                    >
                      <option value="Affinity Map">Affinity Diagramming Board</option>
                      <option value="User Journey">Customer Journey & Touchpoints</option>
                      <option value="Sprint Board">Design Sprint 2.0 Solution Board</option>
                      <option value="Architecture">Information Architecture Mindmap</option>
                    </select>
                  </div>
                  <p className="text-[11px] text-gray-500 bg-emerald-50 p-2.5 rounded-xl border border-emerald-100 text-emerald-800">
                    <i className="fa-solid fa-sparkles mr-1 text-emerald-600"></i>
                    Initial columns and sample sticky notes will be generated automatically for this canvas type.
                  </p>
                </div>
              )}

              {/* Form Buttons */}
              <div className="pt-4 border-t border-gray-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold rounded-xl text-xs transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-semibold rounded-xl text-xs shadow-md shadow-indigo-200 transition-all hover:scale-[1.02]"
                >
                  Create & Open Artifact
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

// ==========================================
// --- ROADMAPS VIEW (Starter, Features, Now Next Later, Strategy, Portfolio, Custom) ---
// ==========================================
interface RoadmapsViewProps {
  activeSubMenu?: string;
  onSelectSubMenu?: (menu: string) => void;
  onNavigateToAgents?: () => void;
}

export const RoadmapsView: React.FC<RoadmapsViewProps> = ({ 
  activeSubMenu = 'roadmaps:starter', 
  onSelectSubMenu,
  onNavigateToAgents 
}) => {
  // Determine active roadmap from activeSubMenu or default to 'starter'
  const parseActiveType = (menuStr: string): RoadmapType => {
    if (menuStr.includes('features')) return 'features';
    if (menuStr.includes('now-next-later')) return 'now-next-later';
    if (menuStr.includes('strategy')) return 'strategy';
    if (menuStr.includes('portfolio')) return 'portfolio';
    if (menuStr.includes('custom')) return 'custom';
    return 'starter';
  };

  const [activeType, setActiveType] = useState<RoadmapType>(parseActiveType(activeSubMenu));
  const [items, setItems] = useState<RoadmapItem[]>(ROADMAP_ITEMS);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | RoadmapItem['status']>('All');
  const [priorityFilter, setPriorityFilter] = useState<'All' | 'P0 - Critical' | 'P1 - High' | 'P2 - Medium'>('All');
  
  // Selection and modal state
  const [selectedItem, setSelectedItem] = useState<RoadmapItem | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [completedDeliverables, setCompletedDeliverables] = useState<{ [itemId: string]: number[] }>({
    'star-1': [0, 1, 2],
    'star-2': [0, 1, 2],
    'star-3': [0],
    'feat-2': [0, 1, 2],
    'nnl-2': [0],
    'nnl-3': [0]
  });

  // New Roadmap Item Form State
  const [newItemTitle, setNewItemTitle] = useState('');
  const [newItemDescription, setNewItemDescription] = useState('');
  const [newItemStatus, setNewItemStatus] = useState<RoadmapItem['status']>('In Progress');
  const [newItemPriority, setNewItemPriority] = useState<RoadmapItem['priority']>('P1 - High');
  const [newItemEffort, setNewItemEffort] = useState<RoadmapItem['effort']>('M');
  const [newItemImpact, setNewItemImpact] = useState<RoadmapItem['impact']>('High');
  const [newItemHorizon, setNewItemHorizon] = useState<'now' | 'next' | 'later'>('now');
  const [newItemQuarter, setNewItemQuarter] = useState('Q4 2026');
  const [newItemTrack, setNewItemTrack] = useState('Design System');
  const [newItemDeliverables, setNewItemDeliverables] = useState('Spec Draft, Testing Review');
  const [newItemAgent, setNewItemAgent] = useState('UX Design Reviewer');

  // Sync state if prop changes
  React.useEffect(() => {
    if (activeSubMenu) {
      setActiveType(parseActiveType(activeSubMenu));
    }
  }, [activeSubMenu]);

  const handleSwitchTab = (type: RoadmapType) => {
    setActiveType(type);
    if (onSelectSubMenu) {
      onSelectSubMenu(`roadmaps:${type}`);
    }
  };

  // Deliverable toggle
  const toggleDeliverableCheck = (itemId: string, dIdx: number, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setCompletedDeliverables(prev => {
      const current = prev[itemId] || [];
      const updated = current.includes(dIdx)
        ? current.filter(idx => idx !== dIdx)
        : [...current, dIdx];
      return { ...prev, [itemId]: updated };
    });
  };

  // Move Horizon for Now, Next, Later
  const handleMoveHorizon = (itemId: string, newHorizon: 'now' | 'next' | 'later', e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setItems(prev =>
      prev.map(item => (item.id === itemId ? { ...item, horizon: newHorizon } : item))
    );
  };

  // Update Status
  const handleUpdateStatus = (itemId: string, newStatus: RoadmapItem['status'], e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setItems(prev =>
      prev.map(item => (item.id === itemId ? { ...item, status: newStatus } : item))
    );
    if (selectedItem?.id === itemId) {
      setSelectedItem(prev => prev ? { ...prev, status: newStatus } : null);
    }
  };

  // Delete item
  const handleDeleteItem = (itemId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (window.confirm('Are you sure you want to remove this item from the roadmap?')) {
      setItems(prev => prev.filter(item => item.id !== itemId));
      if (selectedItem?.id === itemId) setSelectedItem(null);
    }
  };

  // Handle Add Item
  const handleCreateRoadmapItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemTitle.trim()) return;

    const parsedDeliverables = newItemDeliverables
      .split(',')
      .map(d => d.trim())
      .filter(Boolean);

    const newItem: RoadmapItem = {
      id: `road-${Date.now()}`,
      roadmapType: activeType,
      title: newItemTitle.trim(),
      description: newItemDescription.trim() || 'Roadmap initiative for UX design enhancements.',
      status: newItemStatus,
      priority: newItemPriority,
      effort: newItemEffort,
      impact: newItemImpact,
      horizon: newItemHorizon,
      quarter: newItemQuarter,
      track: newItemTrack,
      progress: newItemStatus === 'Completed' ? 100 : newItemStatus === 'In Progress' ? 45 : 0,
      owner: {
        name: 'You (Lead)',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
        role: 'Staff Product Designer'
      },
      tags: [newItemTrack, newItemPriority?.split(' - ')[0] || 'P1'],
      deliverables: parsedDeliverables.length > 0 ? parsedDeliverables : ['Design Spec', 'Prototype Review'],
      aiAgent: newItemAgent
    };

    setItems([newItem, ...items]);
    setIsAddModalOpen(false);

    // Reset Form
    setNewItemTitle('');
    setNewItemDescription('');
  };

  // Filter items for the active roadmap type
  const currentRoadmapItems = items.filter(item => {
    if (item.roadmapType !== activeType) return false;
    if (statusFilter !== 'All' && item.status !== statusFilter) return false;
    if (priorityFilter !== 'All' && item.priority !== priorityFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const matchTitle = item.title.toLowerCase().includes(q);
      const matchDesc = item.description.toLowerCase().includes(q);
      const matchTrack = item.track?.toLowerCase().includes(q) || false;
      const matchTags = item.tags?.some(t => t.toLowerCase().includes(q)) || false;
      const matchOwner = item.owner?.name.toLowerCase().includes(q) || false;
      if (!matchTitle && !matchDesc && !matchTrack && !matchTags && !matchOwner) return false;
    }
    return true;
  });

  const isFiltered = searchQuery.trim() !== '' || statusFilter !== 'All' || priorityFilter !== 'All';

  // Roadmap Navigation Config
  const ROADMAP_TABS: { type: RoadmapType; label: string; icon: string; count: number; subtitle: string }[] = [
    { type: 'starter', label: 'Starter', icon: 'fa-flag-checkered', count: items.filter(i => i.roadmapType === 'starter').length, subtitle: 'MVP Launch Milestones' },
    { type: 'features', label: 'Features', icon: 'fa-cube', count: items.filter(i => i.roadmapType === 'features').length, subtitle: 'Version Release Delivery' },
    { type: 'now-next-later', label: 'Now, Next, Later', icon: 'fa-table-columns', count: items.filter(i => i.roadmapType === 'now-next-later').length, subtitle: 'Horizon Kanban Board' },
    { type: 'strategy', label: 'Strategy', icon: 'fa-chess', count: items.filter(i => i.roadmapType === 'strategy').length, subtitle: 'Strategic Pillars & OKRs' },
    { type: 'portfolio', label: 'Portfolio', icon: 'fa-layer-group', count: items.filter(i => i.roadmapType === 'portfolio').length, subtitle: 'Cross-Squad Multi-Track' },
    { type: 'custom', label: 'Custom', icon: 'fa-sliders', count: items.filter(i => i.roadmapType === 'custom').length, subtitle: 'Customizable Swimlanes' }
  ];

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 space-y-6">
      {/* ================= TOP HERO BANNER ================= */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-purple-950 rounded-3xl p-6 sm:p-8 text-white relative overflow-hidden shadow-xl border border-indigo-900/40">
        <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-radial from-indigo-500/20 to-transparent pointer-events-none"></div>
        <div className="absolute -right-8 -bottom-8 text-white/5 text-9xl font-black pointer-events-none select-none">
          <i className="fa-solid fa-route"></i>
        </div>

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="max-w-2xl">
            <div className="flex items-center space-x-2.5 mb-2.5">
              <span className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-indigo-500/30 text-indigo-200 border border-indigo-400/30 flex items-center gap-1.5 backdrop-blur-md">
                <i className="fa-solid fa-timeline text-[10px] text-amber-300"></i>
                Product Roadmap Suite
              </span>
              <span className="text-xs text-indigo-300/80 font-medium">
                {items.length} Total Initiatives Across 6 Views
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
              UX Product & Engineering Roadmaps
            </h1>
            <p className="text-sm text-indigo-200/80 mt-2 leading-relaxed">
              Align team priorities across Starter sprint launches, Version Features, Now/Next/Later horizons, Strategic OKRs, and cross-product Portfolio tracks.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => setIsAddModalOpen(true)}
              className="px-4 py-2.5 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white font-semibold text-xs rounded-xl shadow-lg shadow-indigo-500/30 flex items-center gap-2 transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              <i className="fa-solid fa-plus text-xs"></i>
              <span>Add Roadmap Item</span>
            </button>
          </div>
        </div>

        {/* ================= 6 ROADMAP TYPE SELECTOR TABS ================= */}
        <div className="relative z-10 mt-8 pt-6 border-t border-white/10 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
          {ROADMAP_TABS.map(tab => {
            const isActive = activeType === tab.type;
            return (
              <button
                key={tab.type}
                onClick={() => handleSwitchTab(tab.type)}
                className={`p-3 rounded-2xl text-left transition-all flex flex-col justify-between ${
                  isActive
                    ? 'bg-white text-gray-900 shadow-lg shadow-black/20 ring-2 ring-indigo-400'
                    : 'bg-white/10 text-white/80 hover:bg-white/15 hover:text-white'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <i className={`fa-solid ${tab.icon} text-sm ${isActive ? 'text-indigo-600' : 'text-indigo-300'}`}></i>
                  <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded-full ${
                    isActive ? 'bg-indigo-100 text-indigo-700' : 'bg-white/20 text-white'
                  }`}>
                    {tab.count}
                  </span>
                </div>
                <div>
                  <div className={`text-xs font-bold leading-tight ${isActive ? 'text-gray-900' : 'text-white'}`}>
                    {tab.label}
                  </div>
                  <div className={`text-[10px] truncate mt-0.5 ${isActive ? 'text-gray-500' : 'text-indigo-200/70'}`}>
                    {tab.subtitle}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* ================= FILTER & SEARCH BAR ================= */}
      <div className="bg-white p-4 rounded-2xl border border-gray-200 shadow-sm space-y-3">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          {/* Search Input */}
          <div className="relative flex-1">
            <i className="fa-solid fa-magnifying-glass absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 text-xs"></i>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={`Search ${ROADMAP_TABS.find(t => t.type === activeType)?.label} initiatives, tags, deliverables, or owners...`}
              className="w-full pl-9 pr-8 py-2 bg-gray-50 border border-gray-200 rounded-xl text-xs text-gray-800 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 text-xs p-1"
              >
                <i className="fa-solid fa-circle-xmark"></i>
              </button>
            )}
          </div>

          {/* Status & Priority Selectors */}
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Status Filter */}
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-semibold text-gray-500 hidden sm:inline">Status:</span>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as any)}
                className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-xs font-medium text-gray-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="All">All Statuses</option>
                <option value="In Progress">In Progress</option>
                <option value="Completed">Completed</option>
                <option value="Upcoming">Upcoming</option>
                <option value="Planned">Planned</option>
              </select>
            </div>

            {/* Priority Filter */}
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-semibold text-gray-500 hidden sm:inline">Priority:</span>
              <select
                value={priorityFilter}
                onChange={(e) => setPriorityFilter(e.target.value as any)}
                className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-xs font-medium text-gray-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="All">All Priorities</option>
                <option value="P0 - Critical">P0 - Critical</option>
                <option value="P1 - High">P1 - High</option>
                <option value="P2 - Medium">P2 - Medium</option>
              </select>
            </div>
          </div>
        </div>

        {/* Summary Count and Reset Action */}
        <div className="flex items-center justify-between text-xs text-gray-500 pt-2 border-t border-gray-100">
          <div className="flex items-center gap-2">
            <span>
              Showing <strong>{currentRoadmapItems.length}</strong> items in <strong>{ROADMAP_TABS.find(t => t.type === activeType)?.label} Roadmap</strong>
            </span>
            {isFiltered && (
              <span className="text-purple-600 font-medium">(Filtered)</span>
            )}
          </div>

          {isFiltered && (
            <button
              onClick={() => {
                setSearchQuery('');
                setStatusFilter('All');
                setPriorityFilter('All');
              }}
              className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold hover:underline flex items-center gap-1"
            >
              <i className="fa-solid fa-rotate-left text-[10px]"></i>
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* ================= MAIN ROADMAP VIEW CONTENT ================= */}

      {/* 1. STARTER ROADMAP VIEW */}
      {activeType === 'starter' && (
        <div className="space-y-4">
          <div className="bg-indigo-50/50 p-4 rounded-2xl border border-indigo-100 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-9 h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center text-sm shadow-sm">
                <i className="fa-solid fa-flag-checkered"></i>
              </div>
              <div>
                <h3 className="text-sm font-bold text-gray-900">MVP Starter Release Track</h3>
                <p className="text-xs text-gray-500">Phased sprint delivery roadmap guiding foundational setup through to public launch.</p>
              </div>
            </div>
            <span className="text-xs font-bold px-3 py-1 bg-white text-indigo-700 rounded-xl border border-indigo-200 shadow-2xs">
              Phase 3 of 5 In Flight
            </span>
          </div>

          <div className="space-y-4 relative before:absolute before:left-7 before:top-6 before:bottom-6 before:w-0.5 before:bg-indigo-100">
            {currentRoadmapItems.map((item, idx) => (
              <div
                key={item.id}
                onClick={() => setSelectedItem(item)}
                className="relative flex items-start space-x-4 bg-white p-5 rounded-2xl border border-gray-200 shadow-sm hover:border-indigo-300 hover:shadow-md transition-all cursor-pointer group"
              >
                {/* Step Circle */}
                <div className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 z-10 ${
                  item.status === 'Completed'
                    ? 'bg-green-500 text-white ring-4 ring-green-100'
                    : item.status === 'In Progress'
                    ? 'bg-indigo-600 text-white ring-4 ring-indigo-100 animate-pulse'
                    : 'bg-gray-100 text-gray-500 border border-gray-200'
                }`}>
                  {item.status === 'Completed' ? <i className="fa-solid fa-check"></i> : idx + 1}
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-1.5">
                    <div className="flex items-center gap-2">
                      <h4 className="text-base font-bold text-gray-900 group-hover:text-indigo-600 transition-colors">
                        {item.title}
                      </h4>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-gray-100 text-gray-600">
                        {item.quarter || item.dateRange}
                      </span>
                    </div>

                    <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                      <select
                        value={item.status}
                        onChange={(e) => handleUpdateStatus(item.id, e.target.value as any, e as any)}
                        className={`text-xs font-bold px-2.5 py-1 rounded-full border cursor-pointer focus:outline-none ${
                          item.status === 'Completed' ? 'bg-green-50 border-green-200 text-green-700' :
                          item.status === 'In Progress' ? 'bg-indigo-50 border-indigo-200 text-indigo-700' :
                          'bg-gray-50 border-gray-200 text-gray-600'
                        }`}
                      >
                        <option value="In Progress">In Progress</option>
                        <option value="Completed">Completed</option>
                        <option value="Upcoming">Upcoming</option>
                      </select>

                      <button
                        onClick={(e) => handleDeleteItem(item.id, e)}
                        className="p-1 hover:bg-rose-50 rounded-lg text-gray-300 hover:text-rose-500 transition-colors"
                        title="Delete Milestone"
                      >
                        <i className="fa-solid fa-trash text-xs"></i>
                      </button>
                    </div>
                  </div>

                  <p className="text-xs text-gray-500 leading-relaxed mb-3">
                    {item.description}
                  </p>

                  {/* Progress Bar */}
                  <div className="w-full bg-gray-100 rounded-full h-1.5 mb-3 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        item.status === 'Completed' ? 'bg-green-500' : 'bg-indigo-600'
                      }`}
                      style={{ width: `${item.progress || (item.status === 'Completed' ? 100 : 50)}%` }}
                    ></div>
                  </div>

                  {/* Deliverables Checklist with interactive clicks */}
                  {item.deliverables && (
                    <div className="bg-gray-50 p-3 rounded-xl border border-gray-100 mb-3" onClick={(e) => e.stopPropagation()}>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-gray-400 block mb-1.5">
                        Deliverable Target Checklist:
                      </span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                        {item.deliverables.map((del, dIdx) => {
                          const isDone = (completedDeliverables[item.id] || []).includes(dIdx) || item.status === 'Completed';
                          return (
                            <div
                              key={dIdx}
                              onClick={(e) => toggleDeliverableCheck(item.id, dIdx, e)}
                              className={`flex items-center gap-2 p-1.5 rounded-lg text-xs cursor-pointer select-none transition-colors ${
                                isDone ? 'bg-green-50/80 text-green-800' : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-200'
                              }`}
                            >
                              <i className={`fa-solid ${isDone ? 'fa-square-check text-green-600' : 'fa-square text-gray-300'} text-xs`}></i>
                              <span className={`text-[11px] truncate ${isDone ? 'line-through text-green-700' : ''}`}>{del}</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Owner and Linked Agent */}
                  <div className="flex flex-wrap items-center justify-between text-xs text-gray-500 pt-2 border-t border-gray-100">
                    <div className="flex items-center space-x-2">
                      {item.owner && (
                        <>
                          <img src={item.owner.avatar} alt={item.owner.name} className="w-5 h-5 rounded-full object-cover" />
                          <span className="text-[11px] text-gray-700 font-medium">Lead: {item.owner.name}</span>
                        </>
                      )}
                    </div>

                    {item.aiAgent && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (onNavigateToAgents) onNavigateToAgents();
                        }}
                        className="text-purple-600 hover:text-purple-800 text-[11px] font-semibold flex items-center gap-1 hover:underline"
                      >
                        <i className="fa-solid fa-robot text-[10px]"></i>
                        Run {item.aiAgent}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 2. FEATURES ROADMAP VIEW */}
      {activeType === 'features' && (
        <div className="space-y-6">
          {/* Release Version Tracks */}
          {['v2.4', 'v2.5', 'v3.0'].map(version => {
            const versionItems = currentRoadmapItems.filter(i => (i.releaseVersion || 'v2.4') === version);
            if (versionItems.length === 0) return null;

            return (
              <div key={version} className="bg-white rounded-3xl border border-gray-200 overflow-hidden shadow-sm">
                <div className="p-4 sm:p-5 bg-gradient-to-r from-gray-50 to-indigo-50/40 border-b border-gray-200 flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <span className="px-3 py-1 rounded-xl font-mono text-xs font-bold bg-indigo-600 text-white shadow-xs">
                      Release {version}
                    </span>
                    <div>
                      <h4 className="text-sm font-bold text-gray-900">
                        {version === 'v2.4' ? 'Live Copilot & Agent Chaining' :
                         version === 'v2.5' ? 'Code Exporter & Figma Two-Way Sync' :
                         'Enterprise RBAC & Custom Agent Sandbox'}
                      </h4>
                      <span className="text-[11px] text-gray-400">
                        {version === 'v2.4' ? 'Target: Q4 2026' : version === 'v2.5' ? 'Target: Q1 2027' : 'Target: Q2 2027'}
                      </span>
                    </div>
                  </div>
                  <span className="text-xs font-semibold text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-lg border border-indigo-100">
                    {versionItems.length} Features Planned
                  </span>
                </div>

                <div className="p-4 sm:p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                  {versionItems.map(feat => (
                    <div
                      key={feat.id}
                      onClick={() => setSelectedItem(feat)}
                      className="p-5 rounded-2xl border border-gray-200 bg-white shadow-2xs hover:border-indigo-300 hover:shadow-md transition-all flex flex-col justify-between group cursor-pointer"
                    >
                      <div>
                        <div className="flex items-start justify-between gap-2 mb-2">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-50 text-indigo-700">
                              {feat.priority || 'P1'}
                            </span>
                            <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-gray-100 text-gray-600">
                              Effort: {feat.effort || 'M'}
                            </span>
                            <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-700">
                              {feat.impact || 'High Impact'}
                            </span>
                          </div>

                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            feat.status === 'Completed' ? 'bg-green-100 text-green-700' :
                            feat.status === 'In Progress' ? 'bg-indigo-100 text-indigo-700' :
                            'bg-gray-100 text-gray-600'
                          }`}>
                            {feat.status}
                          </span>
                        </div>

                        <h4 className="text-sm font-bold text-gray-900 group-hover:text-indigo-600 transition-colors">
                          {feat.title}
                        </h4>
                        <p className="text-xs text-gray-500 mt-1 line-clamp-2 leading-relaxed">
                          {feat.description}
                        </p>
                      </div>

                      <div className="pt-3 border-t border-gray-100 mt-4 flex items-center justify-between text-xs text-gray-500">
                        {feat.owner && (
                          <div className="flex items-center space-x-2">
                            <img src={feat.owner.avatar} alt={feat.owner.name} className="w-5 h-5 rounded-full object-cover" />
                            <span className="text-[11px] text-gray-700">{feat.owner.name}</span>
                          </div>
                        )}
                        <span className="text-indigo-600 font-semibold text-[11px] group-hover:translate-x-0.5 transition-transform flex items-center gap-1">
                          Inspect Specs <i className="fa-solid fa-arrow-right text-[9px]"></i>
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* 3. NOW, NEXT, LATER ROADMAP VIEW */}
      {activeType === 'now-next-later' && (
        <div className="space-y-4">
          <div className="bg-purple-50/50 p-4 rounded-2xl border border-purple-100 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-9 h-9 rounded-xl bg-purple-600 text-white flex items-center justify-center text-sm shadow-sm">
                <i className="fa-solid fa-table-columns"></i>
              </div>
              <div>
                <h3 className="text-sm font-bold text-gray-900">Now, Next, Later Product Board</h3>
                <p className="text-xs text-gray-500">Continuous outcome-focused roadmap moving from immediate commitments to exploratory horizons.</p>
              </div>
            </div>
            <button
              onClick={() => setIsAddModalOpen(true)}
              className="px-3 py-1.5 bg-purple-600 hover:bg-purple-700 text-white font-semibold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-colors"
            >
              <i className="fa-solid fa-plus text-[10px]"></i>
              <span>Add Card</span>
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {(['now', 'next', 'later'] as const).map(horizonKey => {
              const horizonItems = currentRoadmapItems.filter(i => (i.horizon || 'now') === horizonKey);
              const headerColor = horizonKey === 'now' ? 'bg-indigo-600' : horizonKey === 'next' ? 'bg-purple-600' : 'bg-slate-700';
              const horizonTitle = horizonKey === 'now' ? 'NOW (In Flight)' : horizonKey === 'next' ? 'NEXT (Scoping)' : 'LATER (Discovery)';
              const horizonSubtitle = horizonKey === 'now' ? 'Committed & high confidence' : horizonKey === 'next' ? 'Validating requirements' : 'Future exploration';

              return (
                <div key={horizonKey} className="bg-slate-50 rounded-2xl border border-slate-200/90 p-4 flex flex-col justify-between shadow-2xs">
                  <div>
                    {/* Horizon Column Header */}
                    <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-200">
                      <div className="flex items-center gap-2">
                        <span className={`w-2.5 h-2.5 rounded-full ${headerColor}`}></span>
                        <div>
                          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800">{horizonTitle}</h4>
                          <span className="text-[10px] text-slate-400 block">{horizonSubtitle}</span>
                        </div>
                      </div>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-white text-slate-700 border border-slate-200">
                        {horizonItems.length}
                      </span>
                    </div>

                    {/* Cards Stack */}
                    <div className="space-y-3">
                      {horizonItems.map(item => (
                        <div
                          key={item.id}
                          onClick={() => setSelectedItem(item)}
                          className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs hover:border-purple-300 hover:shadow-sm transition-all cursor-pointer group"
                        >
                          <div className="flex items-start justify-between gap-2 mb-1.5">
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-50 text-purple-700">
                              {item.track || 'UX Core'}
                            </span>
                            <div className="flex items-center space-x-1" onClick={(e) => e.stopPropagation()}>
                              {horizonKey !== 'now' && (
                                <button
                                  onClick={(e) => handleMoveHorizon(item.id, horizonKey === 'later' ? 'next' : 'now', e)}
                                  className="p-1 hover:bg-slate-100 rounded text-slate-400 hover:text-indigo-600 transition-colors"
                                  title="Move Left"
                                >
                                  <i className="fa-solid fa-arrow-left text-[10px]"></i>
                                </button>
                              )}
                              {horizonKey !== 'later' && (
                                <button
                                  onClick={(e) => handleMoveHorizon(item.id, horizonKey === 'now' ? 'next' : 'later', e)}
                                  className="p-1 hover:bg-slate-100 rounded text-slate-400 hover:text-indigo-600 transition-colors"
                                  title="Move Right"
                                >
                                  <i className="fa-solid fa-arrow-right text-[10px]"></i>
                                </button>
                              )}
                            </div>
                          </div>

                          <h5 className="text-xs font-bold text-gray-900 group-hover:text-purple-600 transition-colors line-clamp-2">
                            {item.title}
                          </h5>
                          <p className="text-[11px] text-gray-500 mt-1 line-clamp-2 leading-relaxed">
                            {item.description}
                          </p>

                          {/* Chips */}
                          <div className="flex items-center gap-1.5 mt-2.5">
                            {item.priority && (
                              <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-gray-100 text-gray-700">
                                {item.priority.split(' - ')[0]}
                              </span>
                            )}
                            {item.effort && (
                              <span className="text-[9px] font-semibold px-1.5 py-0.5 rounded bg-blue-50 text-blue-700">
                                {item.effort} Effort
                              </span>
                            )}
                            {item.impact && (
                              <span className="text-[9px] font-semibold px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700">
                                {item.impact}
                              </span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Column Bottom Add */}
                  <button
                    onClick={() => {
                      setNewItemHorizon(horizonKey);
                      setIsAddModalOpen(true);
                    }}
                    className="w-full mt-3 py-2 bg-white hover:bg-slate-100 text-slate-600 border border-dashed border-slate-300 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <i className="fa-solid fa-plus text-[10px]"></i>
                    <span>Add to {horizonKey.toUpperCase()}</span>
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 4. STRATEGY ROADMAP VIEW */}
      {activeType === 'strategy' && (
        <div className="space-y-4">
          <div className="bg-amber-50/50 p-4 rounded-2xl border border-amber-100 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-9 h-9 rounded-xl bg-amber-600 text-white flex items-center justify-center text-sm shadow-sm">
                <i className="fa-solid fa-chess"></i>
              </div>
              <div>
                <h3 className="text-sm font-bold text-gray-900">Strategic Pillars & OKR Alignment</h3>
                <p className="text-xs text-gray-500">High-level strategic initiatives driving product architecture and measurable design leadership.</p>
              </div>
            </div>
            <button
              onClick={() => setIsAddModalOpen(true)}
              className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5"
            >
              <i className="fa-solid fa-plus text-[10px]"></i>
              <span>Add Strategic Pillar</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {currentRoadmapItems.map(pillar => (
              <div
                key={pillar.id}
                onClick={() => setSelectedItem(pillar)}
                className="bg-white rounded-3xl border border-gray-200 p-6 shadow-sm hover:border-amber-300 hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between mb-3">
                    <span className="px-2.5 py-1 rounded-xl text-xs font-bold bg-amber-50 text-amber-800 border border-amber-200">
                      {pillar.quarter || 'Annual Strategy'}
                    </span>
                    <span className="text-xs font-bold text-amber-700">
                      {pillar.progress}% Complete
                    </span>
                  </div>

                  <h4 className="text-base font-bold text-gray-900 group-hover:text-amber-700 transition-colors">
                    {pillar.title}
                  </h4>
                  <p className="text-xs text-gray-500 mt-1 leading-relaxed">
                    {pillar.description}
                  </p>

                  {/* Progress Bar */}
                  <div className="w-full bg-gray-100 rounded-full h-2 my-4 overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-amber-500 to-orange-500 h-full rounded-full transition-all duration-500"
                      style={{ width: `${pillar.progress}%` }}
                    ></div>
                  </div>

                  {/* Key Results / Deliverables */}
                  {pillar.deliverables && (
                    <div className="bg-amber-50/40 p-3.5 rounded-2xl border border-amber-100 space-y-2">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-amber-900 block">
                        Measurable Key Results (OKRs):
                      </span>
                      {pillar.deliverables.map((del, dIdx) => (
                        <div key={dIdx} className="flex items-start gap-2 text-xs text-gray-700">
                          <i className="fa-solid fa-circle-check text-amber-600 text-xs mt-0.5"></i>
                          <span className="leading-tight">{del}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="pt-4 border-t border-gray-100 mt-5 flex items-center justify-between text-xs text-gray-500">
                  {pillar.owner && (
                    <div className="flex items-center space-x-2">
                      <img src={pillar.owner.avatar} alt={pillar.owner.name} className="w-5 h-5 rounded-full object-cover" />
                      <span className="text-[11px] text-gray-700 font-medium">Champion: {pillar.owner.name}</span>
                    </div>
                  )}
                  <span className="text-amber-700 font-semibold text-xs group-hover:translate-x-0.5 transition-transform flex items-center gap-1">
                    Strategy Brief <i className="fa-solid fa-arrow-right text-[10px]"></i>
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 5. PORTFOLIO ROADMAP VIEW */}
      {activeType === 'portfolio' && (
        <div className="space-y-4">
          <div className="bg-blue-50/50 p-4 rounded-2xl border border-blue-100 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center text-sm shadow-sm">
                <i className="fa-solid fa-layer-group"></i>
              </div>
              <div>
                <h3 className="text-sm font-bold text-gray-900">Multi-Track Portfolio Matrix</h3>
                <p className="text-xs text-gray-500">Cross-squad progress timeline showing synchronizations, inter-team dependencies, and quarterly horizons.</p>
              </div>
            </div>
            <button
              onClick={() => setIsAddModalOpen(true)}
              className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5"
            >
              <i className="fa-solid fa-plus text-[10px]"></i>
              <span>Add Track Initiative</span>
            </button>
          </div>

          <div className="bg-white rounded-3xl border border-gray-200 overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-gray-50/80 border-b border-gray-200 text-[11px] font-bold text-gray-500 uppercase tracking-wider">
                    <th className="py-3.5 px-4">Track & Product Initiative</th>
                    <th className="py-3.5 px-4">Timeline / Horizon</th>
                    <th className="py-3.5 px-4">Progress</th>
                    <th className="py-3.5 px-4">Dependencies</th>
                    <th className="py-3.5 px-4">Owner</th>
                    <th className="py-3.5 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 text-xs text-gray-700">
                  {currentRoadmapItems.map(item => (
                    <tr
                      key={item.id}
                      onClick={() => setSelectedItem(item)}
                      className="hover:bg-blue-50/20 transition-colors group cursor-pointer"
                    >
                      <td className="py-3.5 px-4">
                        <div className="flex items-center space-x-3">
                          <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center flex-shrink-0 text-sm shadow-2xs">
                            <i className="fa-solid fa-layer-group"></i>
                          </div>
                          <div>
                            <span className="font-bold text-gray-900 group-hover:text-blue-600 transition-colors block">
                              {item.title}
                            </span>
                            <span className="text-[11px] text-gray-400 block mt-0.5 truncate max-w-xs">
                              {item.description}
                            </span>
                          </div>
                        </div>
                      </td>

                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-50 text-blue-700">
                          {item.quarter || item.dateRange}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <div className="flex items-center space-x-2">
                          <div className="w-20 bg-gray-100 rounded-full h-1.5 overflow-hidden">
                            <div className="bg-blue-600 h-full rounded-full" style={{ width: `${item.progress}%` }}></div>
                          </div>
                          <span className="text-[11px] font-semibold text-gray-700">{item.progress}%</span>
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="flex flex-wrap gap-1">
                          {(item.dependencies || ['Core API']).map((dep, dIdx) => (
                            <span key={dIdx} className="text-[10px] bg-gray-100 text-gray-600 px-2 py-0.5 rounded">
                              {dep}
                            </span>
                          ))}
                        </div>
                      </td>

                      <td className="py-3.5 px-4 whitespace-nowrap">
                        {item.owner && (
                          <div className="flex items-center space-x-2">
                            <img src={item.owner.avatar} alt={item.owner.name} className="w-5 h-5 rounded-full object-cover" />
                            <span className="text-gray-700 text-xs font-medium">{item.owner.name}</span>
                          </div>
                        )}
                      </td>

                      <td className="py-3.5 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => setSelectedItem(item)}
                          className="px-2.5 py-1.5 bg-gray-100 hover:bg-blue-50 hover:text-blue-700 text-gray-700 rounded-lg text-xs font-semibold transition-colors"
                        >
                          Details
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 6. CUSTOM ROADMAP VIEW */}
      {activeType === 'custom' && (
        <div className="space-y-4">
          <div className="bg-rose-50/50 p-4 rounded-2xl border border-rose-100 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-9 h-9 rounded-xl bg-rose-600 text-white flex items-center justify-center text-sm shadow-sm">
                <i className="fa-solid fa-sliders"></i>
              </div>
              <div>
                <h3 className="text-sm font-bold text-gray-900">Customizable Studio Roadmap</h3>
                <p className="text-xs text-gray-500">Design your own project timelines, custom deliverables, tags, and stages tailored to your design organization.</p>
              </div>
            </div>
            <button
              onClick={() => setIsAddModalOpen(true)}
              className="px-3.5 py-2 bg-rose-600 hover:bg-rose-700 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5"
            >
              <i className="fa-solid fa-plus text-[10px]"></i>
              <span>Create Custom Initiative</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {currentRoadmapItems.map(cust => (
              <div
                key={cust.id}
                onClick={() => setSelectedItem(cust)}
                className="bg-white rounded-3xl border border-gray-200 p-5 shadow-sm hover:border-rose-300 hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between mb-3">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-50 text-rose-700">
                      {cust.track || 'Custom Track'}
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-gray-100 text-gray-700">
                      {cust.status}
                    </span>
                  </div>

                  <h4 className="text-base font-bold text-gray-900 group-hover:text-rose-600 transition-colors">
                    {cust.title}
                  </h4>
                  <p className="text-xs text-gray-500 mt-1 line-clamp-3 leading-relaxed">
                    {cust.description}
                  </p>

                  {/* Deliverables */}
                  {cust.deliverables && (
                    <div className="mt-3.5 pt-3 border-t border-gray-100 space-y-1">
                      {cust.deliverables.map((del, dIdx) => (
                        <div key={dIdx} className="flex items-center gap-1.5 text-xs text-gray-600">
                          <i className="fa-solid fa-check text-rose-500 text-[10px]"></i>
                          <span className="truncate">{del}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="pt-3 border-t border-gray-100 mt-4 flex items-center justify-between text-xs text-gray-500">
                  <span className="font-semibold text-gray-700">{cust.quarter || 'Sprint A'}</span>
                  <button
                    onClick={(e) => handleDeleteItem(cust.id, e)}
                    className="p-1 hover:bg-rose-50 text-gray-300 hover:text-rose-500 rounded transition-colors"
                    title="Remove Initiative"
                  >
                    <i className="fa-solid fa-trash text-xs"></i>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= MODAL: ROADMAP ITEM INSPECTOR ================= */}
      {selectedItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden border border-gray-100">
            {/* Header */}
            <div className="p-6 border-b border-gray-100 flex items-start justify-between bg-gradient-to-r from-gray-50 to-indigo-50/30">
              <div className="flex items-start space-x-3.5">
                <div className="w-11 h-11 rounded-2xl bg-indigo-600 text-white flex items-center justify-center text-lg shadow-sm">
                  <i className="fa-solid fa-route"></i>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-100 text-indigo-700 uppercase">
                      {selectedItem.roadmapType}
                    </span>
                    <span className="text-xs text-gray-400">{selectedItem.quarter || selectedItem.dateRange}</span>
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 mt-1">{selectedItem.title}</h3>
                </div>
              </div>

              <button
                onClick={() => setSelectedItem(null)}
                className="p-2 text-gray-400 hover:text-gray-700 rounded-xl hover:bg-gray-100 transition-colors"
              >
                <i className="fa-solid fa-xmark text-lg"></i>
              </button>
            </div>

            {/* Body */}
            <div className="p-6 overflow-y-auto flex-1 space-y-5 text-xs text-gray-700">
              <div>
                <label className="font-bold text-gray-900 block mb-1">Initiative Overview</label>
                <p className="text-xs text-gray-600 leading-relaxed bg-gray-50 p-3 rounded-xl border border-gray-100">
                  {selectedItem.description}
                </p>
              </div>

              {/* Status and Priority Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <div className="bg-gray-50 p-2.5 rounded-xl border border-gray-200">
                  <span className="text-[10px] text-gray-400 font-bold uppercase block">Status</span>
                  <span className="font-bold text-indigo-700 mt-0.5 block">{selectedItem.status}</span>
                </div>
                <div className="bg-gray-50 p-2.5 rounded-xl border border-gray-200">
                  <span className="text-[10px] text-gray-400 font-bold uppercase block">Priority</span>
                  <span className="font-bold text-gray-900 mt-0.5 block">{selectedItem.priority || 'P1 - High'}</span>
                </div>
                <div className="bg-gray-50 p-2.5 rounded-xl border border-gray-200">
                  <span className="text-[10px] text-gray-400 font-bold uppercase block">Effort Size</span>
                  <span className="font-bold text-gray-900 mt-0.5 block">{selectedItem.effort || 'M'}</span>
                </div>
                <div className="bg-gray-50 p-2.5 rounded-xl border border-gray-200">
                  <span className="text-[10px] text-gray-400 font-bold uppercase block">Impact</span>
                  <span className="font-bold text-emerald-700 mt-0.5 block">{selectedItem.impact || 'High'}</span>
                </div>
              </div>

              {/* Deliverables Checklist */}
              {selectedItem.deliverables && selectedItem.deliverables.length > 0 && (
                <div>
                  <label className="font-bold text-gray-900 block mb-2">Deliverables Target Checklist</label>
                  <div className="space-y-1.5">
                    {selectedItem.deliverables.map((del, dIdx) => {
                      const isDone = (completedDeliverables[selectedItem.id] || []).includes(dIdx) || selectedItem.status === 'Completed';
                      return (
                        <div
                          key={dIdx}
                          onClick={() => toggleDeliverableCheck(selectedItem.id, dIdx)}
                          className={`p-2.5 rounded-xl border flex items-center justify-between cursor-pointer select-none transition-colors ${
                            isDone ? 'bg-green-50 border-green-200 text-green-900' : 'bg-white border-gray-200 hover:bg-gray-50'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <i className={`fa-solid ${isDone ? 'fa-circle-check text-green-600' : 'fa-circle text-gray-300'} text-sm`}></i>
                            <span className={isDone ? 'line-through text-green-800' : 'font-medium'}>{del}</span>
                          </div>
                          <span className="text-[10px] font-semibold text-gray-400">
                            {isDone ? 'Completed' : 'Pending'}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Linked AI Agent Action */}
              {selectedItem.aiAgent && (
                <div className="p-3 bg-purple-50 rounded-2xl border border-purple-100 flex items-center justify-between">
                  <div>
                    <span className="text-[11px] font-bold text-purple-900 block">
                      Recommended Studio Agent: {selectedItem.aiAgent}
                    </span>
                    <span className="text-[10px] text-purple-600">
                      Run automated design review and deliverable synthesis.
                    </span>
                  </div>
                  <button
                    onClick={() => {
                      setSelectedItem(null);
                      if (onNavigateToAgents) onNavigateToAgents();
                    }}
                    className="px-3 py-1.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-semibold shadow-2xs transition-colors flex items-center gap-1.5"
                  >
                    <i className="fa-solid fa-play text-[9px]"></i>
                    Run Agent
                  </button>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="p-4 bg-gray-50 border-t border-gray-100 flex justify-between items-center">
              <button
                onClick={(e) => handleDeleteItem(selectedItem.id, e)}
                className="text-rose-600 hover:text-rose-800 text-xs font-semibold hover:underline"
              >
                Delete from Roadmap
              </button>
              <button
                onClick={() => setSelectedItem(null)}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl text-xs shadow-sm transition-colors"
              >
                Close Details
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL: ADD ROADMAP ITEM ================= */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden border border-gray-100">
            {/* Header */}
            <div className="p-6 border-b border-gray-100 flex items-center justify-between bg-gradient-to-r from-gray-50 to-indigo-50/20">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 text-white flex items-center justify-center text-lg shadow-sm">
                  <i className="fa-solid fa-plus"></i>
                </div>
                <div>
                  <h3 className="text-base font-bold text-gray-900">Add Roadmap Initiative</h3>
                  <p className="text-xs text-gray-500">
                    Add new milestone to the <strong>{ROADMAP_TABS.find(t => t.type === activeType)?.label}</strong> roadmap.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-2 text-gray-400 hover:text-gray-700 rounded-xl hover:bg-gray-100 transition-colors"
              >
                <i className="fa-solid fa-xmark text-lg"></i>
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleCreateRoadmapItem} className="p-6 overflow-y-auto flex-1 space-y-4 text-xs">
              <div>
                <label className="font-bold text-gray-700 block mb-1">Initiative Title</label>
                <input
                  type="text"
                  required
                  value={newItemTitle}
                  onChange={(e) => setNewItemTitle(e.target.value)}
                  placeholder="e.g. Phase 4: Token Architecture Sync..."
                  className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                />
              </div>

              <div>
                <label className="font-bold text-gray-700 block mb-1">Description</label>
                <textarea
                  rows={2}
                  value={newItemDescription}
                  onChange={(e) => setNewItemDescription(e.target.value)}
                  placeholder="Goals and rationale for this roadmap initiative..."
                  className="w-full px-3.5 py-2 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-gray-700 block mb-1">Status</label>
                  <select
                    value={newItemStatus}
                    onChange={(e) => setNewItemStatus(e.target.value as any)}
                    className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-xs"
                  >
                    <option value="In Progress">In Progress</option>
                    <option value="Upcoming">Upcoming</option>
                    <option value="Planned">Planned</option>
                    <option value="Completed">Completed</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold text-gray-700 block mb-1">Priority</label>
                  <select
                    value={newItemPriority}
                    onChange={(e) => setNewItemPriority(e.target.value as any)}
                    className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-xs"
                  >
                    <option value="P0 - Critical">P0 - Critical</option>
                    <option value="P1 - High">P1 - High</option>
                    <option value="P2 - Medium">P2 - Medium</option>
                  </select>
                </div>
              </div>

              {activeType === 'now-next-later' && (
                <div>
                  <label className="font-bold text-gray-700 block mb-1">Horizon Column</label>
                  <select
                    value={newItemHorizon}
                    onChange={(e) => setNewItemHorizon(e.target.value as any)}
                    className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-xs"
                  >
                    <option value="now">NOW (In Flight)</option>
                    <option value="next">NEXT (Upcoming Cycle)</option>
                    <option value="later">LATER (Future Exploration)</option>
                  </select>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-gray-700 block mb-1">Target Horizon / Quarter</label>
                  <input
                    type="text"
                    value={newItemQuarter}
                    onChange={(e) => setNewItemQuarter(e.target.value)}
                    placeholder="e.g. Q4 2026, Sprint 6..."
                    className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-xs"
                  />
                </div>

                <div>
                  <label className="font-bold text-gray-700 block mb-1">Track / Category</label>
                  <input
                    type="text"
                    value={newItemTrack}
                    onChange={(e) => setNewItemTrack(e.target.value)}
                    placeholder="e.g. Design System, Web App..."
                    className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-gray-700 block mb-1">Deliverables (comma separated)</label>
                <input
                  type="text"
                  value={newItemDeliverables}
                  onChange={(e) => setNewItemDeliverables(e.target.value)}
                  placeholder="Design Spec, Color Contrast Matrix, Handoff Docs..."
                  className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-xs"
                />
              </div>

              {/* Footer */}
              <div className="pt-4 border-t border-gray-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold rounded-xl text-xs transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-semibold rounded-xl text-xs shadow-md shadow-indigo-200 transition-all hover:scale-[1.02]"
                >
                  Save to Roadmap
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

// --- Generic Placeholder View for others ---
export const PlaceholderView: React.FC<{ name: string; icon: string }> = ({ name, icon }) => (
    <ViewLayout title={name} description={`Manage your ${name.toLowerCase()} here.`}>
        <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
            <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className={`fa-solid ${icon} text-3xl text-gray-300`}></i>
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">{name} Coming Soon</h3>
            <p className="text-gray-500 max-w-md mx-auto">We are currently building the {name} module. Check back later for updates.</p>
            <button className="mt-6 px-6 py-2 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700">
                Notify Me
            </button>
        </div>
    </ViewLayout>
);

export const ABTestingView: React.FC = () => <PlaceholderView name="A/B Testing" icon="fa-code-compare" />;
export const UserResearchView: React.FC = () => <PlaceholderView name="User Research" icon="fa-users" />;
export const DocumentationView: React.FC = () => <PlaceholderView name="Documentation" icon="fa-book" />;
export const TutorialsView: React.FC = () => <PlaceholderView name="Tutorials" icon="fa-graduation-cap" />;
export const SupportView: React.FC = () => <PlaceholderView name="Support" icon="fa-life-ring" />;
export const ProfileView: React.FC = () => <PlaceholderView name="Profile" icon="fa-user-circle" />;
export const PreferencesView: React.FC = () => <PlaceholderView name="Preferences" icon="fa-cog" />;