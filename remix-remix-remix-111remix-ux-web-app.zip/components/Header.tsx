import React, { useState, useRef, useEffect } from 'react';
import { AppNotification, NotificationCategory } from '../types';
import { INITIAL_NOTIFICATIONS } from '../constants';

interface HeaderProps {
  collapsed: boolean;
  onNavigate?: (view: string) => void;
}

const Header: React.FC<HeaderProps> = ({ collapsed, onNavigate }) => {
  const [notifications, setNotifications] = useState<AppNotification[]>(INITIAL_NOTIFICATIONS);
  const [isOpen, setIsOpen] = useState(false);
  const [activeFilter, setActiveFilter] = useState<'all' | NotificationCategory>('all');
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on click outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  const unreadCount = notifications.filter(n => !n.read).length;

  const filteredNotifications = notifications.filter(n => {
    if (activeFilter === 'all') return true;
    return n.category === activeFilter;
  });

  const markAllAsRead = () => {
    setNotifications(notifications.map(n => ({ ...n, read: true })));
  };

  const markAsRead = (id: string) => {
    setNotifications(notifications.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const dismissNotification = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setNotifications(notifications.filter(n => n.id !== id));
  };

  const clearAllNotifications = () => {
    if (activeFilter === 'all') {
      setNotifications([]);
    } else {
      setNotifications(notifications.filter(n => n.category !== activeFilter));
    }
  };

  const handleActionClick = (notif: AppNotification, e: React.MouseEvent) => {
    e.stopPropagation();
    markAsRead(notif.id);
    setIsOpen(false);
    if (notif.actionView && onNavigate) {
      onNavigate(notif.actionView);
    }
  };

  const getCategoryCount = (category: NotificationCategory) => {
    return notifications.filter(n => n.category === category).length;
  };

  return (
    <div className={`fixed top-0 right-0 ${collapsed ? 'left-16' : 'left-64'} bg-white border-b border-gray-200 z-30 transition-all duration-300`}>
      <div className="flex items-center justify-between px-8 py-3.5">
        <div className="flex items-center space-x-6">
          <div>
            <h2 className="text-xl md:text-2xl font-bold text-gray-900">Dashboard</h2>
            <p className="text-xs md:text-sm text-gray-500">Welcome back, Sarah! Here's what's happening today.</p>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <div className="relative hidden md:block">
            <input 
              type="text" 
              placeholder="Search agents, knowledge, projects, files..." 
              className="w-72 lg:w-80 pl-10 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all" 
            />
            <i className="fa-solid fa-search absolute left-3.5 top-3 text-gray-400 text-xs"></i>
          </div>

          {/* Notification Bell Dropdown Container */}
          <div className="relative" ref={dropdownRef}>
            <button 
              id="notification-bell-btn"
              onClick={() => setIsOpen(!isOpen)}
              className={`relative p-2.5 rounded-xl border transition-all ${
                isOpen 
                  ? 'bg-indigo-50 border-indigo-200 text-indigo-600 shadow-sm' 
                  : 'text-gray-600 border-gray-200 hover:bg-gray-50 hover:text-gray-900'
              }`}
              title="Notifications & Activity"
              aria-label="Notifications"
            >
              <i className="fa-solid fa-bell text-base"></i>
              
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 flex h-4 min-w-4 px-1 items-center justify-center rounded-full bg-rose-500 text-[10px] font-bold text-white shadow-sm ring-2 ring-white animate-pulse">
                  {unreadCount}
                </span>
              )}
            </button>

            {/* Dropdown Panel */}
            {isOpen && (
              <div 
                id="notification-dropdown-panel"
                className="absolute right-0 top-full mt-2 w-80 sm:w-[420px] bg-white rounded-2xl shadow-2xl border border-gray-200 overflow-hidden z-50 animate-in fade-in slide-in-from-top-2 duration-200"
              >
                {/* Header */}
                <div className="p-4 bg-gray-50/80 border-b border-gray-100 flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <h3 className="font-bold text-gray-900 text-sm">Notifications</h3>
                    {unreadCount > 0 ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-100 text-indigo-700">
                        {unreadCount} new
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-gray-100 text-gray-600">
                        All read
                      </span>
                    )}
                  </div>

                  {unreadCount > 0 && (
                    <button 
                      onClick={markAllAsRead}
                      className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 transition-colors hover:underline flex items-center gap-1"
                    >
                      <i className="fa-solid fa-check-double text-[10px]"></i>
                      Mark all as read
                    </button>
                  )}
                </div>

                {/* Filter Tabs */}
                <div className="flex items-center gap-1 p-2 bg-white border-b border-gray-100 overflow-x-auto scrollbar-hide text-xs">
                  <button
                    onClick={() => setActiveFilter('all')}
                    className={`px-3 py-1.5 rounded-lg font-semibold transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                      activeFilter === 'all'
                        ? 'bg-gray-900 text-white'
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    <span>All</span>
                    <span className={`px-1.5 py-0.2 rounded-full text-[10px] ${
                      activeFilter === 'all' ? 'bg-white/20 text-white' : 'bg-gray-100 text-gray-600'
                    }`}>
                      {notifications.length}
                    </span>
                  </button>

                  <button
                    onClick={() => setActiveFilter('agent_run')}
                    className={`px-3 py-1.5 rounded-lg font-semibold transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                      activeFilter === 'agent_run'
                        ? 'bg-purple-600 text-white'
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    <i className="fa-solid fa-robot text-[10px]"></i>
                    <span>Agent Runs</span>
                    <span className={`px-1.5 py-0.2 rounded-full text-[10px] ${
                      activeFilter === 'agent_run' ? 'bg-white/20 text-white' : 'bg-purple-50 text-purple-700'
                    }`}>
                      {getCategoryCount('agent_run')}
                    </span>
                  </button>

                  <button
                    onClick={() => setActiveFilter('system')}
                    className={`px-3 py-1.5 rounded-lg font-semibold transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                      activeFilter === 'system'
                        ? 'bg-blue-600 text-white'
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    <i className="fa-solid fa-gear text-[10px]"></i>
                    <span>System</span>
                    <span className={`px-1.5 py-0.2 rounded-full text-[10px] ${
                      activeFilter === 'system' ? 'bg-white/20 text-white' : 'bg-blue-50 text-blue-700'
                    }`}>
                      {getCategoryCount('system')}
                    </span>
                  </button>

                  <button
                    onClick={() => setActiveFilter('alert')}
                    className={`px-3 py-1.5 rounded-lg font-semibold transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                      activeFilter === 'alert'
                        ? 'bg-amber-600 text-white'
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    <i className="fa-solid fa-triangle-exclamation text-[10px]"></i>
                    <span>Alerts</span>
                    <span className={`px-1.5 py-0.2 rounded-full text-[10px] ${
                      activeFilter === 'alert' ? 'bg-white/20 text-white' : 'bg-amber-50 text-amber-700'
                    }`}>
                      {getCategoryCount('alert')}
                    </span>
                  </button>
                </div>

                {/* Notifications Scroll List */}
                <div className="max-h-[380px] overflow-y-auto divide-y divide-gray-100">
                  {filteredNotifications.length === 0 ? (
                    <div className="p-8 text-center">
                      <div className="w-12 h-12 rounded-full bg-gray-100 text-gray-400 flex items-center justify-center mx-auto mb-3">
                        <i className="fa-solid fa-bell-slash text-base"></i>
                      </div>
                      <h4 className="text-xs font-bold text-gray-800">All caught up!</h4>
                      <p className="text-[11px] text-gray-500 mt-1">No notifications in this category right now.</p>
                    </div>
                  ) : (
                    filteredNotifications.map((notif) => (
                      <div 
                        key={notif.id}
                        onClick={() => markAsRead(notif.id)}
                        className={`p-3.5 hover:bg-gray-50 transition-colors cursor-pointer group flex items-start gap-3 relative ${
                          !notif.read ? 'bg-indigo-50/25' : ''
                        }`}
                      >
                        {/* Unread indicator bar */}
                        {!notif.read && (
                          <div className="absolute left-0 top-3 bottom-3 w-1 bg-indigo-600 rounded-r"></div>
                        )}

                        {/* Icon */}
                        <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 shadow-sm ${notif.iconBg}`}>
                          <i className={`fa-solid ${notif.icon} text-xs`}></i>
                        </div>

                        {/* Content */}
                        <div className="flex-grow min-w-0 pr-6">
                          <div className="flex items-center justify-between gap-1 mb-1">
                            <span className={`px-2 py-0.2 rounded text-[9px] font-extrabold uppercase tracking-wider ${notif.badgeColor}`}>
                              {notif.badgeText}
                            </span>
                            <span className="text-[10px] text-gray-400 font-medium whitespace-nowrap">
                              {notif.time}
                            </span>
                          </div>

                          <h4 className={`text-xs font-bold leading-snug truncate ${
                            !notif.read ? 'text-gray-900' : 'text-gray-700'
                          }`}>
                            {notif.title}
                          </h4>

                          <p className="text-[11px] text-gray-600 leading-relaxed mt-0.5 line-clamp-2">
                            {notif.message}
                          </p>

                          {/* Quick action button */}
                          {notif.actionLabel && (
                            <div className="mt-2 flex items-center gap-2">
                              <button
                                onClick={(e) => handleActionClick(notif, e)}
                                className="px-2.5 py-1 rounded-lg text-[10px] font-bold bg-white hover:bg-gray-100 text-indigo-700 border border-gray-200 shadow-2xs transition-colors flex items-center gap-1"
                              >
                                <span>{notif.actionLabel}</span>
                                <i className="fa-solid fa-arrow-right text-[8px]"></i>
                              </button>
                            </div>
                          )}
                        </div>

                        {/* Dismiss button */}
                        <button
                          onClick={(e) => dismissNotification(notif.id, e)}
                          className="opacity-0 group-hover:opacity-100 absolute right-2.5 top-3 p-1 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-200/60 transition-all text-xs"
                          title="Dismiss notification"
                        >
                          <i className="fa-solid fa-times"></i>
                        </button>
                      </div>
                    ))
                  )}
                </div>

                {/* Footer */}
                {filteredNotifications.length > 0 && (
                  <div className="p-2.5 bg-gray-50 border-t border-gray-100 flex items-center justify-between text-[11px] text-gray-500 px-4">
                    <span className="flex items-center gap-1">
                      <i className="fa-solid fa-circle-check text-green-500 text-[10px]"></i>
                      Auto-synced with active agents
                    </span>
                    <button 
                      onClick={clearAllNotifications}
                      className="text-gray-400 hover:text-rose-600 transition-colors font-medium"
                    >
                      Clear {activeFilter === 'all' ? 'all' : 'filtered'}
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>

          <button 
            onClick={() => onNavigate && onNavigate('support')}
            className="p-2.5 text-gray-600 hover:bg-gray-100 rounded-xl border border-gray-200 transition-colors"
            title="Help & Support"
          >
            <i className="fa-solid fa-question-circle text-base"></i>
          </button>

          <div className="h-7 w-px bg-gray-200"></div>

          <div 
            onClick={() => onNavigate && onNavigate('profile')}
            className="flex items-center space-x-3 cursor-pointer hover:bg-gray-50 p-1.5 rounded-xl border border-transparent hover:border-gray-200 transition-colors"
          >
            <img src="https://picsum.photos/100/100" alt="User" className="w-8 h-8 rounded-full object-cover border border-gray-200" />
            <div className="hidden sm:block">
              <p className="text-xs font-bold text-gray-900 leading-tight">Sarah Chen</p>
              <p className="text-[10px] text-gray-500 font-medium">UX Designer</p>
            </div>
            <i className="fa-solid fa-chevron-down text-gray-400 text-[10px] hidden sm:block"></i>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Header;
