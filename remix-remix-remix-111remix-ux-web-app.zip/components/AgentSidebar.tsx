import React, { useState, useEffect } from 'react';
import { Agent } from '../types';

interface AgentSidebarProps {
  agent: Agent | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (agent: Agent) => void;
}

const AgentSidebar: React.FC<AgentSidebarProps> = ({ agent, isOpen, onClose, onSave }) => {
  const [formData, setFormData] = useState<Partial<Agent>>({});

  useEffect(() => {
    if (agent) {
      setFormData({
        ...agent,
        systemPrompt: agent.systemPrompt || '',
        outputStructure: agent.outputStructure || '',
        hasChainOfThought: agent.hasChainOfThought || false
      });
    }
  }, [agent]);

  if (!isOpen || !agent) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (agent && formData) {
      onSave({ ...agent, ...formData } as Agent);
      onClose();
    }
  };

  return (
    <div className={`fixed inset-y-0 right-0 w-full max-w-md bg-white shadow-2xl z-50 transform transition-transform duration-300 ease-in-out ${isOpen ? 'translate-x-0' : 'translate-x-full'} flex flex-col`}>
      <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
        <div className="flex items-center space-x-3">
          <div className={`w-8 h-8 ${agent.iconBg} rounded-lg flex items-center justify-center`}>
            <i className={`fa-solid ${agent.icon} text-white text-sm`}></i>
          </div>
          <div>
            <h3 className="text-lg font-bold text-gray-900">Configure Tool</h3>
            <p className="text-xs text-gray-500">Fine-tune prompts and settings</p>
          </div>
        </div>
        <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition-colors">
          <i className="fa-solid fa-times text-lg"></i>
        </button>
      </div>
      
      <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-6">
        <div>
          <label className="block text-xs font-semibold text-gray-900 mb-1 uppercase">Tool Name *</label>
          <input
            type="text"
            value={formData.name || ''}
            onChange={(e) => setFormData({...formData, name: e.target.value})}
            className="w-full px-3 py-2 border border-indigo-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/50 text-sm"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-gray-900 mb-1 uppercase">Category</label>
            <select className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white">
              <option>User Research</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-900 mb-1 uppercase">Badge Theme</label>
            <select className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white">
              <option>Purple (Research / Strategy)</option>
            </select>
          </div>
        </div>

        <div>
            <label className="block text-xs font-semibold text-gray-900 mb-1 uppercase">Description *</label>
            <textarea
                rows={3}
                value={formData.description || ''}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
            />
        </div>

        <div>
            <label className="block text-xs font-semibold text-gray-900 mb-1 uppercase">Prompt Engineering (System Instruction) *</label>
            <textarea
                rows={6}
                value={formData.systemPrompt || ''}
                onChange={(e) => setFormData({...formData, systemPrompt: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm font-mono bg-gray-50"
            />
        </div>

        <div>
            <label className="block text-xs font-semibold text-gray-900 mb-1 uppercase">Output Structure & Formatting</label>
            <textarea
                rows={4}
                value={formData.outputStructure || ''}
                onChange={(e) => setFormData({...formData, outputStructure: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm font-mono bg-gray-50"
            />
        </div>

        <div className="flex items-center justify-between bg-gray-50 p-3 rounded-lg border border-gray-200">
            <div>
                <label className="block text-sm font-medium text-gray-900">Request Explicit Reasoning</label>
                <p className="text-xs text-gray-500">Explain methodology prior to final recommendations.</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
                <input 
                    type="checkbox" 
                    checked={formData.hasChainOfThought || false}
                    onChange={(e) => setFormData({...formData, hasChainOfThought: e.target.checked})}
                    className="sr-only peer" 
                />
                <div className="w-11 h-6 bg-gray-200 rounded-full peer peer-checked:bg-indigo-600 after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all"></div>
            </label>
        </div>
      </form>

      <div className="px-6 py-4 border-t border-gray-100 flex justify-between items-center bg-white">
        <button type="button" onClick={onClose} className="text-sm font-medium text-gray-700 hover:text-gray-900">Cancel</button>
        <button onClick={handleSubmit} className="px-6 py-2 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 shadow-sm flex items-center">
            <i className="fa-solid fa-save mr-2"></i> Save Changes
        </button>
      </div>
    </div>
  );
};

export default AgentSidebar;
