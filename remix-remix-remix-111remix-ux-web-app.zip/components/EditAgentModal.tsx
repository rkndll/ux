import React, { useState, useEffect } from 'react';
import { Agent } from '../types';

interface EditAgentModalProps {
  isOpen: boolean;
  agent: Agent | null;
  onClose: () => void;
  onSave: (agent: Agent) => void;
}

const EditAgentModal: React.FC<EditAgentModalProps> = ({ isOpen, agent, onClose, onSave }) => {
  const [formData, setFormData] = useState<Partial<Agent>>({});

  useEffect(() => {
    if (agent) {
      setFormData({
        ...agent,
        systemPrompt: agent.systemPrompt || '',
        outputStructure: agent.outputStructure || '',
        hasChainOfThought: agent.hasChainOfThought || false
      });
    }
  }, [agent]);

  if (!isOpen || !agent) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (agent && formData) {
      onSave({ ...agent, ...formData } as Agent);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl overflow-hidden transform transition-all scale-100 flex flex-col max-h-[90vh]">
        <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
          <div className="flex items-center space-x-3">
             <div className={`w-8 h-8 ${agent.iconBg} rounded-lg flex items-center justify-center`}>
                <i className={`fa-solid ${agent.icon} text-white text-sm`}></i>
            </div>
            <div>
                <h3 className="text-lg font-bold text-gray-900">Configure {agent.name}</h3>
                <p className="text-xs text-gray-500">Edit agent prompts and behavior</p>
            </div>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition-colors">
            <i className="fa-solid fa-times text-lg"></i>
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-6 overflow-y-auto">
          {/* General Settings */}
          <div className="grid grid-cols-2 gap-4">
             <div className="col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <input
                    type="text"
                    value={formData.description || ''}
                    onChange={(e) => setFormData({...formData, description: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500 text-sm"
                />
             </div>
          </div>

          <div className="border-t border-gray-100 pt-4">
            <h4 className="text-sm font-semibold text-gray-900 mb-3 flex items-center">
                <i className="fa-solid fa-wand-magic-sparkles text-indigo-500 mr-2"></i>
                Prompt Engineering
            </h4>
            
            <div className="space-y-4">
                <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1 uppercase tracking-wider">System Prompt</label>
                    <p className="text-xs text-gray-500 mb-2">Define the persona and primary instructions for the agent.</p>
                    <textarea
                        rows={4}
                        value={formData.systemPrompt || ''}
                        onChange={(e) => setFormData({...formData, systemPrompt: e.target.value})}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500 text-sm font-mono bg-gray-50"
                        placeholder="e.g., You are an expert UX researcher..."
                    />
                </div>

                <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1 uppercase tracking-wider">Output Structure</label>
                    <p className="text-xs text-gray-500 mb-2">Specify how the agent should format its response.</p>
                    <textarea
                        rows={2}
                        value={formData.outputStructure || ''}
                        onChange={(e) => setFormData({...formData, outputStructure: e.target.value})}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500 text-sm font-mono bg-gray-50"
                        placeholder="e.g., JSON format with fields: id, recommendation, severity"
                    />
                </div>

                <div className="flex items-center justify-between bg-gray-50 p-3 rounded-lg border border-gray-200">
                    <div>
                        <label className="block text-sm font-medium text-gray-900">Chain of Thought</label>
                        <p className="text-xs text-gray-500">Enable step-by-step reasoning before generating the final answer.</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                        <input 
                            type="checkbox" 
                            checked={formData.hasChainOfThought || false}
                            onChange={(e) => setFormData({...formData, hasChainOfThought: e.target.checked})}
                            className="sr-only peer" 
                        />
                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-indigo-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                    </label>
                </div>
            </div>
          </div>
        </form>

        <div className="px-6 py-4 border-t border-gray-100 flex justify-between bg-gray-50/50">
            <button
              type="button"
              className="text-red-600 hover:text-red-700 text-sm font-medium px-3 py-2 rounded-lg hover:bg-red-50"
            >
              Delete Agent
            </button>
            <div className="flex space-x-3">
                <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                >
                Cancel
                </button>
                <button
                onClick={handleSubmit}
                className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 shadow-sm"
                >
                Save Configuration
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};

export default EditAgentModal;
