import React, { useState } from 'react';
import { Agent } from '../types';

interface NewAgentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (agent: Partial<Agent>) => void;
}

const NewAgentModal: React.FC<NewAgentModalProps> = ({ isOpen, onClose, onSave }) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('UI Design');
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [systemPrompt, setSystemPrompt] = useState('');
  const [outputStructure, setOutputStructure] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Logic to map category to visual styles
    let icon = 'fa-robot';
    let iconBg = 'bg-gradient-to-br from-gray-500 to-gray-600';
    let tagColor = 'bg-gray-50 text-gray-700';

    switch (category) {
      case 'UI Design':
        icon = 'fa-palette';
        iconBg = 'bg-gradient-to-br from-blue-500 to-blue-600';
        tagColor = 'bg-blue-50 text-blue-700';
        break;
      case 'UX Research':
        icon = 'fa-brain';
        iconBg = 'bg-gradient-to-br from-purple-500 to-purple-600';
        tagColor = 'bg-indigo-50 text-indigo-700';
        break;
      case 'Quality Assurance':
        icon = 'fa-check-circle';
        iconBg = 'bg-gradient-to-br from-green-500 to-green-600';
        tagColor = 'bg-green-50 text-green-700';
        break;
      case 'Analytics':
        icon = 'fa-chart-pie';
        iconBg = 'bg-gradient-to-br from-pink-500 to-pink-600';
        tagColor = 'bg-pink-50 text-pink-700';
        break;
    }

    onSave({
      name,
      description,
      icon,
      iconBg,
      tags: [{ label: category, color: tagColor }],
      systemPrompt,
      outputStructure
    });

    // Reset form
    setName('');
    setDescription('');
    setCategory('UI Design');
    setSystemPrompt('');
    setOutputStructure('');
    setShowAdvanced(false);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden transform transition-all scale-100 max-h-[90vh] flex flex-col">
        <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50/50 flex-shrink-0">
          <h3 className="text-lg font-bold text-gray-900">Create New Agent</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition-colors">
            <i className="fa-solid fa-times text-lg"></i>
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto">
          <div>
            <label htmlFor="agentName" className="block text-sm font-medium text-gray-700 mb-1">Agent Name</label>
            <input
              id="agentName"
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Color Palette Generator"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-shadow"
            />
          </div>

          <div>
            <label htmlFor="agentDesc" className="block text-sm font-medium text-gray-700 mb-1">Description</label>
            <textarea
              id="agentDesc"
              required
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe what this agent does..."
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-shadow resize-none"
            />
          </div>

          <div>
            <label htmlFor="agentCategory" className="block text-sm font-medium text-gray-700 mb-1">Category & Style</label>
            <div className="relative">
              <select
                id="agentCategory"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary appearance-none bg-white transition-shadow"
              >
                <option value="UI Design">UI Design (Blue)</option>
                <option value="UX Research">UX Research (Purple)</option>
                <option value="Quality Assurance">Quality Assurance (Green)</option>
                <option value="Analytics">Analytics (Pink)</option>
              </select>
              <div className="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none text-gray-500">
                <i className="fa-solid fa-chevron-down text-xs"></i>
              </div>
            </div>
          </div>

          <div className="pt-2">
            <button 
              type="button" 
              onClick={() => setShowAdvanced(!showAdvanced)}
              className="flex items-center text-sm font-medium text-indigo-600 hover:text-indigo-700 transition-colors"
            >
              <i className={`fa-solid fa-chevron-${showAdvanced ? 'up' : 'down'} mr-2 text-xs`}></i>
              Advanced Configuration
            </button>

            {showAdvanced && (
              <div className="space-y-4 pt-4 animate-in fade-in slide-in-from-top-2 duration-200">
                <div>
                  <label htmlFor="systemPrompt" className="block text-xs font-medium text-gray-700 mb-1 uppercase tracking-wider">System Prompt</label>
                  <p className="text-xs text-gray-500 mb-2">Instructions for the agent's behavior and persona.</p>
                  <textarea
                    id="systemPrompt"
                    rows={3}
                    value={systemPrompt}
                    onChange={(e) => setSystemPrompt(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-shadow bg-gray-50 text-sm font-mono"
                    placeholder="e.g., You are an expert UX researcher..."
                  />
                </div>
                <div>
                  <label htmlFor="outputStructure" className="block text-xs font-medium text-gray-700 mb-1 uppercase tracking-wider">Output Structure</label>
                  <p className="text-xs text-gray-500 mb-2">Define how the response should be formatted.</p>
                  <textarea
                    id="outputStructure"
                    rows={2}
                    value={outputStructure}
                    onChange={(e) => setOutputStructure(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-shadow bg-gray-50 text-sm font-mono"
                    placeholder="e.g., JSON format with fields: recommendation, impact..."
                  />
                </div>
              </div>
            )}
          </div>

          <div className="pt-4 flex justify-end space-x-3 border-t border-gray-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium text-white bg-primary rounded-lg hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary shadow-sm"
            >
              Create Agent
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default NewAgentModal;