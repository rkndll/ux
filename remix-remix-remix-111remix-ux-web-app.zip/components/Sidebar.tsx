import React, { useState } from 'react';

interface SidebarProps {
  collapsed: boolean;
  toggleCollapse: () => void;
  currentView: string;
  onNavigate: (view: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ collapsed, toggleCollapse, currentView, onNavigate }) => {
  const [roadmapsOpen, setRoadmapsOpen] = useState(true);
  
  const NavItem = ({ view, icon, label, badge, badgeColor }: { view: string, icon: string, label: string, badge?: string, badgeColor?: string }) => {
    const isActive = currentView === view;
    return (
      <button 
        onClick={() => onNavigate(view)}
        className={`w-full flex items-center px-3 py-2.5 text-sm font-medium rounded-lg group relative transition-colors ${
          isActive 
            ? 'text-white bg-indigo-600' 
            : 'text-gray-700 hover:bg-gray-100'
        }`}
      >
        <i className={`fa-solid ${icon} w-5 text-center ${isActive ? 'text-white' : 'text-gray-400 group-hover:text-indigo-600'}`}></i>
        {!collapsed && (
          <>
            <span className="ml-3">{label}</span>
            {badge && (
              <span className={`ml-auto ${badgeColor || 'bg-indigo-600'} text-white text-xs px-2 py-0.5 rounded-full`}>
                {badge}
              </span>
            )}
          </>
        )}
        {isActive && !collapsed && <div className="absolute left-0 top-0 bottom-0 w-1 bg-white/20 rounded-r"></div>}
      </button>
    );
  };

  return (
    <div className={`fixed left-0 top-0 h-full bg-white border-r border-gray-200 flex flex-col transition-all duration-300 z-40 ${collapsed ? 'w-16' : 'w-64'}`}>
      <div className="p-6 border-b border-gray-200">
        <div className={`flex items-center justify-between ${collapsed ? 'justify-center' : ''}`}>
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => onNavigate('dashboard')}>
            <div className="w-10 h-10 min-w-[2.5rem] bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center shadow-lg shadow-indigo-200">
              <i className="fa-solid fa-wand-magic-sparkles text-white text-lg"></i>
            </div>
            {!collapsed && (
              <div className="overflow-hidden whitespace-nowrap">
                <h1 className="text-lg font-bold text-gray-900">UX AI Studio</h1>
                <p className="text-xs text-gray-500">Design Platform</p>
              </div>
            )}
          </div>
          {!collapsed && (
            <button onClick={toggleCollapse} className="text-gray-400 hover:text-gray-600">
              <i className="fa-solid fa-bars"></i>
            </button>
          )}
        </div>
        {collapsed && (
             <button onClick={toggleCollapse} className="mt-4 w-full text-center text-gray-400 hover:text-gray-600">
             <i className="fa-solid fa-bars"></i>
           </button>
        )}
      </div>

      <div className="flex-1 overflow-y-auto overflow-x-hidden py-4 scrollbar-hide">
        <div className="px-3 mb-6">
          {!collapsed && <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3 px-3">Main</div>}
          <nav className="space-y-1">
            <NavItem view="dashboard" icon="fa-chart-line" label="Dashboard" />
            <NavItem view="agents" icon="fa-robot" label="AI Agents" badge="12" />
            <NavItem view="knowledge" icon="fa-book-bookmark" label="Knowledge" badge="Hub" badgeColor="bg-purple-600" />
            

            <NavItem view="library" icon="fa-palette" label="Design Library" />
            <NavItem view="projects" icon="fa-folder-open" label="Projects" />
            <NavItem view="analytics" icon="fa-chart-bar" label="Analytics" />
          </nav>
        </div>

        <div className="px-3 mb-6">
          {!collapsed && <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3 px-3">AI Tools</div>}
          <nav className="space-y-1">
            <NavItem view="auto-generate" icon="fa-wand-sparkles" label="Auto-Generate" />
            <NavItem view="workflows" icon="fa-diagram-project" label="Workflows" />
            <NavItem view="suggestions" icon="fa-lightbulb" label="Suggestions" badge="3" badgeColor="bg-pink-500" />
          </nav>


        </div>

         <div className="px-3 mb-6">
          {!collapsed && <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3 px-3">Resources</div>}
          <nav className="space-y-1">
            <NavItem view="documentation" icon="fa-book" label="Documentation" />
            <NavItem view="tutorials" icon="fa-graduation-cap" label="Tutorials" />
            <NavItem view="support" icon="fa-life-ring" label="Support" />
          </nav>
        </div>

         <div className="px-3">
          {!collapsed && <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3 px-3">Settings</div>}
          <nav className="space-y-1">
            <NavItem view="profile" icon="fa-user-circle" label="Profile" />
            <NavItem view="preferences" icon="fa-cog" label="Preferences" />
          </nav>
        </div>
      </div>

      <div className="p-4 border-t border-gray-200">
        <div className={`bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg p-4 text-white shadow-lg shadow-indigo-200 ${collapsed ? 'flex flex-col items-center p-2' : ''}`}>
           {collapsed ? (
              <i className="fa-solid fa-crown text-yellow-300 text-xl"></i>
           ) : (
             <>
                <div className="flex items-center justify-between mb-2">
                    <i className="fa-solid fa-crown text-yellow-300"></i>
                    <button className="text-xs text-white/80 hover:text-white">
                        <i className="fa-solid fa-times"></i>
                    </button>
                </div>
                <h3 className="font-semibold text-sm mb-1">Upgrade to Pro</h3>
                <p className="text-xs text-white/90 mb-3">Unlock advanced AI features</p>
                <button className="w-full bg-white text-indigo-600 text-sm font-medium py-2 rounded-md hover:bg-gray-50 transition-colors shadow-sm">
                    Upgrade Now
                </button>
            </>
           )}
        </div>
      </div>
    </div>
  );
};

export default Sidebar;