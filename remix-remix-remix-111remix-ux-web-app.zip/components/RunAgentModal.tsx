import React, { useState, useEffect } from 'react';
import { Agent } from '../types';

interface RunAgentModalProps {
  isOpen: boolean;
  agent: Agent | null;
  onClose: () => void;
  onEdit: (agent: Agent) => void;
}

// Sample preset prompts and responses for each agent to provide instant rich interactivity
const PRESETS: Record<string, { sampleInput: string; sampleOutput: string }> = {
  "UX Design Reviewer": {
    sampleInput: "Review the checkout screen: Single page with accordion steps (Shipping, Billing, Review). The 'Pay Now' button is gray until all fields validate, with no inline error messages. Order summary is located below the fold on mobile.",
    sampleOutput: `### UX Heuristic Evaluation Report
**Evaluator:** UX Design Reviewer Agent (Nielsen Norman Heuristics)
**Score:** 64/100 (3 High Severity, 2 Medium Severity)

#### 1. Visibility of System Status (Heuristic #1) — SEVERITY: HIGH
- **Issue:** The disabled gray 'Pay Now' button provides zero visual feedback regarding which required fields are incomplete.
- **Recommendation:** Keep the button active; upon clicking, automatically scroll to and highlight incomplete fields with clear inline error messaging.

#### 2. Error Prevention & Recovery (Heuristic #5 & #9) — SEVERITY: HIGH
- **Issue:** Missing real-time inline validation causes form fatigue and abandonment at payment step.
- **Recommendation:** Implement instant green checkmarks for valid fields and contextual microcopy guidance (e.g. "Card number must be 16 digits").

#### 3. Match Between System and Real World (Heuristic #2) — SEVERITY: MEDIUM
- **Issue:** Order summary hidden below fold on mobile causes anxiety around total price and shipping surcharges.
- **Recommendation:** Pin a sticky compact order summary bar at top/bottom showing Total ($) with an expandable item breakdown drawer.`
  },
  "UX Documenter": {
    sampleInput: "Generate component specification and design tokens documentation for the new 'Floating Action Filter Bar' component on mobile.",
    sampleOutput: `## Component Specification: Floating Action Filter Bar

### 1. Overview
The Floating Action Filter Bar allows users to rapidly filter, sort, and slice high-density data tables and catalog grids on mobile viewports without sacrificing vertical screen real estate.

### 2. Design Tokens
- **Background:** \`var(--bg-glass-overlay)\` (rgba(255,255,255, 0.88), backdrop-blur: 16px)
- **Border:** \`1px solid var(--border-subtle)\` (#E2E8F0)
- **Elevation:** \`0 10px 25px -5px rgba(0, 0, 0, 0.08), 0 8px 10px -6px rgba(0, 0, 0, 0.04)\`
- **Border Radius:** \`9999px\` (Pill shape)
- **Min Height:** \`48px\` (Meets 48x48px WCAG Touch Target Requirement)

### 3. States & Interactions
| State | Visual Feedback | Micro-interaction |
| :--- | :--- | :--- |
| Default | Subtle gray border, 50% opacity icons | Transition: all 180ms ease |
| Active Filter | Indigo badge with counter, highlighted text | Spring scale 1.05 -> 1.0 |
| Scroll Down | Collapses horizontally to 56px circle icon | Smooth transition ease-out |
| Scroll Up | Re-expands to full width filter capsule | Immediate snap-in with 200ms delay |`
  },
  "User Persona Generator": {
    sampleInput: "Target Audience: Senior B2B SaaS Product Managers managing distributed agile teams across multiple time zones. High stress, fragmented communication tools.",
    sampleOutput: `### Primary Persona: Maya "The Orchestrator" Patel
**Role:** Senior Lead Product Manager | Enterprise SaaS
**Demographics:** Age 34, Hybrid (New York / Remote), Masters in HCI
**Tech Savvy:** 9.5 / 10 | Tools: Figma, Jira, Linear, Slack, Loom, Notion

#### Core Motivations
- Align engineering velocity with strategic business revenue goals.
- Eliminate context switching caused by duplicate status sync meetings.
- Maintain high design quality without creating PR review bottlenecks.

#### Frustrations & Pain Points
- "Stakeholders ask for status in 4 different channels every single day."
- Lack of centralized single-source-of-truth between design files and Jira tickets.
- Team member burnout from asynchronous communication lag.

#### Key Quotes
> *"If I have to manually paste Figma screenshots into three different slide decks one more time, my productivity for the sprint is gone."*`
  },
  "Brand Archetype Finder": {
    sampleInput: "Brand Name: 'CraftPulse' - An AI-augmented collaborative design workspace. Core values: Mastery, precision, playful exploration, unblocking creative flow.",
    sampleOutput: `### Brand Archetype Analysis: CraftPulse

**Primary Archetype:** The Creator (88% Affinity)
- **Core Desire:** To create things of enduring value and aesthetic brilliance.
- **Brand Voice:** Imaginative, precise, inspiring, empowering, non-conformist.
- **Motto:** "If you can imagine the interface, you can build it."

**Secondary Archetype:** The Magician (72% Affinity)
- **Influence:** Turning complex, tedious engineering tasks into frictionless, almost magical real-time experiences.

#### Visual & Design Language Implications
- **Color Palette:** Deep void slate (\`#0F172A\`), electric violet accent (\`#7C3AED\`), neon mint pulse (\`#10B981\`).
- **Typography:** Geometric neo-grotesque sans-serif with high-contrast monospace code accents.
- **Copy Stance:** Never sound corporate or bureaucratic. Speak like an artisan engineer crafting digital violin strings.`
  },
  "Brand archetypes": {
    sampleInput: "Generate complete Archetype Tone of Voice guidelines for a fintech app rooted in 'The Sage' and 'The Everyday Hero' archetypes.",
    sampleOutput: `## Archetype Voice & Tone Guidelines: The Empathetic Sage

### 1. Archetype Synthesis
Balancing **The Sage** (clarity, data-driven wisdom, unbiased guidance) with **The Everyday Hero** (approachable, humble, reliable ally for everyday working people).

### 2. The 4 Pillars of Tone
1. **Clear over Clever:** We explain complex interest rates in Plain English.
2. **Calm over Hype:** No sensationalist exclamation marks or FOMO crypto jargon.
3. **Transparent over Defensiveness:** Fees are stated prominently in 16px bold, never in 8px gray footnotes.
4. **Actionable over Academic:** Every insight must be accompanied by a 1-tap decision.

### 3. Vocabulary Matrix: Words We Use vs Avoid
- **USE:** "Grow sustainably", "Safety buffer", "Transparent rate", "Your funds are protected"
- **AVOID:** "10x your moonshot", "Disruptive yield", "Synergistic wealth accumulation"`
  },
  "Build personas": {
    sampleInput: "User Interview synthesis: 8 freelance UI/UX designers testing freelance invoice and client portal software.",
    sampleOutput: `### Persona Archetype: Leo "The Solo Artisan" Rossi
**Category:** Independent Freelance Product Designer
**Annual Billables:** $90k - $140k | Client Count: 3-5 concurrent

#### Empathy Map
- **Says:** "I want to spend 95% of my time designing and 0% chasing overdue wire transfers."
- **Thinks:** "Am I charging enough value-based pricing? Will this client renegotiate scope creep?"
- **Does:** Sends Figma prototypes via direct link, tracks hours in spreadsheets, drafts proposals in Notion.
- **Feels:** Anxious about inconsistent cashflow; proud of design autonomy and craftsmanship.

#### Top Feature Opportunities
1. 1-click Milestone approvals directly inside Figma embed.
2. Auto-generated friendly reminder emails triggered 3 days before payment due.`
  },
  "Summarise meeting notes": {
    sampleInput: "Meeting Notes: Design Sync Oct 21. Attendees: Dan, Elena, Marcus. Discussed checkout redesign. Elena suggested moving delivery date selector before payment. Dan worried it might lengthen step 2. Marcus showed user test clip where 4 of 5 users were confused by shipping carrier names. Agreed to rename 'Standard Ground' to 'Free 3-Day Delivery'. Marcus will update Figma by Thursday. Elena to sync with backend team on zip code validation API.",
    sampleOutput: `### Executive Summary: Design Sync (Oct 21)
**Topic:** Checkout Redesign & Shipping Usability | **Duration:** 45 mins

#### Key Decisions Made
1. **Shipping Label Rename:** Approved renaming 'Standard Ground' to **'Free 3-Day Delivery'** based on user testing showing 80% confusion rate.
2. **Delivery Step Order:** Maintained current step sequencing; agreed not to add extra sub-steps that lengthen funnel friction.

#### Action Items Matrix
| Owner | Task | Deadline | Status |
| :--- | :--- | :--- | :--- |
| **Marcus** | Update Figma checkout mockup with revised shipping copy | Thursday, Oct 23 | Pending |
| **Elena** | Sync with Backend Engineering regarding zip code API payload | Friday, Oct 24 | In Progress |

#### Open Questions
- Does third-party carrier SLA guarantee 3 business days for rural zip codes?`
  },
  "Summarise document": {
    sampleInput: "Summarise the 18-page PRD for 'Enterprise Role-Based Access Control & Audit Logs v3.2'.",
    sampleOutput: `### Executive UX Summary: Enterprise RBAC & Audit Logs PRD
**Target Release:** Q1 Enterprise Tier | **Document Length:** 18 Pages condensed to 4 Core Pillars

#### 1. Core Problem Statement
Enterprise compliance teams (SOC2, HIPAA) are unable to audit which external contractor viewed specific client PII data, blocking sales cycles for companies >500 seats.

#### 2. Key UX Requirements
- **Granular Permissions Matrix:** Replace binary Admin/Member roles with Custom Roles (5 default templates: Owner, Billing, Lead Designer, Reviewer, Guest).
- **Time-Bounded Access:** Temporary 24h / 7-day access pass with auto-revocation banner.
- **Searchable Audit Ledger:** Real-time filterable log by Actor, Action (Created, Exported, Deleted), IP Address, and Timestamp.

#### 3. Critical Edge Cases & Constraints
- Downgrades: If an org downgrades from Enterprise, custom roles must fall back gracefully to 'Member' with a 30-day read-only grace period.`
  },
  "User Journey Mapper": {
    sampleInput: "Customer journey for first-time user signing up for our AI Design Workspace from seeing a Twitter ad to exporting their first design file.",
    sampleOutput: `### User Journey Map: First-Time Creator Onboarding

| Stage | 1. Discovery | 2. First Landing | 3. Account Signup | 4. First AI Prompt | 5. Export Asset |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Touchpoint** | Twitter/X Video Demo | Landing Page Hero | Google 1-Tap OAuth | Interactive Canvas | Modal Download |
| **User Goal** | Understand what tool does | Verify pricing & speed | Get past login fast | See prompt turned to UI | Use in Figma/Code |
| **User Emotion** | Neutral (curious) | +1 (impressed) | -1 (friction/apprehension) | +2 (delighted/wow moment) | +2 (empowered) |
| **Pain Point** | Hard to tell if real or vaporware | Page load on mobile | Asking for credit card upfront | "What do I type in the prompt?" | Formats limited |
| **Opportunity** | Add verified customer review | Instant interactive sandbox | No credit card required badge | Curated 1-click starter prompts | Multi-format SVG/React export |`
  },
  "Wireframe Generator": {
    sampleInput: "Generate a responsive wireframe layout for a Team Settings & Billing Dashboard screen.",
    sampleOutput: `### Wireframe Layout Specification: Team Settings & Billing
\`\`\`
+------------------------------------------------------------------------+
| [UX AI Studio]   [Projects]  [Agents]  [Workflows]      (Avatar) [User] |
+------------------------------------------------------------------------+
|                                                                        |
|  SETTINGS & ORGANIZATION                                               |
|  [ General ]  [ Members & Roles ]  [* Billing & Plans *]  [ API Keys ] |
|  --------------------------------------------------------------------  |
|                                                                        |
|  +-------------------------------------+  +-------------------------+  |
|  | Current Plan: Enterprise Pro        |  | Payment Method          |  |
|  | $149/mo • Billed Annually           |  | Visa ending in 4242     |  |
|  | Next renewal: Dec 1, 2026           |  | Expires 08/28           |  |
|  | [ Upgrade Plan ]  [ Cancel Sub ]    |  | [ Edit Card ]           |  |
|  +-------------------------------------+  +-------------------------+  |
|                                                                        |
|  INVOICE HISTORY                                                       |
|  +-------------------------------------------------------------------+ |
|  | DATE         DESCRIPTION             AMOUNT      STATUS   INVOICE | |
|  | Nov 1, 2026  Enterprise Tier - 10 Seats  $149.00    Paid     [PDF]   | |
|  | Oct 1, 2026  Enterprise Tier - 10 Seats  $149.00    Paid     [PDF]   | |
|  +-------------------------------------------------------------------+ |
+------------------------------------------------------------------------+
\`\`\`
**Responsive Breakpoints:**
- Mobile (<640px): Stack Current Plan and Payment Method vertically; horizontal scroll for invoice table.`
  },
  "User Research Planner": {
    sampleInput: "Research Plan for validating an in-app AI copilot for junior UX designers.",
    sampleOutput: `### UX Research Plan: In-App AI Design Copilot

#### 1. Research Objectives
- Determine whether junior designers trust AI-suggested spacing and layout tokens.
- Identify the threshold where AI suggestions feel intrusive vs helpful.
- Benchmark task completion speed for building a responsive mobile navigation.

#### 2. Methodology & Demographics
- **Method:** 60-minute remote moderated usability testing + think-aloud protocol.
- **Cohort Size:** 8 Participants (Junior Product Designers with 6mo - 2yrs experience).
- **Incentive:** $120 honorarium per participant.

#### 3. 5-Question Core Interview Script
1. *"Walk me through the last time you handed off design specifications to an engineer. Where did friction occur?"*
2. *"When an AI tool suggests changing your color contrast, what is your initial gut reaction?"*
3. *"Looking at this suggestion panel on the right, how do you expect to preview the suggested layout change?"*
4. *"If the suggestion was wrong, what would be your ideal way to dismiss or train it?"*
5. *"On a scale of 1-10, how likely are you to keep this assistant panel docked open during your work day?"*`
  },
  "Focus Group Analyzer": {
    sampleInput: "Focus Group Transcript snippet: 6 users discussing mobile banking biometrics. P1: 'Face ID failed in sunlight twice'. P2: 'Fingerprint is faster'. P3: 'I worry about someone holding phone to my face'. P4: 'I love Face ID, hate typing PINs'.",
    sampleOutput: `### Focus Group Synthesis Report: Biometric Authentication

#### 1. Sentiment Distribution
- **Positive Sentiment:** 48% (Speed, convenience, elimination of 6-digit PIN cognitive load)
- **Negative / Anxiety Sentiment:** 36% (Coercion fear, environmental failure like direct sunlight / sunglasses)
- **Neutral / Pragmatic:** 16% (Desire for dual fallback)

#### 2. Emerging Themes & Verbatim Quotes
- **Theme A: Environmental Reliability:** *"Face ID failed in direct sunlight twice when I was trying to pay at a parking meter."* (P1, verified by P3)
- **Theme B: Physical Security Concerns:** Strong anxiety about involuntary biometric unlocking while asleep or distracted.

#### 3. Actionable UX Recommendation
- Implement **Graceful Degradation**: If biometric scan fails after 1.2s, auto-focus numeric PIN keypad instantly without error shake animation.`
  },
  "Focus Group Analyzer (Advanced)": {
    sampleInput: "Cross-cohort comparison between Gen Z (18-24) vs Gen X (45-60) users evaluating our auto-layout AI feature.",
    sampleOutput: `### Comparative Cohort Analysis: Gen Z vs Gen X

| Dimension | Cohort A: Gen Z (Digital Natives) | Cohort B: Gen X (Experienced Leads) |
| :--- | :--- | :--- |
| **Trust in Automation** | **High (82%)** — Expects the tool to guess intent automatically | **Moderate (48%)** — Demands manual override & inspection |
| **Onboarding Patience** | **<45 seconds** before abandoning tutorial video | **Willing to read** 3-step tooltip documentation |
| **Top Request** | TikTok-style swipeable variations & generative presets | Git-style versioning and branch comparison |
| **Consensus Point** | Both cohorts universally agreed that keyboard shortcut \`Cmd+Shift+A\` was intuitive. |`
  },
  "UX Writer": {
    sampleInput: "Write copy options for an error modal when user's payment card is declined due to insufficient funds. Need 3 variations: Direct, Empathetic, and Humorous/Friendly.",
    sampleOutput: `### UX Microcopy Matrix: Card Declined (Insufficient Funds)

| Variation | Headline | Body Copy | Primary CTA | Secondary CTA |
| :--- | :--- | :--- | :--- | :--- |
| **1. Empathetic (Recommended)** | We couldn't process this payment | Your bank was unable to complete the charge. You can try a different card or check with your bank. | **Try Another Card** | Contact Support |
| **2. Concise & Direct** | Payment declined | Please check your card balance or choose another payment method to continue. | **Change Payment Method** | Cancel |
| **3. Conversational** | Small bump in the road | That card didn't go through this time. No worries—your items are saved in your cart. | **Use a Different Card** | Save for Later |

#### Accessibility & Tone Audit
- **Reading Level:** Grade 4 (accessible to non-native English speakers)
- **Blame Free:** Does not shame the user with phrases like "You have insufficient balance".`
  },
  "UAT Creator": {
    sampleInput: "Create UAT test cases for user resetting password via magic link email flow.",
    sampleOutput: `### UAT Test Suite: Magic Link Password Reset Flow

| Test ID | Scenario Description | Pre-conditions | Test Steps | Expected Result | Pass/Fail |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **UAT-001** | Valid email triggers magic link | User account exists with valid email | 1. Enter email<br>2. Click 'Send Link' | Green banner shows: "Link sent. Check inbox". Email received within 30s. | [ ] PASS |
| **UAT-002** | Expired magic link handling | Link sent >15 mins ago | 1. Click expired link in email | Lands on friendly error page with 1-click 'Resend Link' button. | [ ] PASS |
| **UAT-003** | Single-use token invalidation | Link already clicked once | 1. Click same email link again | Displays message: "This link was already used. Request a fresh one". | [ ] PASS |
| **UAT-004** | Non-existent email security | Email not registered in DB | 1. Enter fake@domain.com<br>2. Click 'Send Link' | Shows identical generic success message to prevent user enumeration. | [ ] PASS |`
  }
};

export const RunAgentModal: React.FC<RunAgentModalProps> = ({ isOpen, agent, onClose, onEdit }) => {
  const [inputPrompt, setInputPrompt] = useState('');
  const [output, setOutput] = useState('');
  const [isRunning, setIsRunning] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (agent) {
      const preset = PRESETS[agent.name] || {
        sampleInput: `Please run ${agent.name} on my design requirements and deliver actionable UX recommendations.`,
        sampleOutput: `### Execution Output: ${agent.name}\n\nProcessed prompt successfully based on ${agent.systemPrompt || 'configured system guidelines'}.\n\n- Status: Completed with 100% confidence\n- Output structure: ${agent.outputStructure || 'Standard UX format'}\n- Latency: 420ms`
      };
      setInputPrompt(preset.sampleInput);
      setOutput(preset.sampleOutput);
    }
  }, [agent]);

  if (!isOpen || !agent) return null;

  const handleRun = () => {
    setIsRunning(true);
    setOutput('');
    setTimeout(() => {
      const preset = PRESETS[agent.name];
      if (preset && inputPrompt.trim() === preset.sampleInput.trim()) {
        setOutput(preset.sampleOutput);
      } else {
        setOutput(`### Output from ${agent.name}\n\n**Processed Request:**\n> "${inputPrompt}"\n\n**Key Findings & Recommendations:**\n1. **High Priority UX Action:** Align interface layout with standard user expectations to eliminate hesitation.\n2. **Cognitive Load Optimization:** Reduce competing calls-to-action to a single primary pathway.\n3. **Accessibility (WCAG 2.1 AA):** Ensure minimum contrast ratio of 4.5:1 and verify tab navigation order.\n\n*Generated by ${agent.name} using system prompt: "${(agent.systemPrompt || 'UX Intelligence System').slice(0, 80)}..."*`);
      }
      setIsRunning(false);
    }, 650);
  };

  const handleCopy = () => {
    if (output) {
      navigator.clipboard.writeText(output);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl overflow-hidden transform transition-all flex flex-col max-h-[92vh] border border-gray-200">
        
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50/80">
          <div className="flex items-center space-x-3">
            <div className={`w-10 h-10 ${agent.iconBg} rounded-xl flex items-center justify-center shadow-sm`}>
              <i className={`fa-solid ${agent.icon} text-white text-lg`}></i>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-lg font-bold text-gray-900">{agent.name}</h3>
                <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-green-100 text-green-700">
                  {agent.status}
                </span>
              </div>
              <p className="text-xs text-gray-500 line-clamp-1">{agent.description}</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <button 
              onClick={() => { onClose(); onEdit(agent); }}
              className="px-3 py-1.5 text-xs font-medium text-gray-600 hover:text-gray-900 hover:bg-gray-200/60 rounded-lg transition-colors flex items-center"
              title="Edit Agent Prompts"
            >
              <i className="fa-solid fa-gear mr-1.5"></i>
              Configure
            </button>
            <button 
              onClick={onClose} 
              className="w-8 h-8 rounded-lg flex items-center justify-center text-gray-400 hover:text-gray-600 hover:bg-gray-100 transition-colors"
            >
              <i className="fa-solid fa-times text-base"></i>
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-grow space-y-6">
          
          {/* Agent Meta Chips */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="text-gray-400 font-medium mr-1">Tags:</span>
            {agent.tags.map((t, i) => (
              <span key={i} className={`px-2.5 py-0.5 rounded-md font-medium ${t.color}`}>
                {t.label}
              </span>
            ))}
            <span className="text-gray-300">|</span>
            <span className="text-gray-500">Success Rate: <strong className="text-green-600">{agent.successRate}</strong></span>
            <span className="text-gray-300">|</span>
            <span className="text-gray-500">Historical: <strong>{agent.statDetail}</strong></span>
          </div>

          {/* Input Box */}
          <div>
            <div className="flex justify-between items-center mb-2">
              <label className="text-xs font-bold uppercase tracking-wider text-gray-700">
                Input Prompt / Context for {agent.name}
              </label>
              <button 
                onClick={() => {
                  const preset = PRESETS[agent.name];
                  if (preset) setInputPrompt(preset.sampleInput);
                }}
                className="text-xs text-indigo-600 hover:text-indigo-800 font-medium hover:underline flex items-center"
              >
                <i className="fa-solid fa-arrow-rotate-left mr-1"></i>
                Load Sample Scenario
              </button>
            </div>
            <textarea
              rows={4}
              value={inputPrompt}
              onChange={(e) => setInputPrompt(e.target.value)}
              placeholder={`Enter instructions or context for ${agent.name}...`}
              className="w-full p-3.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all resize-y font-sans"
            />
          </div>

          {/* Action Bar */}
          <div className="flex justify-between items-center pt-1">
            <div className="text-xs text-gray-400">
              {agent.hasChainOfThought ? (
                <span className="flex items-center text-purple-600 font-medium">
                  <i className="fa-solid fa-brain mr-1.5"></i>
                  Chain-of-Thought Reasoning Enabled
                </span>
              ) : (
                <span className="flex items-center text-gray-500">
                  <i className="fa-solid fa-bolt mr-1.5 text-amber-500"></i>
                  Fast Single-Pass Inference
                </span>
              )}
            </div>

            <button
              onClick={handleRun}
              disabled={isRunning || !inputPrompt.trim()}
              className={`px-5 py-2.5 rounded-xl font-medium text-sm flex items-center shadow-md transition-all ${
                isRunning 
                  ? 'bg-indigo-400 text-white cursor-wait' 
                  : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-200 hover:shadow-lg'
              }`}
            >
              {isRunning ? (
                <>
                  <i className="fa-solid fa-circle-notch fa-spin mr-2"></i>
                  Executing {agent.name}...
                </>
              ) : (
                <>
                  <i className="fa-solid fa-play mr-2 text-xs"></i>
                  Run Agent Now
                </>
              )}
            </button>
          </div>

          {/* Output Display */}
          <div>
            <div className="flex justify-between items-center mb-2">
              <label className="text-xs font-bold uppercase tracking-wider text-gray-700 flex items-center">
                <span>Agent Output</span>
                {output && (
                  <span className="ml-2 px-2 py-0.5 rounded text-[10px] bg-indigo-50 text-indigo-700 font-mono">
                    Structured Result
                  </span>
                )}
              </label>

              {output && (
                <button
                  onClick={handleCopy}
                  className="text-xs text-gray-500 hover:text-gray-800 font-medium flex items-center px-2 py-1 rounded hover:bg-gray-100 transition-colors"
                >
                  <i className={`fa-solid ${copied ? 'fa-check text-green-600' : 'fa-copy'} mr-1.5`}></i>
                  {copied ? 'Copied to Clipboard!' : 'Copy Result'}
                </button>
              )}
            </div>

            <div className="bg-slate-900 text-slate-100 rounded-xl p-5 border border-slate-800 min-h-[220px] font-mono text-xs leading-relaxed overflow-x-auto shadow-inner">
              {isRunning ? (
                <div className="flex flex-col items-center justify-center py-12 space-y-3">
                  <div className="w-8 h-8 border-2 border-indigo-400 border-t-transparent rounded-full animate-spin"></div>
                  <p className="text-slate-400 text-xs font-sans">Synthesizing UX output with {agent.name}...</p>
                </div>
              ) : output ? (
                <pre className="whitespace-pre-wrap font-sans text-sm text-slate-100 selection:bg-indigo-600 selection:text-white">
                  {output}
                </pre>
              ) : (
                <div className="flex flex-col items-center justify-center py-12 text-slate-500 font-sans">
                  <i className="fa-solid fa-terminal text-2xl mb-2 text-slate-600"></i>
                  <p>Click "Run Agent Now" to generate output</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 bg-gray-50 border-t border-gray-100 flex justify-between items-center text-xs text-gray-500">
          <span>System Output Architecture: <code className="bg-gray-200 px-1 py-0.5 rounded text-[11px] text-gray-800">{agent.outputStructure || 'Markdown Report'}</code></span>
          <button 
            onClick={onClose}
            className="px-4 py-2 bg-white border border-gray-200 hover:bg-gray-100 text-gray-700 font-medium rounded-lg transition-colors"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};

export default RunAgentModal;
