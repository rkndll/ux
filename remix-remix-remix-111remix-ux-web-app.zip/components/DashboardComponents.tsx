import React from 'react';
import { Agent, Stat, Activity, TeamMember } from '../types';

export const StatCard: React.FC<{ stat: Stat }> = ({ stat }) => (
  <div className="bg-white p-6 rounded-xl border border-gray-200 hover:shadow-md transition-shadow">
    <div className="flex items-center justify-between mb-3">
        <div className={`w-12 h-12 ${stat.bgClass} rounded-lg flex items-center justify-center`}>
            <i className={`fa-solid ${stat.icon} ${stat.colorClass} text-xl`}></i>
        </div>
        <span className={`text-xs ${stat.trend.startsWith('+') ? 'text-green-600 bg-green-50' : stat.trend === '--' ? 'text-gray-600 bg-gray-50' : 'text-red-600 bg-red-50'} px-2 py-1 rounded-full font-medium`}>
            {stat.trend}
        </span>
    </div>
    <h3 className="text-2xl font-bold text-gray-800 mb-1">{stat.value}</h3>
    <p className="text-sm text-gray-500">{stat.label}</p>
  </div>
);

export const AgentCard: React.FC<{ 
  agent: Agent; 
  onEdit: (agent: Agent) => void;
  onRun?: (agent: Agent) => void;
  onDuplicate?: (agent: Agent) => void;
}> = ({ agent, onEdit, onRun, onDuplicate }) => (
  <div className="bg-white rounded-xl border border-gray-200 hover:border-indigo-300 transition-all hover:shadow-md group">
    <div className="p-5 flex flex-col md:flex-row gap-5">
        {/* Icon Section */}
        <div className={`w-14 h-14 ${agent.iconBg} rounded-xl flex flex-shrink-0 items-center justify-center shadow-sm group-hover:scale-105 transition-transform`}>
            <i className={`fa-solid ${agent.icon} text-white text-2xl`}></i>
        </div>

        {/* Content Section */}
        <div className="flex-grow">
            <div className="flex items-start justify-between mb-1 gap-2">
                <h3 className="text-base md:text-lg font-bold text-gray-900 group-hover:text-indigo-600 transition-colors">
                  {agent.name}
                </h3>
                
                {/* Actions */}
                <div className="flex items-center space-x-1 flex-shrink-0">
                    <button 
                        onClick={() => onRun ? onRun(agent) : onEdit(agent)}
                        className="px-2.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors flex items-center shadow-sm shadow-indigo-100" 
                        title="Run this Agent"
                    >
                         <i className="fa-solid fa-play text-[10px] mr-1.5"></i>
                         Run
                    </button>
                    <button 
                        onClick={() => onEdit(agent)}
                        className="p-1.5 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-colors" 
                        title="Edit Configuration"
                    >
                         <i className="fa-solid fa-pen-to-square"></i>
                    </button>
                    <button 
                        onClick={() => onDuplicate && onDuplicate(agent)}
                        className="p-1.5 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-colors" 
                        title="Duplicate Agent"
                    >
                         <i className="fa-solid fa-copy"></i>
                    </button>
                </div>
            </div>

            <p className="text-sm text-gray-600 mb-3 leading-relaxed">{agent.description}</p>

            {/* Status and Tags */}
            <div className="flex items-center flex-wrap gap-2 mb-2">
                 <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${agent.status === 'Active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}`}>
                    <span className={`w-1.5 h-1.5 rounded-full mr-1.5 ${agent.status === 'Active' ? 'bg-green-500 animate-pulse' : 'bg-gray-400'}`}></span>
                    {agent.status}
                </span>
                {agent.tags.map((tag, idx) => (
                     <span key={idx} className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${tag.color}`}>
                        {tag.label}
                    </span>
                ))}
            </div>
        </div>
    </div>
    
    {/* Footer */}
    <div className="px-5 py-3 border-t border-gray-100 flex items-center justify-between bg-gray-50/50 rounded-b-xl">
         <div className="flex items-center space-x-6 text-xs text-gray-500">
            <span>Last run: <span className="font-medium text-gray-700">{agent.lastRun}</span></span>
            <span>Success rate: <span className="font-semibold text-green-600">{agent.successRate}</span></span>
         </div>
         <div className="text-xs text-gray-400 font-mono">{agent.statDetail}</div>
    </div>
  </div>
);

export const ActivityItem: React.FC<{ activity: Activity }> = ({ activity }) => (
  <div className="flex items-start space-x-4 pb-4 border-b border-gray-100 last:border-0 last:pb-0">
    <div className={`w-10 h-10 ${activity.iconBg} rounded-lg flex items-center justify-center flex-shrink-0`}>
        <i className={`fa-solid ${activity.icon} ${activity.iconColor}`}></i>
    </div>
    <div className="flex-1">
        <h4 className="text-sm font-medium text-gray-800 mb-1">{activity.title}</h4>
        <p className="text-xs text-gray-500 mb-2">{activity.description}</p>
        <span className="text-xs text-gray-400">{activity.time}</span>
    </div>
  </div>
);

export const TeamMemberItem: React.FC<{ member: TeamMember }> = ({ member }) => (
    <div className="flex items-start space-x-3">
        <img src={member.avatar} alt="Team member" className="w-8 h-8 rounded-full object-cover" />
        <div className="flex-1">
            <p className="text-sm text-gray-900"><span className="font-semibold">{member.name}</span> {member.action}</p>
            <p className="text-xs text-gray-500">{member.time}</p>
        </div>
    </div>
);
