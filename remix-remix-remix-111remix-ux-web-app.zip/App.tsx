import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import { StatCard, AgentCard, ActivityItem } from './components/DashboardComponents';
import { STATS, AGENTS, ACTIVITIES } from './constants';
import NewAgentModal from './components/NewAgentModal';
import EditAgentSidebar from './components/AgentSidebar';
import RunAgentModal from './components/RunAgentModal';
import { Agent } from './types';
import { 
  DesignLibraryView, 
  ProjectsView, 
  AnalyticsView, 
  AutoGenerateView, 
  SuggestionsView, 
  ABTestingView,
  UserResearchView,
  DocumentationView,
  TutorialsView,
  SupportView,
  ProfileView,
  PreferencesView,
  AgentsView,
  WorkflowsView, // Imported WorkflowsView
  KnowledgeView,
  RoadmapsView
} from './components/Views';

const App: React.FC = () => {
  const [agents, setAgents] = useState<Agent[]>(AGENTS);
  const [isNewModalOpen, setIsNewModalOpen] = useState(false);
  const [editingAgent, setEditingAgent] = useState<Agent | null>(null);
  const [runningAgent, setRunningAgent] = useState<Agent | null>(null);
  const [collapsed, setCollapsed] = useState(false);
  const [currentView, setCurrentView] = useState('dashboard');
  
  // Dashboard agent filtering & search
  const [dashboardFilter, setDashboardFilter] = useState<'All' | 'Active' | 'Idle'>('All');
  const [dashboardSearch, setDashboardSearch] = useState('');
  const [showAllDashboardAgents, setShowAllDashboardAgents] = useState(false);

  const toggleCollapse = () => {
    setCollapsed(!collapsed);
  };

  const handleCreateAgent = (agentData: Partial<Agent>) => {
    const newAgent: Agent = {
      id: (agents.length + 1).toString(),
      name: agentData.name || 'New Agent',
      description: agentData.description || '',
      icon: agentData.icon || 'fa-robot',
      iconBg: agentData.iconBg || 'bg-gradient-to-br from-indigo-500 to-indigo-600',
      status: 'Active',
      statusColor: 'bg-green-100 text-green-700',
      tags: agentData.tags || [{ label: 'Custom', color: 'bg-indigo-50 text-indigo-700' }],
      lastRun: 'Never',
      successRate: '100%',
      statDetail: '0 runs',
      systemPrompt: agentData.systemPrompt || '',
      outputStructure: agentData.outputStructure || 'Standard Markdown Report',
      hasChainOfThought: false
    };
    
    setAgents([newAgent, ...agents]);
    setIsNewModalOpen(false);
  };

  const handleUpdateAgent = (updatedAgent: Agent) => {
    setAgents(agents.map(a => a.id === updatedAgent.id ? updatedAgent : a));
    setEditingAgent(null);
  };

  const handleDuplicateAgent = (agent: Agent) => {
    const duplicated: Agent = {
      ...agent,
      id: Date.now().toString(),
      name: `${agent.name} (Copy)`,
      lastRun: 'Never',
      statDetail: '0 runs'
    };
    setAgents([duplicated, ...agents]);
  };

  const filteredDashboardAgents = agents.filter(agent => {
    const matchesStatus = dashboardFilter === 'All' || agent.status === dashboardFilter;
    const matchesSearch = dashboardSearch === '' || 
      agent.name.toLowerCase().includes(dashboardSearch.toLowerCase()) ||
      agent.description.toLowerCase().includes(dashboardSearch.toLowerCase()) ||
      agent.tags.some(t => t.label.toLowerCase().includes(dashboardSearch.toLowerCase()));
    return matchesStatus && matchesSearch;
  });

  const displayedDashboardAgents = showAllDashboardAgents 
    ? filteredDashboardAgents 
    : filteredDashboardAgents.slice(0, 6);

  const renderContent = () => {
    switch(currentView) {
      case 'dashboard':
        return (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
             {/* Stats Section */}
             <div id="stats-section" className="mb-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {STATS.map((stat, idx) => (
                    <StatCard key={idx} stat={stat} />
                ))}
            </div>

            {/* Agents Section */}
            <div id="agents-section" className="mb-8">
                <div className="flex flex-col md:flex-row md:items-center justify-between mb-5 gap-4">
                    <div>
                        <div className="flex items-center space-x-2">
                          <h2 className="text-xl font-bold text-gray-900">UX Design AI Agents</h2>
                          <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-100 text-indigo-700">
                            {agents.length} Agents Available
                          </span>
                        </div>
                        <p className="text-sm text-gray-500 mt-1">Manage, run, and customize your intelligent design assistants</p>
                    </div>
                    
                    <div className="flex flex-wrap items-center gap-3">
                        {/* Search in dashboard */}
                        <div className="relative">
                          <input 
                            type="text" 
                            placeholder="Filter agents..."
                            value={dashboardSearch}
                            onChange={(e) => setDashboardSearch(e.target.value)}
                            className="pl-8 pr-3 py-1.5 bg-white border border-gray-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 w-36 sm:w-44"
                          />
                          <i className="fa-solid fa-search absolute left-2.5 top-2 text-gray-400 text-xs"></i>
                          {dashboardSearch && (
                            <button onClick={() => setDashboardSearch('')} className="absolute right-2 top-2 text-gray-400 hover:text-gray-600 text-xs">
                              <i className="fa-solid fa-times"></i>
                            </button>
                          )}
                        </div>

                        {/* Status Filter */}
                        <div className="bg-white border border-gray-200 rounded-lg p-1 flex">
                            {(['All', 'Active', 'Idle'] as const).map((filterKey) => (
                              <button 
                                key={filterKey}
                                onClick={() => setDashboardFilter(filterKey)}
                                className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
                                  dashboardFilter === filterKey 
                                    ? 'bg-indigo-600 text-white shadow-sm' 
                                    : 'text-gray-600 hover:bg-gray-100'
                                }`}
                              >
                                {filterKey}
                              </button>
                            ))}
                        </div>

                        <button 
                            onClick={() => setIsNewModalOpen(true)}
                            className="bg-indigo-600 text-white px-3.5 py-1.5 rounded-lg text-xs font-medium hover:bg-indigo-700 flex items-center transition-colors shadow-sm"
                        >
                            <i className="fa-solid fa-plus mr-1.5"></i>
                            New Agent
                        </button>
                    </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* Main Agent List */}
                    <div className="lg:col-span-2 space-y-4">
                        {displayedDashboardAgents.length > 0 ? (
                          displayedDashboardAgents.map((agent) => (
                              <AgentCard 
                                  key={agent.id} 
                                  agent={agent} 
                                  onEdit={(a) => setEditingAgent(a)} 
                                  onRun={(a) => setRunningAgent(a)}
                                  onDuplicate={handleDuplicateAgent}
                              />
                          ))
                        ) : (
                          <div className="bg-white p-8 rounded-xl border border-gray-200 text-center">
                            <i className="fa-solid fa-robot text-gray-300 text-3xl mb-2"></i>
                            <p className="text-gray-600 text-sm font-medium">No agents match "{dashboardSearch}"</p>
                            <button onClick={() => setDashboardSearch('')} className="mt-2 text-xs text-indigo-600 hover:underline">
                              Clear Search
                            </button>
                          </div>
                        )}

                        <div className="flex flex-col sm:flex-row gap-3 pt-2">
                          {filteredDashboardAgents.length > 6 && (
                            <button 
                              onClick={() => setShowAllDashboardAgents(!showAllDashboardAgents)} 
                              className="flex-1 py-3 text-sm text-indigo-600 font-semibold bg-white border border-indigo-200 rounded-xl hover:bg-indigo-50 transition-colors shadow-sm flex items-center justify-center"
                            >
                                <i className={`fa-solid ${showAllDashboardAgents ? 'fa-chevron-up' : 'fa-chevron-down'} mr-2`}></i>
                                {showAllDashboardAgents ? 'Show Less' : `Show All ${filteredDashboardAgents.length} Agents on Dashboard`}
                            </button>
                          )}
                          <button 
                            onClick={() => setCurrentView('agents')} 
                            className="flex-1 py-3 text-sm text-gray-700 font-semibold bg-white border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors shadow-sm flex items-center justify-center"
                          >
                              <i className="fa-solid fa-grid-2 mr-2"></i>
                              Open Full Agents Directory ({agents.length})
                          </button>
                        </div>
                    </div>

                    {/* Sidebar / Quick Actions */}
                    <div className="lg:col-span-1 space-y-6">
                        {/* Quick Actions Panel */}
                        <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
                            <h2 className="text-lg font-bold text-gray-900 mb-4">Quick Actions</h2>
                            
                            <div className="space-y-3">
                                <button onClick={() => setIsNewModalOpen(true)} className="w-full p-4 bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-xl flex items-center justify-between hover:shadow-lg transition-all group">
                                    <div className="flex items-center">
                                        <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center mr-3">
                                            <i className="fa-solid fa-robot text-lg"></i>
                                        </div>
                                        <div className="text-left">
                                            <div className="font-semibold text-sm">Create Agent</div>
                                            <div className="text-xs text-indigo-100">Build a new AI assistant</div>
                                        </div>
                                    </div>
                                    <i className="fa-solid fa-arrow-right text-sm group-hover:translate-x-1 transition-transform"></i>
                                </button>

                                <button onClick={() => setCurrentView('auto-generate')} className="w-full p-4 bg-white border border-indigo-100 text-indigo-700 rounded-xl flex items-center justify-between hover:border-indigo-300 hover:shadow-md transition-all group">
                                    <div className="flex items-center">
                                         <div className="w-10 h-10 bg-indigo-50 rounded-lg flex items-center justify-center mr-3">
                                            <i className="fa-solid fa-wand-magic-sparkles text-lg"></i>
                                        </div>
                                        <div className="text-left">
                                            <div className="font-semibold text-sm">Run Auto-Generate</div>
                                            <div className="text-xs text-indigo-400">Generate designs instantly</div>
                                        </div>
                                    </div>
                                    <i className="fa-solid fa-arrow-right text-sm group-hover:translate-x-1 transition-transform"></i>
                                </button>

                                <button className="w-full p-4 bg-white border border-gray-200 text-gray-700 rounded-xl flex items-center justify-between hover:border-gray-300 hover:bg-gray-50 transition-all group">
                                    <div className="flex items-center">
                                         <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center mr-3">
                                            <i className="fa-solid fa-file-import text-lg text-gray-500"></i>
                                        </div>
                                        <div className="text-left">
                                            <div className="font-semibold text-sm">Import Design</div>
                                            <div className="text-xs text-gray-400">From Figma or Sketch</div>
                                        </div>
                                    </div>
                                    <i className="fa-solid fa-arrow-right text-sm group-hover:translate-x-1 transition-transform text-gray-400"></i>
                                </button>

                                 <button onClick={() => setCurrentView('suggestions')} className="w-full p-4 bg-white border border-gray-200 text-gray-700 rounded-xl flex items-center justify-between hover:border-gray-300 hover:bg-gray-50 transition-all group">
                                    <div className="flex items-center">
                                         <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center mr-3">
                                            <i className="fa-solid fa-lightbulb text-lg text-gray-500"></i>
                                        </div>
                                        <div className="text-left">
                                            <div className="font-semibold text-sm">Review Suggestions</div>
                                            <div className="text-xs text-gray-400">3 pending reviews</div>
                                        </div>
                                    </div>
                                    <div className="flex items-center">
                                        <span className="bg-pink-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full mr-2">3</span>
                                        <i className="fa-solid fa-arrow-right text-sm group-hover:translate-x-1 transition-transform text-gray-400"></i>
                                    </div>
                                </button>
                            </div>
                        </div>

                        {/* Recent Templates */}
                        <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
                             <h2 className="text-sm font-bold text-gray-900 mb-4">Recent Templates</h2>
                             <div className="space-y-4">
                                <div className="flex items-center space-x-3 cursor-pointer group">
                                    <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 flex-shrink-0"></div>
                                    <div>
                                        <div className="text-sm font-medium text-gray-900 group-hover:text-indigo-600">Dashboard Template</div>
                                        <div className="text-xs text-gray-500">Admin Panel</div>
                                    </div>
                                </div>
                                <div className="flex items-center space-x-3 cursor-pointer group">
                                    <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-purple-500 to-purple-600 flex-shrink-0"></div>
                                    <div>
                                        <div className="text-sm font-medium text-gray-900 group-hover:text-indigo-600">Landing Page</div>
                                        <div className="text-xs text-gray-500">Marketing Site</div>
                                    </div>
                                </div>
                                 <div className="flex items-center space-x-3 cursor-pointer group">
                                    <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-pink-500 to-pink-600 flex-shrink-0"></div>
                                    <div>
                                        <div className="text-sm font-medium text-gray-900 group-hover:text-indigo-600">Mobile App</div>
                                        <div className="text-xs text-gray-500">iOS Design</div>
                                    </div>
                                </div>
                             </div>
                        </div>

                         {/* Team Activity */}
                        <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
                            <h2 className="text-sm font-bold text-gray-900 mb-4">Team Activity</h2>
                            <div className="space-y-4">
                                {ACTIVITIES.slice(0, 3).map((activity) => (
                                    <div key={activity.id} className="flex items-start space-x-3">
                                        <div className={`w-8 h-8 rounded-full ${activity.iconBg} flex items-center justify-center flex-shrink-0`}>
                                            <i className={`fa-solid ${activity.icon} ${activity.iconColor} text-xs`}></i>
                                        </div>
                                        <div>
                                            <p className="text-xs text-gray-900"><span className="font-semibold">Alex Johnson</span> {activity.title.toLowerCase()}</p>
                                            <p className="text-[10px] text-gray-400">{activity.time}</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>

                    </div>
                </div>
            </div>
          </div>
        );
      case 'agents':
        return (
            <AgentsView 
                agents={agents} 
                onEdit={(a) => setEditingAgent(a)} 
                onNew={() => setIsNewModalOpen(true)}
                onRun={(a) => setRunningAgent(a)}
                onDuplicate={handleDuplicateAgent}
            />
        );
      case 'workflows':
        return <WorkflowsView />;
      case 'knowledge':
        return <KnowledgeView onNavigateToAgents={() => setCurrentView('agents')} />;
      case 'roadmaps':
      case 'roadmaps:starter':
      case 'roadmaps:features':
      case 'roadmaps:now-next-later':
      case 'roadmaps:strategy':
      case 'roadmaps:portfolio':
      case 'roadmaps:custom':
        return (
          <RoadmapsView 
            activeSubMenu={currentView} 
            onSelectSubMenu={setCurrentView} 
            onNavigateToAgents={() => setCurrentView('agents')} 
          />
        );
      case 'library':
        return <DesignLibraryView />;
      case 'projects':
        return <ProjectsView />;
      case 'analytics':
        return <AnalyticsView />;
      case 'auto-generate':
        return <AutoGenerateView />;
      case 'suggestions':
        return <SuggestionsView />;
      case 'ab-testing':
        return <ABTestingView />;
      case 'research':
        return <UserResearchView />;
      case 'documentation':
        return <DocumentationView />;
      case 'tutorials':
        return <TutorialsView />;
      case 'support':
        return <SupportView />;
      case 'profile':
        return <ProfileView />;
      case 'preferences':
        return <PreferencesView />;
      default:
        return <div>Page not found</div>;
    }
  };

  return (
    <div className="bg-gray-50 font-sans min-h-screen">
      <Sidebar 
        collapsed={collapsed} 
        toggleCollapse={toggleCollapse} 
        currentView={currentView}
        onNavigate={setCurrentView}
      />
      <Header collapsed={collapsed} onNavigate={setCurrentView} />
      
      <NewAgentModal 
        isOpen={isNewModalOpen} 
        onClose={() => setIsNewModalOpen(false)} 
        onSave={handleCreateAgent} 
      />

      <EditAgentSidebar
        isOpen={!!editingAgent}
        agent={editingAgent}
        onClose={() => setEditingAgent(null)}
        onSave={handleUpdateAgent}
      />

      <RunAgentModal
        isOpen={!!runningAgent}
        agent={runningAgent}
        onClose={() => setRunningAgent(null)}
        onEdit={(a) => {
          setRunningAgent(null);
          setEditingAgent(a);
        }}
      />

      <div className={`pt-16 transition-all duration-300 ease-in-out min-h-screen ${collapsed ? 'ml-16' : 'ml-64'}`}>
        <div className="p-6 md:p-8 max-w-7xl mx-auto min-h-[calc(100vh-4rem)]">
            {renderContent()}
        </div>
      </div>
    </div>
  );
};

export default App;