
export interface Stat {
  label: string;
  value: string;
  trend: string;
  trendUp: boolean;
  icon: string;
  colorClass: string;
  bgClass: string;
  iconColorClass: string;
}

export interface Agent {
  id: string;
  name: string;
  description: string;
  icon: string;
  iconBg: string;
  status: 'Active' | 'Running' | 'Idle' | 'Beta';
  statusColor: string;
  tags: { label: string; color: string }[];
  lastRun: string;
  successRate: string;
  statDetail: string;
  // Configuration fields
  systemPrompt?: string;
  outputStructure?: string;
  hasChainOfThought?: boolean;
}

export interface WorkflowStep {
  id: string;
  order: number;
  name: string;
  type: 'Trigger' | 'Action' | 'Condition';
  details: string;
  icon: string;
}

export interface Workflow {
  id: string;
  name: string;
  description: string;
  status: 'Active' | 'Draft' | 'Paused';
  steps: WorkflowStep[];
  lastRun: string;
}

export interface Activity {
  id: string;
  type: string;
  title: string;
  description: string;
  descriptionHighlight: string;
  time: string;
  icon: string;
  iconBg: string;
  iconColor: string;
  actor: string;
}

export interface TeamMember {
  id: string;
  name: string;
  action: string;
  time: string;
  avatar: string;
}

export interface ChartData {
  name: string;
  value: number;
}

export interface ProjectFile {
  id: string;
  name: string;
  type: 'Figma' | 'Sketch' | 'Markdown' | 'JSON' | 'ZIP' | 'CSV' | 'PDF' | 'Wireframe';
  size: string;
  date: string;
  createdBy: string;
  isAIGenerated?: boolean;
  contentSnippet?: string;
  sourceUrl?: string;
}

export interface ProjectAgentResult {
  id: string;
  agentId?: string;
  agentName: string;
  agentIcon: string;
  agentBg: string;
  runDate: string;
  summary: string;
  fullResult: string;
  status: 'Completed' | 'In Review' | 'Applied';
}

export interface ProjectTeamMember {
  id: string;
  name: string;
  role: string;
  avatar: string;
  email: string;
  status: 'Active' | 'Offline' | 'In Meeting';
  tasksCount: number;
}

export interface ProjectMilestone {
  id: string;
  phase: string;
  title: string;
  description: string;
  status: 'Completed' | 'In Progress' | 'Upcoming';
  startDate: string;
  dueDate: string;
  progress: number;
  deliverables: string[];
  completedDeliverables?: string[];
}

export interface ProjectActivityItem {
  id: string;
  actor: string;
  actorType: 'user' | 'agent';
  avatar?: string;
  icon?: string;
  action: string;
  time: string;
  details?: string;
}

export interface Project {
  id: number | string;
  title: string;
  description: string;
  category: string;
  status: 'In Progress' | 'Review' | 'Planning' | 'Completed';
  color: string;
  date: string;
  progress: number;
  screensCount: number;
  componentsCount: number;
  files: ProjectFile[];
  recentActivity: ProjectActivityItem[];
  agentResults: ProjectAgentResult[];
  teamMembers: ProjectTeamMember[];
  timeline: ProjectMilestone[];
}

export type NotificationCategory = 'agent_run' | 'system' | 'alert';

export interface AppNotification {
  id: string;
  category: NotificationCategory;
  title: string;
  message: string;
  time: string;
  read: boolean;
  icon: string;
  iconBg: string;
  badgeText: string;
  badgeColor: string;
  actionLabel?: string;
  actionView?: string;
}

export type KnowledgeType = 'document' | 'whiteboard' | 'framework';

export interface StickyNote {
  id: string;
  color: 'yellow' | 'pink' | 'blue' | 'green' | 'purple' | 'orange';
  text: string;
  author: string;
  column?: string;
  votes?: number;
}

export interface FrameworkStep {
  title: string;
  description: string;
  deliverables?: string[];
  tips?: string;
}

export interface KnowledgeItem {
  id: string;
  type: KnowledgeType;
  title: string;
  description: string;
  category: string;
  author: {
    name: string;
    avatar: string;
    role: string;
  };
  updatedAt: string;
  tags: string[];
  isFeatured?: boolean;
  
  // Document specific
  readTime?: string;
  documentFormat?: 'Markdown' | 'Spec' | 'Guide' | 'Report';
  documentContent?: string;
  
  // Whiteboard specific
  stickyCount?: number;
  collaboratorsCount?: number;
  canvasType?: 'Affinity Map' | 'User Journey' | 'Sprint Board' | 'Mind Map' | 'Architecture';
  stickyNotes?: StickyNote[];
  boardColumns?: string[];
  
  // Framework specific
  frameworkCategory?: 'Methodology' | 'Evaluation' | 'Metrics' | 'Behavioral' | 'Prioritization';
  stepsCount?: number;
  steps?: FrameworkStep[];
  recommendedAgents?: string[];
  templateSnippet?: string;
}

export type RoadmapType = 'starter' | 'features' | 'now-next-later' | 'strategy' | 'portfolio' | 'custom';

export interface RoadmapItem {
  id: string;
  roadmapType: RoadmapType;
  title: string;
  description: string;
  status: 'In Progress' | 'Completed' | 'Upcoming' | 'Review' | 'Planned';
  quarter?: string;
  dateRange?: string;
  horizon?: 'now' | 'next' | 'later';
  track?: string;
  priority?: 'P0 - Critical' | 'P1 - High' | 'P2 - Medium' | 'P3 - Low';
  effort?: 'XS' | 'S' | 'M' | 'L' | 'XL';
  impact?: 'High' | 'Medium' | 'Low';
  progress?: number;
  owner?: {
    name: string;
    avatar: string;
    role: string;
  };
  tags?: string[];
  deliverables?: string[];
  aiAgent?: string;
  releaseVersion?: string;
  dependencies?: string[];
}
