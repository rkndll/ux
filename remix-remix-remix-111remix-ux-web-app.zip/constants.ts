
import { Agent, Stat, Activity, TeamMember, ChartData, Workflow, Project, AppNotification, KnowledgeItem, RoadmapItem, RoadmapType } from './types';

export const STATS: Stat[] = [
  {
    label: "Active AI Agents",
    value: "15",
    trend: "+150%",
    trendUp: true,
    icon: "fa-robot",
    colorClass: "text-indigo-600",
    bgClass: "bg-indigo-100",
    iconColorClass: "text-indigo-600"
  },
  {
    label: "Tasks Completed",
    value: "3,480",
    trend: "+42%",
    trendUp: true,
    icon: "fa-chart-line",
    colorClass: "text-purple-600",
    bgClass: "bg-purple-100",
    iconColorClass: "text-purple-600"
  },
  {
    label: "Design Systems",
    value: "28",
    trend: "+8%",
    trendUp: true,
    icon: "fa-layer-group",
    colorClass: "text-blue-600",
    bgClass: "bg-blue-100",
    iconColorClass: "text-blue-600"
  },
  {
    label: "Time Saved",
    value: "128h",
    trend: "+35%",
    trendUp: true,
    icon: "fa-clock",
    colorClass: "text-orange-600",
    bgClass: "bg-orange-100",
    iconColorClass: "text-orange-600"
  }
];

export const AGENTS: Agent[] = [
  {
    id: "1",
    name: "UX Design Reviewer",
    description: "Analyzes your designs and provides comprehensive UX feedback with actionable recommendations.",
    icon: "fa-magnifying-glass-chart",
    iconBg: "bg-gradient-to-br from-indigo-500 to-purple-600",
    status: "Active",
    statusColor: "bg-green-100 text-green-700",
    tags: [{label: "Review", color: "bg-blue-50 text-blue-700"}, {label: "Heuristics", color: "bg-purple-50 text-purple-700"}],
    lastRun: "2 hours ago",
    successRate: "98%",
    statDetail: "847 reviews",
    systemPrompt: "You are an expert UX researcher. Analyze the provided image or text description of a user interface. Identify potential usability issues based on Nielsen's heuristics.",
    outputStructure: "JSON format with list of issues, severity level, and suggested fixes.",
    hasChainOfThought: true
  },
  {
    id: "2",
    name: "UX Documenter",
    description: "Automatically generates comprehensive UX documentation from your design files and notes.",
    icon: "fa-file-lines",
    iconBg: "bg-gradient-to-br from-blue-500 to-cyan-600",
    status: "Active",
    statusColor: "bg-green-100 text-green-700",
    tags: [{label: "Docs", color: "bg-indigo-50 text-indigo-700"}, {label: "Specs", color: "bg-cyan-50 text-cyan-700"}],
    lastRun: "5 hours ago",
    successRate: "95%",
    statDetail: "623 docs",
    systemPrompt: "You are a technical writer specializing in UX documentation. Convert the input design specs into a readable documentation format.",
    outputStructure: "Markdown with sections for Overview, User Flow, and Component details.",
    hasChainOfThought: false
  },
  {
    id: "3",
    name: "User Persona Generator",
    description: "Creates detailed user personas based on research data and user behavior patterns.",
    icon: "fa-user-group",
    iconBg: "bg-gradient-to-br from-purple-500 to-pink-600",
    status: "Active",
    statusColor: "bg-green-100 text-green-700",
    tags: [{label: "Research", color: "bg-pink-50 text-pink-700"}, {label: "Personas", color: "bg-purple-50 text-purple-700"}],
    lastRun: "15 min ago",
    successRate: "99%",
    statDetail: "412 personas",
    systemPrompt: "Create a user persona based on the following demographic and behavioral data points.",
    outputStructure: "Profile card format with Name, Bio, Goals, and Frustrations.",
    hasChainOfThought: true
  },
  {
    id: "4",
    name: "UAT Creator",
    description: "Generates comprehensive User Acceptance Test scenarios and test cases automatically.",
    icon: "fa-clipboard-check",
    iconBg: "bg-gradient-to-br from-emerald-500 to-teal-600",
    status: "Active",
    statusColor: "bg-green-100 text-green-700",
    tags: [{label: "Testing", color: "bg-green-50 text-green-700"}, {label: "QA", color: "bg-emerald-50 text-emerald-700"}],
    lastRun: "1 day ago",
    successRate: "100%",
    statDetail: "298 tests",
    systemPrompt: "Generate UAT test cases for the following user flow.",
    outputStructure: "Table with Test ID, Description, Pre-conditions, Steps, and Expected Result.",
    hasChainOfThought: false
  },
  {
    id: "5",
    name: "Focus Group Analyzer",
    description: "Analyzes focus group sessions and extracts key insights and user feedback patterns.",
    icon: "fa-comments",
    iconBg: "bg-gradient-to-br from-orange-500 to-red-600",
    status: "Active",
    statusColor: "bg-green-100 text-green-700",
    tags: [{label: "Analysis", color: "bg-orange-50 text-orange-700"}, {label: "Feedback", color: "bg-amber-50 text-amber-700"}],
    lastRun: "3 hours ago",
    successRate: "92%",
    statDetail: "156 sessions",
    systemPrompt: "Analyze the transcript of a focus group session. Identify recurring themes and sentiment.",
    outputStructure: "Summary report with key findings and sentiment analysis chart.",
    hasChainOfThought: true
  },
  {
    id: "6",
    name: "Brand Archetype Finder",
    description: "Analyzes your brand voice, mission, and visuals to pinpoint your primary and secondary Jungian brand archetypes.",
    icon: "fa-compass",
    iconBg: "bg-gradient-to-br from-amber-500 to-orange-600",
    status: "Active",
    statusColor: "bg-green-100 text-green-700",
    tags: [{label: "Brand", color: "bg-amber-50 text-amber-700"}, {label: "Archetype", color: "bg-orange-50 text-orange-700"}],
    lastRun: "45 min ago",
    successRate: "97%",
    statDetail: "189 brands",
    systemPrompt: "You are an expert brand strategist. Evaluate the user's brand description against Carl Jung's 12 archetypes. Calculate affinity scores and provide personality indicators.",
    outputStructure: "Archetype radar: Primary, Secondary, Core Motivation, and Visual Expression.",
    hasChainOfThought: true
  },
  {
    id: "7",
    name: "Brand archetypes",
    description: "Builds comprehensive brand archetype guidelines, voice and tone pillars, vocabulary, and competitor positioning.",
    icon: "fa-crown",
    iconBg: "bg-gradient-to-br from-yellow-500 to-amber-600",
    status: "Active",
    statusColor: "bg-green-100 text-green-700",
    tags: [{label: "Strategy", color: "bg-yellow-50 text-yellow-700"}, {label: "Brand", color: "bg-amber-50 text-amber-700"}],
    lastRun: "1 hour ago",
    successRate: "96%",
    statDetail: "310 profiles",
    systemPrompt: "Construct an actionable brand personality system based on specified archetypes. Detail tone spectra, copy examples, and design tokens.",
    outputStructure: "Brand Guidelines Dossier: Tone spectrum, Lexicon, and Do's and Don'ts.",
    hasChainOfThought: false
  },
  {
    id: "8",
    name: "Build personas",
    description: "Synthesizes raw user interviews, surveys, and behavioral analytics into living empathy maps and persona profiles.",
    icon: "fa-id-card",
    iconBg: "bg-gradient-to-br from-violet-500 to-purple-600",
    status: "Active",
    statusColor: "bg-green-100 text-green-700",
    tags: [{label: "Research", color: "bg-purple-50 text-purple-700"}, {label: "Personas", color: "bg-violet-50 text-violet-700"}],
    lastRun: "30 min ago",
    successRate: "98%",
    statDetail: "542 personas",
    systemPrompt: "Synthesize user research data into cohesive persona archetypes. Include Empathy Map segments: Says, Thinks, Does, Feels.",
    outputStructure: "Persona blueprint with Demographics, Jobs-to-be-Done, and Empathy Map.",
    hasChainOfThought: true
  },
  {
    id: "9",
    name: "Summarise meeting notes",
    description: "Extracts design decisions, unresolved questions, and assigns action items directly from UX meetings and critiques.",
    icon: "fa-list-check",
    iconBg: "bg-gradient-to-br from-sky-500 to-blue-600",
    status: "Active",
    statusColor: "bg-green-100 text-green-700",
    tags: [{label: "Productivity", color: "bg-sky-50 text-sky-700"}, {label: "Sync", color: "bg-blue-50 text-blue-700"}],
    lastRun: "10 min ago",
    successRate: "99%",
    statDetail: "1,120 notes",
    systemPrompt: "Transform unstructured design meeting transcripts or rough notes into concise summaries, key design decisions, and action items with owners.",
    outputStructure: "TL;DR, Key Decisions, Action Items (Owner, Task, Due Date), Open Questions.",
    hasChainOfThought: false
  },
  {
    id: "10",
    name: "Summarise document",
    description: "Condenses lengthy PRDs, design briefs, research whitepapers, and RFPs into clear, high-impact UX summaries.",
    icon: "fa-file-contract",
    iconBg: "bg-gradient-to-br from-teal-500 to-cyan-600",
    status: "Active",
    statusColor: "bg-green-100 text-green-700",
    tags: [{label: "Docs", color: "bg-teal-50 text-teal-700"}, {label: "Summary", color: "bg-cyan-50 text-cyan-700"}],
    lastRun: "4 hours ago",
    successRate: "97%",
    statDetail: "890 docs",
    systemPrompt: "Distill the provided document into a concise executive summary highlighting product objectives, user requirements, and technical constraints.",
    outputStructure: "Overview, Core Objectives, User Constraints, and Critical Takeaways.",
    hasChainOfThought: false
  },
  {
    id: "11",
    name: "User Journey Mapper",
    description: "Visualizes customer touchpoints, user emotion arcs, friction points, and opportunities across the entire product lifecycle.",
    icon: "fa-route",
    iconBg: "bg-gradient-to-br from-rose-500 to-pink-600",
    status: "Active",
    statusColor: "bg-green-100 text-green-700",
    tags: [{label: "Journey", color: "bg-rose-50 text-rose-700"}, {label: "UX Flow", color: "bg-pink-50 text-pink-700"}],
    lastRun: "20 min ago",
    successRate: "96%",
    statDetail: "460 maps",
    systemPrompt: "Map out the complete end-to-end user journey across defined stages: Discovery, Onboarding, Engagement, and Retention.",
    outputStructure: "Stage Matrix: User Goals, Actions, Emotional Score (-2 to +2), Pain Points, Opportunities.",
    hasChainOfThought: true
  },
  {
    id: "12",
    name: "Wireframe Generator",
    description: "Generates low-fidelity wireframe layouts, ASCII UI mockups, and component specifications from simple user requirements.",
    icon: "fa-border-top-left",
    iconBg: "bg-gradient-to-br from-slate-700 to-indigo-900",
    status: "Active",
    statusColor: "bg-green-100 text-green-700",
    tags: [{label: "Wireframe", color: "bg-slate-100 text-slate-700"}, {label: "Layout", color: "bg-indigo-50 text-indigo-700"}],
    lastRun: "1 hour ago",
    successRate: "94%",
    statDetail: "734 layouts",
    systemPrompt: "Translate user interface requirements into low-fidelity structural wireframe layouts, component hierarchies, and responsive break-points.",
    outputStructure: "ASCII Wireframe layout, Screen Structure Tree, and Component Specs.",
    hasChainOfThought: true
  },
  {
    id: "13",
    name: "User Research Planner",
    description: "Crafts comprehensive UX research plans with methodologies, participant screeners, study timelines, and interview scripts.",
    icon: "fa-clipboard-list",
    iconBg: "bg-gradient-to-br from-emerald-600 to-teal-700",
    status: "Active",
    statusColor: "bg-green-100 text-green-700",
    tags: [{label: "Research", color: "bg-emerald-50 text-emerald-700"}, {label: "Planning", color: "bg-teal-50 text-teal-700"}],
    lastRun: "6 hours ago",
    successRate: "98%",
    statDetail: "245 plans",
    systemPrompt: "Design an end-to-end UX research study. Specify research goals, methodology, participant criteria, screener questions, and interview guide.",
    outputStructure: "Research Protocol: Goals, Screener Criteria, 10-Question Guide, and Synthesis Method.",
    hasChainOfThought: true
  },
  {
    id: "14",
    name: "Focus Group Analyzer (Advanced)",
    description: "Deep multi-cohort focus group synthesis comparing cross-segment sentiment, consensus clusters, and friction heatmaps.",
    icon: "fa-users-viewfinder",
    iconBg: "bg-gradient-to-br from-fuchsia-600 to-rose-600",
    status: "Active",
    statusColor: "bg-green-100 text-green-700",
    tags: [{label: "Analysis", color: "bg-fuchsia-50 text-fuchsia-700"}, {label: "Cohorts", color: "bg-rose-50 text-rose-700"}],
    lastRun: "2 days ago",
    successRate: "93%",
    statDetail: "128 sessions",
    systemPrompt: "Perform comparative cohort analysis across focus group recordings. Identify consensus themes, polarization points, and feature bets.",
    outputStructure: "Cohort Comparison Matrix, Sentiment Polarities, Key Divergences, and Actionable Feature Bets.",
    hasChainOfThought: true
  },
  {
    id: "15",
    name: "UX Writer",
    description: "Generates clear, concise, and accessible microcopy for CTA buttons, error states, empty states, and onboarding flows.",
    icon: "fa-pen-nib",
    iconBg: "bg-gradient-to-br from-blue-600 to-indigo-700",
    status: "Active",
    statusColor: "bg-green-100 text-green-700",
    tags: [{label: "Writing", color: "bg-blue-50 text-blue-700"}, {label: "Microcopy", color: "bg-indigo-50 text-indigo-700"}],
    lastRun: "5 min ago",
    successRate: "99%",
    statDetail: "2,410 strings",
    systemPrompt: "Craft delightful, accessible UX microcopy adhering strictly to clarity, conciseness, and brand tone. Provide multiple variations.",
    outputStructure: "Copy Variants Table: Context, Primary Copy, Alternatives, Character Count, and Accessibility Notes.",
    hasChainOfThought: false
  }
];

export const WORKFLOWS: Workflow[] = [
  {
    id: '1',
    name: 'Design Hand-off',
    description: 'Automate generating assets and specs when a design is marked ready.',
    status: 'Active',
    lastRun: '10 min ago',
    steps: [
      { id: 's1', order: 1, name: 'Status Changed', type: 'Trigger', details: 'When Design status is "Ready for Dev"', icon: 'fa-toggle-on' },
      { id: 's2', order: 2, name: 'Generate Assets', type: 'Action', details: 'Export all exportable layers', icon: 'fa-image' },
      { id: 's3', order: 3, name: 'Generate Docs', type: 'Action', details: 'Run UX Documenter Agent', icon: 'fa-file-lines' },
      { id: 's4', order: 4, name: 'Notify Dev Team', type: 'Action', details: 'Send Slack notification to #dev-team', icon: 'fa-paper-plane' }
    ]
  },
  {
    id: '2',
    name: 'Accessibility Audit',
    description: 'Run accessibility checks weekly on all active project files.',
    status: 'Paused',
    lastRun: '5 days ago',
    steps: [
      { id: 's1', order: 1, name: 'Weekly Schedule', type: 'Trigger', details: 'Every Monday at 9:00 AM', icon: 'fa-clock' },
      { id: 's2', order: 2, name: 'Scan Projects', type: 'Action', details: 'Scan recent Figma files', icon: 'fa-magnifying-glass' },
      { id: 's3', order: 3, name: 'Generate Report', type: 'Action', details: 'Create PDF report', icon: 'fa-file-pdf' }
    ]
  }
];

export const ACTIVITIES: Activity[] = [
  {
    id: "1",
    type: "Review",
    title: "UX Design Review Completed",
    description: "Dashboard redesign project received comprehensive feedback",
    descriptionHighlight: "",
    time: "2 minutes ago",
    icon: "fa-magnifying-glass-chart",
    iconBg: "bg-indigo-100",
    iconColor: "text-indigo-600",
    actor: ""
  },
  {
    id: "2",
    type: "Persona",
    title: "New Persona Generated",
    description: "Created persona \"Tech-Savvy Professional\" for mobile app",
    descriptionHighlight: "",
    time: "15 minutes ago",
    icon: "fa-user-group",
    iconBg: "bg-purple-100",
    iconColor: "text-purple-600",
    actor: ""
  },
  {
    id: "3",
    type: "UAT",
    title: "UAT Scenarios Created",
    description: "45 test scenarios generated for checkout flow",
    descriptionHighlight: "",
    time: "1 hour ago",
    icon: "fa-clipboard-check",
    iconBg: "bg-green-100",
    iconColor: "text-green-600",
    actor: ""
  },
  {
    id: "4",
    type: "Analysis",
    title: "Focus Group Analysis",
    description: "Insights extracted from 8 participant sessions",
    descriptionHighlight: "",
    time: "3 hours ago",
    icon: "fa-comments",
    iconBg: "bg-orange-100",
    iconColor: "text-orange-600",
    actor: ""
  },
  {
    id: "5",
    type: "Docs",
    title: "Documentation Updated",
    description: "UX documentation generated for onboarding flow",
    descriptionHighlight: "",
    time: "5 hours ago",
    icon: "fa-file-lines",
    iconBg: "bg-blue-100",
    iconColor: "text-blue-600",
    actor: ""
  },
  {
    id: "6",
    type: "Brand",
    title: "Brand Archetype Identified",
    description: "Determined 'The Creator & Sage' archetype pair with 97% affinity",
    descriptionHighlight: "",
    time: "45 minutes ago",
    icon: "fa-compass",
    iconBg: "bg-amber-100",
    iconColor: "text-amber-600",
    actor: ""
  },
  {
    id: "7",
    type: "Sync",
    title: "Meeting Notes Summarised",
    description: "Extracted 12 decisions and 8 action items from Design Crit",
    descriptionHighlight: "",
    time: "10 minutes ago",
    icon: "fa-list-check",
    iconBg: "bg-sky-100",
    iconColor: "text-sky-600",
    actor: ""
  },
  {
    id: "8",
    type: "Wireframe",
    title: "Wireframes Generated",
    description: "Generated low-fi structural layout for user settings view",
    descriptionHighlight: "",
    time: "1 hour ago",
    icon: "fa-border-top-left",
    iconBg: "bg-slate-100",
    iconColor: "text-slate-700",
    actor: ""
  },
  {
    id: "9",
    type: "Content",
    title: "UX Microcopy Refined",
    description: "Optimized 18 button labels & form error states for clarity",
    descriptionHighlight: "",
    time: "5 minutes ago",
    icon: "fa-pen-nib",
    iconBg: "bg-indigo-100",
    iconColor: "text-indigo-600",
    actor: ""
  }
];

export const TEAM_ACTIVITY: TeamMember[] = [];
export const PERFORMANCE_DATA: ChartData[] = [];
export const OUTPUT_DATA: ChartData[] = [];

export const PROJECTS: Project[] = [
  {
    id: 1,
    title: "E-commerce Redesign",
    description: "Checkout and cart flow redesign with AI heuristic suggestions and frictionless payment integration.",
    category: "Web App",
    status: "In Progress",
    color: "bg-blue-500",
    date: "Last updated 2h ago",
    progress: 68,
    screensCount: 124,
    componentsCount: 45,
    files: [
      { id: "f1", name: "Checkout_Funnel_v3.fig", type: "Figma", size: "24.2 MB", date: "2h ago", createdBy: "Sarah Chen" },
      { id: "f2", name: "Nielsen_Heuristic_Review.md", type: "Markdown", size: "184 KB", date: "3h ago", createdBy: "UX Design Reviewer Agent", isAIGenerated: true, contentSnippet: "Identified 3 high-severity issues on mobile payment checkout accordion." },
      { id: "f3", name: "Cart_Microcopy_Matrix.csv", type: "CSV", size: "62 KB", date: "5h ago", createdBy: "UX Writer Agent", isAIGenerated: true, contentSnippet: "18 microcopy variants for declined cards and coupon expiration states." },
      { id: "f4", name: "Checkout_Design_Tokens.json", type: "JSON", size: "94 KB", date: "1d ago", createdBy: "Mike Rodriguez" },
      { id: "f5", name: "Assets_Icons_Export.zip", type: "ZIP", size: "14.8 MB", date: "2d ago", createdBy: "UX Documenter Agent", isAIGenerated: true }
    ],
    recentActivity: [
      { id: "a1", actor: "Sarah Chen", actorType: "user", avatar: "https://picsum.photos/40/40?random=11", action: "finalized mobile payment accordion contrast ratio (WCAG AA)", time: "2h ago", details: "Changed button background to #4F46E5 with white text." },
      { id: "a2", actor: "UX Writer", actorType: "agent", icon: "fa-pen-nib", action: "generated 18 microcopy variations for card error states", time: "3h ago", details: "Empathetic and concise variants added to design tokens." },
      { id: "a3", actor: "Mike Rodriguez", actorType: "user", avatar: "https://picsum.photos/40/40?random=12", action: "synced Figma tokens with Tailwind theme configuration", time: "5h ago" },
      { id: "a4", actor: "UAT Creator", actorType: "agent", icon: "fa-clipboard-check", action: "generated 45 acceptance test cases for 1-click checkout", time: "1d ago" },
      { id: "a5", actor: "Elena Rostova", actorType: "user", avatar: "https://picsum.photos/40/40?random=13", action: "uploaded 8 participant recordings to User Research study", time: "2d ago" }
    ],
    agentResults: [
      {
        id: "r1",
        agentName: "UX Design Reviewer",
        agentIcon: "fa-magnifying-glass-chart",
        agentBg: "bg-gradient-to-br from-indigo-500 to-purple-600",
        runDate: "Today at 10:15 AM",
        summary: "Evaluated 12 checkout screens against Nielsen heuristics. Overall score: 78/100 (3 High Severity issues fixed).",
        status: "Applied",
        fullResult: "### Heuristic Evaluation: Checkout Funnel\n\n- **Status:** Heuristic #1 & #5 Violations identified on Payment Accordion\n- **Fix Applied:** Sticky order summary pinned to bottom on viewport <640px\n- **Validation:** 0 contrast warnings remaining"
      },
      {
        id: "r2",
        agentName: "UX Writer",
        agentIcon: "fa-pen-nib",
        agentBg: "bg-gradient-to-br from-blue-600 to-indigo-700",
        runDate: "Yesterday at 4:30 PM",
        summary: "Optimized 14 button labels and 3 empty cart state copy variants.",
        status: "Completed",
        fullResult: "### Microcopy Variants: Empty Cart State\n\n1. *Your cart is waiting for great things.* (Empathetic)\n2. *No items yet. Explore trending products below.* (Actionable)\n3. Primary CTA: **Explore New Arrivals**"
      },
      {
        id: "r3",
        agentName: "UAT Creator",
        agentIcon: "fa-clipboard-check",
        agentBg: "bg-gradient-to-br from-emerald-500 to-teal-600",
        runDate: "2 days ago",
        summary: "Created 45 automated test scenarios covering guest checkout, Apple Pay, and voucher codes.",
        status: "In Review",
        fullResult: "### UAT Scenarios Suite: Checkout v3\n\n- Total Test Cases: 45\n- Pass Rate in Staging: 96%\n- Edge Cases: Expired credit card token recovery, international postal code validation"
      }
    ],
    teamMembers: [
      { id: "m1", name: "Sarah Chen", role: "Lead Product Designer", avatar: "https://picsum.photos/40/40?random=11", email: "sarah.c@company.design", status: "Active", tasksCount: 8 },
      { id: "m2", name: "Mike Rodriguez", role: "Senior UI/UX Engineer", avatar: "https://picsum.photos/40/40?random=12", email: "mike.r@company.design", status: "Active", tasksCount: 5 },
      { id: "m3", name: "Elena Rostova", role: "UX Researcher", avatar: "https://picsum.photos/40/40?random=13", email: "elena.r@company.design", status: "In Meeting", tasksCount: 3 },
      { id: "m4", name: "David Kim", role: "Product Manager", avatar: "https://picsum.photos/40/40?random=14", email: "david.k@company.design", status: "Offline", tasksCount: 4 }
    ],
    timeline: [
      { id: "t1", phase: "Phase 1", title: "Discovery & User Research", description: "Competitive benchmarking, stakeholder interviews, and funnel drop-off analytics", status: "Completed", startDate: "Oct 1", dueDate: "Oct 8", progress: 100, deliverables: ["User Research Deck", "Heuristic Benchmark Report"] },
      { id: "t2", phase: "Phase 2", title: "Information Architecture & Wireframes", description: "Low-fi mobile flows, checkout cart architecture, and wireframe generator specs", status: "Completed", startDate: "Oct 9", dueDate: "Oct 15", progress: 100, deliverables: ["Wireframe Layouts", "Clickable Low-Fi Prototype"] },
      { id: "t3", phase: "Phase 3", title: "High-Fidelity UI & Design Tokens", description: "Component specifications, dark/light theme tokens, and typography scales", status: "In Progress", startDate: "Oct 16", dueDate: "Oct 26", progress: 75, deliverables: ["Figma Component Library", "Design Tokens JSON"] },
      { id: "t4", phase: "Phase 4", title: "UAT & Usability Validation", description: "Moderated user testing with 10 participants and UAT test script validation", status: "In Progress", startDate: "Oct 24", dueDate: "Nov 3", progress: 35, deliverables: ["45 UAT Test Cases", "Usability Testing Video Synthesis"] },
      { id: "t5", phase: "Phase 5", title: "Developer Hand-off & Launch", description: "Production asset exports, Storybook documentation, and release QA", status: "Upcoming", startDate: "Nov 4", dueDate: "Nov 14", progress: 0, deliverables: ["Production Assets ZIP", "Dev Hand-off Notes"] }
    ]
  },
  {
    id: 2,
    title: "Mobile App V2",
    description: "iOS & Android mobile banking UI with biometric verification, instant transfers, and card management.",
    category: "Mobile iOS",
    status: "Review",
    color: "bg-purple-500",
    date: "Last updated 5h ago",
    progress: 88,
    screensCount: 86,
    componentsCount: 32,
    files: [
      { id: "f21", name: "Mobile_Wireframes_V2.sketch", type: "Sketch", size: "38.6 MB", date: "5h ago", createdBy: "Elena Rostova" },
      { id: "f22", name: "Biometric_Auth_Flow.fig", type: "Figma", size: "19.4 MB", date: "1d ago", createdBy: "Sarah Chen" },
      { id: "f23", name: "User_Persona_Profile.md", type: "Markdown", size: "128 KB", date: "2d ago", createdBy: "User Persona Generator Agent", isAIGenerated: true, contentSnippet: "Primary persona: The Pragmatic Saver (Maya, 29, Mobile-First)." },
      { id: "f24", name: "Focus_Group_Biometrics.pdf", type: "PDF", size: "2.8 MB", date: "3d ago", createdBy: "Focus Group Analyzer Agent", isAIGenerated: true }
    ],
    recentActivity: [
      { id: "a21", actor: "Elena Rostova", actorType: "user", avatar: "https://picsum.photos/40/40?random=13", action: "submitted biometric security flow for compliance audit", time: "5h ago" },
      { id: "a22", actor: "Focus Group Analyzer", actorType: "agent", icon: "fa-comments", action: "extracted recurring feedback on Face ID reliability in sunlight", time: "1d ago" },
      { id: "a23", actor: "Mike Rodriguez", actorType: "user", avatar: "https://picsum.photos/40/40?random=12", action: "optimized iOS haptic feedback curves in Swift prototypes", time: "2d ago" }
    ],
    agentResults: [
      {
        id: "r21",
        agentName: "User Persona Generator",
        agentIcon: "fa-user-group",
        agentBg: "bg-gradient-to-br from-purple-500 to-pink-600",
        runDate: "Oct 18, 2026",
        summary: "Created 'Maya - The Daily Saver' persona with target pain points around biometrics.",
        status: "Applied",
        fullResult: "### Persona Profile: Maya Lin (Age 29)\n- Primary Device: iPhone 15 Pro\n- Pain Point: Fingerprint reader fails when running or in cold weather\n- Recommendation: Auto-prompt 6-digit PIN fallback seamlessly"
      },
      {
        id: "r22",
        agentName: "Focus Group Analyzer",
        agentIcon: "fa-comments",
        agentBg: "bg-gradient-to-br from-orange-500 to-red-600",
        runDate: "Oct 19, 2026",
        summary: "Analyzed 6 focus group sessions on payment security. Identified 84% preference for Face ID.",
        status: "Completed",
        fullResult: "### Focus Group Synthesis\n- Consensus: Instant transfer confirmation modal needs clear recipient avatar\n- Confidence Score: 94%"
      }
    ],
    teamMembers: [
      { id: "m21", name: "Elena Rostova", role: "Product Designer", avatar: "https://picsum.photos/40/40?random=13", email: "elena.r@company.design", status: "Active", tasksCount: 6 },
      { id: "m22", name: "Sarah Chen", role: "Design Director", avatar: "https://picsum.photos/40/40?random=11", email: "sarah.c@company.design", status: "Active", tasksCount: 4 },
      { id: "m23", name: "Marcus Vance", role: "Security & QA Engineer", avatar: "https://picsum.photos/40/40?random=15", email: "marcus.v@company.design", status: "Active", tasksCount: 7 }
    ],
    timeline: [
      { id: "t21", phase: "Sprint 1", title: "Biometric & Auth Redesign", description: "Face ID, Touch ID, PIN backup, and hardware token support", status: "Completed", startDate: "Oct 1", dueDate: "Oct 10", progress: 100, deliverables: ["Biometric Specs", "Figma Prototype"] },
      { id: "t22", phase: "Sprint 2", title: "Account & Transfer UI", description: "Peer-to-peer payments and QR code scanning", status: "Completed", startDate: "Oct 11", dueDate: "Oct 20", progress: 100, deliverables: ["Transfer Micro-interactions", "Haptic Specs"] },
      { id: "t23", phase: "Sprint 3", title: "Accessibility & Security Review", description: "WCAG AAA compliance check and bank partner sign-off", status: "In Progress", startDate: "Oct 21", dueDate: "Oct 28", progress: 70, deliverables: ["Compliance Audit", "Pen-test UI Feedback"] }
    ]
  },
  {
    id: 3,
    title: "Dashboard System",
    description: "Enterprise SaaS metrics, analytics suite, multi-tenant workspace, and dark mode palette.",
    category: "Admin Suite",
    status: "Planning",
    color: "bg-gray-500",
    date: "Last updated 1d ago",
    progress: 32,
    screensCount: 42,
    componentsCount: 18,
    files: [
      { id: "f31", name: "Analytics_Grid_v1.fig", type: "Figma", size: "18.2 MB", date: "1d ago", createdBy: "Alex Johnson" },
      { id: "f32", name: "ASCII_Wireframe_Spec.txt", type: "Wireframe", size: "48 KB", date: "1d ago", createdBy: "Wireframe Generator Agent", isAIGenerated: true, contentSnippet: "Low-fi ASCII layout for customizable KPI dashboard widget cards." },
      { id: "f33", name: "PRD_Condensed_Summary.md", type: "Markdown", size: "92 KB", date: "2d ago", createdBy: "Summarise Document Agent", isAIGenerated: true }
    ],
    recentActivity: [
      { id: "a31", actor: "Wireframe Generator", actorType: "agent", icon: "fa-border-top-left", action: "created low-fidelity grid layout for customizable widgets", time: "1d ago" },
      { id: "a32", actor: "Summarise Document", actorType: "agent", icon: "fa-file-contract", action: "synthesized 34-page enterprise PRD into 4 core UX constraints", time: "2d ago" },
      { id: "a33", actor: "Alex Johnson", actorType: "user", avatar: "https://picsum.photos/40/40?random=16", action: "defined multi-tenant organization hierarchy", time: "3d ago" }
    ],
    agentResults: [
      {
        id: "r31",
        agentName: "Wireframe Generator",
        agentIcon: "fa-border-top-left",
        agentBg: "bg-gradient-to-br from-slate-700 to-indigo-900",
        runDate: "Oct 20, 2026",
        summary: "Generated 12 widget configurations with responsive collapse rules.",
        status: "Applied",
        fullResult: "### Dashboard Component Specifications\n- Grid: 12-column dynamic flex\n- Min Card Width: 280px on desktop\n- Breakpoints: xs: 375px, md: 768px, lg: 1280px"
      },
      {
        id: "r32",
        agentName: "Summarise Document",
        agentIcon: "fa-file-contract",
        agentBg: "bg-gradient-to-br from-teal-500 to-cyan-600",
        runDate: "Oct 19, 2026",
        summary: "Condensed Enterprise RBAC PRD into high-level user permissions table.",
        status: "Completed",
        fullResult: "### Executive PRD Digest\n- Core Problem: Role permission conflict resolution\n- Recommended UI: Side-drawer matrix with bulk toggle"
      }
    ],
    teamMembers: [
      { id: "m31", name: "Alex Johnson", role: "Principal UI Architect", avatar: "https://picsum.photos/40/40?random=16", email: "alex.j@company.design", status: "Active", tasksCount: 5 },
      { id: "m32", name: "David Kim", role: "Product Manager", avatar: "https://picsum.photos/40/40?random=14", email: "david.k@company.design", status: "Active", tasksCount: 3 }
    ],
    timeline: [
      { id: "t31", phase: "Phase 1", title: "Enterprise Requirements Definition", description: "RBAC, data export compliance, and white-labeling", status: "Completed", startDate: "Oct 15", dueDate: "Oct 20", progress: 100, deliverables: ["PRD Summary", "Tech Matrix"] },
      { id: "t32", phase: "Phase 2", title: "Information Architecture", description: "Data grid layout and widget ecosystem", status: "In Progress", startDate: "Oct 21", dueDate: "Oct 30", progress: 40, deliverables: ["Wireframes", "Navigation Schema"] },
      { id: "t33", phase: "Phase 3", title: "Chart & Visualization Library", description: "Recharts theme integration and accessible color palettes", status: "Upcoming", startDate: "Nov 1", dueDate: "Nov 15", progress: 0, deliverables: ["Chart Palette", "Interaction Demos"] }
    ]
  },
  {
    id: 4,
    title: "Marketing Site",
    description: "Conversion-optimized landing pages, brand component library, and interactive product demo playground.",
    category: "Marketing",
    status: "Completed",
    color: "bg-green-500",
    date: "Last updated 2d ago",
    progress: 100,
    screensCount: 19,
    componentsCount: 60,
    files: [
      { id: "f41", name: "Landing_Page_Final.fig", type: "Figma", size: "44.1 MB", date: "2d ago", createdBy: "Sarah Chen" },
      { id: "f42", name: "Brand_Voice_Guidelines.md", type: "Markdown", size: "156 KB", date: "3d ago", createdBy: "Brand archetypes Agent", isAIGenerated: true, contentSnippet: "Archetype Guide: The Creator & The Sage voice matrix and messaging pillars." },
      { id: "f43", name: "Production_Web_Export.zip", type: "ZIP", size: "32.5 MB", date: "4d ago", createdBy: "UX Documenter Agent", isAIGenerated: true }
    ],
    recentActivity: [
      { id: "a41", actor: "Brand archetypes", actorType: "agent", icon: "fa-crown", action: "generated brand archetype guidelines and copywriting vocabulary", time: "2d ago" },
      { id: "a42", actor: "Sarah Chen", actorType: "user", avatar: "https://picsum.photos/40/40?random=11", action: "pushed final SVG illustrations to production CDN", time: "2d ago" }
    ],
    agentResults: [
      {
        id: "r41",
        agentName: "Brand archetypes",
        agentIcon: "fa-crown",
        agentBg: "bg-gradient-to-br from-yellow-500 to-amber-600",
        runDate: "Oct 18, 2026",
        summary: "Crafted brand voice guidelines emphasizing 'The Creator' archetype.",
        status: "Applied",
        fullResult: "### Brand Voice Manifesto\n- Voice: Inspiring, Precise, Grounded\n- Vocabulary: Avoid buzzwords like 'synergy'; emphasize craftsmanship."
      }
    ],
    teamMembers: [
      { id: "m41", name: "Sarah Chen", role: "Creative Lead", avatar: "https://picsum.photos/40/40?random=11", email: "sarah.c@company.design", status: "Active", tasksCount: 2 },
      { id: "m42", name: "Leo Santos", role: "Frontend Dev Lead", avatar: "https://picsum.photos/40/40?random=17", email: "leo.s@company.design", status: "Active", tasksCount: 1 }
    ],
    timeline: [
      { id: "t41", phase: "Milestone 1", title: "Brand Identity & Archetype", description: "Logo, color palettes, and copywriting guidelines", status: "Completed", startDate: "Sep 20", dueDate: "Sep 30", progress: 100, deliverables: ["Brand Guidelines PDF", "Color Tokens"] },
      { id: "t42", phase: "Milestone 2", title: "Hero & Feature Pages", description: "Desktop and mobile responsive landing pages", status: "Completed", startDate: "Oct 1", dueDate: "Oct 12", progress: 100, deliverables: ["Landing Pages Figma", "Webflow Export"] },
      { id: "t43", phase: "Milestone 3", title: "Launch & Analytics", description: "A/B testing setup and performance optimization", status: "Completed", startDate: "Oct 13", dueDate: "Oct 19", progress: 100, deliverables: ["GA4 Tags", "Heatmap Setup"] }
    ]
  },
  {
    id: 5,
    title: "User Research Study",
    description: "User interviews, focus group recordings, qualitative sentiment analysis, and customer journey maps.",
    category: "UX Research",
    status: "In Progress",
    color: "bg-orange-500",
    date: "Last updated 3d ago",
    progress: 54,
    screensCount: 15,
    componentsCount: 8,
    files: [
      { id: "f51", name: "Focus_Group_Cohort_Synthesis.pdf", type: "PDF", size: "4.2 MB", date: "3d ago", createdBy: "Focus Group Analyzer (Advanced) Agent", isAIGenerated: true, contentSnippet: "Cross-cohort sentiment comparison between Gen Z and Gen X designers." },
      { id: "f52", name: "User_Journey_Map_v2.png", type: "Wireframe", size: "3.1 MB", date: "4d ago", createdBy: "User Journey Mapper Agent", isAIGenerated: true },
      { id: "f53", name: "Research_Interview_Script.md", type: "Markdown", size: "68 KB", date: "5d ago", createdBy: "User Research Planner Agent", isAIGenerated: true }
    ],
    recentActivity: [
      { id: "a51", actor: "Focus Group Analyzer", actorType: "agent", icon: "fa-users-viewfinder", action: "completed cross-cohort synthesis across 8 recorded sessions", time: "3d ago" },
      { id: "a52", actor: "User Journey Mapper", actorType: "agent", icon: "fa-route", action: "rendered 5-stage customer journey with emotional satisfaction scores", time: "4d ago" },
      { id: "a53", actor: "Elena Rostova", actorType: "user", avatar: "https://picsum.photos/40/40?random=13", action: "conducted 4 live moderated design critiques with external users", time: "5d ago" }
    ],
    agentResults: [
      {
        id: "r51",
        agentName: "Focus Group Analyzer",
        agentIcon: "fa-users-viewfinder",
        agentBg: "bg-gradient-to-br from-fuchsia-600 to-rose-600",
        runDate: "Oct 18, 2026",
        summary: "Extracted high consensus on AI auto-layout shortcut and friction in manual resizing.",
        status: "Applied",
        fullResult: "### Qualitative Insights\n- 85% of users prefer keyboard shortcuts over right-click context menu.\n- Onboarding tooltip should have a 'Don't show again' checkbox."
      },
      {
        id: "r52",
        agentName: "User Journey Mapper",
        agentIcon: "fa-route",
        agentBg: "bg-gradient-to-br from-rose-500 to-pink-600",
        runDate: "Oct 17, 2026",
        summary: "Mapped emotional arc from First Discovery to Team Export.",
        status: "Completed",
        fullResult: "### Journey Stages\n1. Sign up (+1)\n2. Prompt entry (+2)\n3. Canvas load (+2)\n4. Team invite (0 - friction around enterprise email)"
      }
    ],
    teamMembers: [
      { id: "m51", name: "Elena Rostova", role: "Lead UX Researcher", avatar: "https://picsum.photos/40/40?random=13", email: "elena.r@company.design", status: "Active", tasksCount: 7 },
      { id: "m52", name: "Sarah Chen", role: "Product Designer", avatar: "https://picsum.photos/40/40?random=11", email: "sarah.c@company.design", status: "Active", tasksCount: 3 }
    ],
    timeline: [
      { id: "t51", phase: "Stage 1", title: "Study Design & Screeners", description: "Participant recruiting and interview guide preparation", status: "Completed", startDate: "Oct 5", dueDate: "Oct 12", progress: 100, deliverables: ["Research Plan", "Screener Survey"] },
      { id: "t52", phase: "Stage 2", title: "Interviews & Focus Groups", description: "Conducting 12 user interviews and 2 focus groups", status: "In Progress", startDate: "Oct 13", dueDate: "Oct 25", progress: 65, deliverables: ["Transcripts", "Key Quotes Matrix"] },
      { id: "t53", phase: "Stage 3", title: "Synthesis & Insights Sharing", description: "Journey mapping, persona updating, and leadership readouts", status: "Upcoming", startDate: "Oct 26", dueDate: "Nov 5", progress: 0, deliverables: ["Synthesis Report", "Actionable Feature Bets"] }
    ]
  },
  {
    id: 6,
    title: "Design Tokens",
    description: "Cross-platform typography scales, spacing variables, semantic colors, and Tailwind theme configuration.",
    category: "Design System",
    status: "In Progress",
    color: "bg-pink-500",
    date: "Last updated 1w ago",
    progress: 72,
    screensCount: 35,
    componentsCount: 94,
    files: [
      { id: "f61", name: "Global_Design_Tokens.json", type: "JSON", size: "320 KB", date: "1w ago", createdBy: "Mike Rodriguez" },
      { id: "f62", name: "Component_Tokens_Spec.md", type: "Markdown", size: "210 KB", date: "1w ago", createdBy: "UX Documenter Agent", isAIGenerated: true, contentSnippet: "Design token mapping for button, card, input, and modal primitives." },
      { id: "f63", name: "Tokens_Figma_Sync.fig", type: "Figma", size: "28.4 MB", date: "1w ago", createdBy: "Sarah Chen" }
    ],
    recentActivity: [
      { id: "a61", actor: "Mike Rodriguez", actorType: "user", avatar: "https://picsum.photos/40/40?random=12", action: "standardized color contrast ratios to WCAG 2.1 AAA", time: "1w ago" },
      { id: "a62", actor: "UX Documenter", actorType: "agent", icon: "fa-file-lines", action: "generated markdown documentation for 94 design token variables", time: "1w ago" }
    ],
    agentResults: [
      {
        id: "r61",
        agentName: "UX Documenter",
        agentIcon: "fa-file-lines",
        agentBg: "bg-gradient-to-br from-blue-500 to-cyan-600",
        runDate: "Oct 14, 2026",
        summary: "Created markdown reference manual for color, spacing, and radius tokens.",
        status: "Applied",
        fullResult: "### Design Tokens Documentation\n- Colors: 48 semantic tokens\n- Spacing: 4px base grid (4px to 64px)\n- Radius: sm (4px), md (8px), lg (12px), full (9999px)"
      }
    ],
    teamMembers: [
      { id: "m61", name: "Mike Rodriguez", role: "Design Systems Engineer", avatar: "https://picsum.photos/40/40?random=12", email: "mike.r@company.design", status: "Active", tasksCount: 9 },
      { id: "m62", name: "Alex Johnson", role: "Design Architect", avatar: "https://picsum.photos/40/40?random=16", email: "alex.j@company.design", status: "Active", tasksCount: 4 }
    ],
    timeline: [
      { id: "t61", phase: "Milestone 1", title: "Primitive Tokens", description: "Raw color values, type scales, and elevation layers", status: "Completed", startDate: "Oct 1", dueDate: "Oct 8", progress: 100, deliverables: ["Primitives JSON", "Palette Swatches"] },
      { id: "t62", phase: "Milestone 2", title: "Semantic Token Mapping", description: "Surface, border, text, and stateful tokens", status: "In Progress", startDate: "Oct 9", dueDate: "Oct 22", progress: 80, deliverables: ["Semantic Tokens", "Dark Mode Mapping"] },
      { id: "t63", phase: "Milestone 3", title: "Code Generation & npm Package", description: "Publishing @company/design-tokens to npm registry", status: "Upcoming", startDate: "Oct 23", dueDate: "Nov 5", progress: 10, deliverables: ["npm package", "Storybook Integration"] }
    ]
  }
];

export const INITIAL_NOTIFICATIONS: AppNotification[] = [
  {
    id: "notif-1",
    category: "agent_run",
    title: "Heuristic Audit Completed",
    message: "UX Design Reviewer completed audit on E-commerce Redesign. Scored 98/100 with 4 accessibility optimizations.",
    time: "6m ago",
    read: false,
    icon: "fa-magnifying-glass-chart",
    iconBg: "bg-indigo-600 text-white",
    badgeText: "Agent Run",
    badgeColor: "bg-purple-100 text-purple-700",
    actionLabel: "View Results",
    actionView: "projects"
  },
  {
    id: "notif-2",
    category: "alert",
    title: "Accessibility Contrast Alert",
    message: "Low color contrast ratio (3.8:1) detected on secondary CTA button in Marketing Site template.",
    time: "24m ago",
    read: false,
    icon: "fa-triangle-exclamation",
    iconBg: "bg-amber-500 text-white",
    badgeText: "Alert",
    badgeColor: "bg-amber-100 text-amber-800",
    actionLabel: "Inspect Alert",
    actionView: "projects"
  },
  {
    id: "notif-3",
    category: "agent_run",
    title: "Wireframe Schema Generated",
    message: "Wireframe Generator produced 6 responsive layout artboards for Mobile App V2 checkout flow.",
    time: "42m ago",
    read: false,
    icon: "fa-cubes",
    iconBg: "bg-purple-600 text-white",
    badgeText: "Agent Run",
    badgeColor: "bg-purple-100 text-purple-700",
    actionLabel: "View Wireframe",
    actionView: "projects"
  },
  {
    id: "notif-4",
    category: "system",
    title: "Design Tokens v2.4 Synced",
    message: "Figma Variables & CSS Tokens synced successfully across 4 active workspaces (48 tokens updated).",
    time: "2h ago",
    read: false,
    icon: "fa-arrows-rotate",
    iconBg: "bg-blue-600 text-white",
    badgeText: "System",
    badgeColor: "bg-blue-100 text-blue-700",
    actionLabel: "Design Tokens",
    actionView: "design-library"
  },
  {
    id: "notif-5",
    category: "agent_run",
    title: "User Personas Synthesized",
    message: "User Persona Generator generated 3 high-fidelity buyer & user personas with friction maps.",
    time: "3h ago",
    read: true,
    icon: "fa-users-viewfinder",
    iconBg: "bg-pink-600 text-white",
    badgeText: "Agent Run",
    badgeColor: "bg-purple-100 text-purple-700",
    actionLabel: "View Personas",
    actionView: "user-research"
  },
  {
    id: "notif-6",
    category: "alert",
    title: "Storage Quota Warning",
    message: "Project 'Dashboard System' reached 15.6 GB of 20 GB allocation (78% capacity used).",
    time: "5h ago",
    read: true,
    icon: "fa-hard-drive",
    iconBg: "bg-rose-500 text-white",
    badgeText: "Alert",
    badgeColor: "bg-rose-100 text-rose-800",
    actionLabel: "Manage Storage",
    actionView: "preferences"
  },
  {
    id: "notif-7",
    category: "system",
    title: "Gemini 2.5 Flash Pipeline Active",
    message: "Model pipeline upgraded. Agent reasoning speeds improved by 40% with zero loss in UX fidelity.",
    time: "8h ago",
    read: true,
    icon: "fa-bolt",
    iconBg: "bg-amber-500 text-white",
    badgeText: "System",
    badgeColor: "bg-blue-100 text-blue-700",
    actionLabel: "System Status",
    actionView: "analytics"
  },
  {
    id: "notif-8",
    category: "agent_run",
    title: "Focus Group Audio Processed",
    message: "Focus Group Analyzer transcribed and extracted sentiment patterns from 12 usability sessions.",
    time: "1d ago",
    read: true,
    icon: "fa-comments-dollar",
    iconBg: "bg-teal-600 text-white",
    badgeText: "Agent Run",
    badgeColor: "bg-purple-100 text-purple-700",
    actionLabel: "Read Summary",
    actionView: "user-research"
  },
  {
    id: "notif-9",
    category: "alert",
    title: "A/B Experiment Threshold Reached",
    message: "Checkout flow Variant B reached 95% statistical significance with +14.2% conversion rate.",
    time: "1d ago",
    read: true,
    icon: "fa-vial-circle-check",
    iconBg: "bg-emerald-600 text-white",
    badgeText: "Alert",
    badgeColor: "bg-emerald-100 text-emerald-800",
    actionLabel: "View Experiment",
    actionView: "ab-testing"
  },
  {
    id: "notif-10",
    category: "system",
    title: "Timeline & Milestones Live",
    message: "New interactive milestones, deliverable checklists, and file tracking are now enabled for all projects.",
    time: "2d ago",
    read: true,
    icon: "fa-timeline",
    iconBg: "bg-indigo-600 text-white",
    badgeText: "System",
    badgeColor: "bg-blue-100 text-blue-700",
    actionLabel: "Explore Projects",
    actionView: "projects"
  }
];

export const KNOWLEDGE_ITEMS: KnowledgeItem[] = [
  // ==================== DOCUMENTS ====================
  {
    id: "doc-1",
    type: "document",
    title: "UX Design System Principles & Token Architecture",
    description: "Standardized token naming conventions, accessible color scales, spacing curves, and typography hierarchy for multi-brand applications.",
    category: "Design System",
    author: {
      name: "Elena Rostova",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&auto=format&fit=crop&q=80",
      role: "Lead Systems Architect"
    },
    updatedAt: "Yesterday at 4:15 PM",
    tags: ["Tokens", "WCAG 2.1", "Spacing", "Figma"],
    isFeatured: true,
    readTime: "7 min read",
    documentFormat: "Spec",
    documentContent: `# UX Design System Principles & Token Architecture
**Version:** 3.4.0 • **Last Updated:** Yesterday • **Status:** Approved

## 1. Core Philosophy
Our design tokens represent the single source of truth for all visual semantics across web, iOS, and Android platforms. By decoupling visual attributes from component implementation, teams can rebrand or refine interfaces with zero downstream regression.

### 1.1 The Golden Triangle of Token Naming
Every design token follows a three-tier semantic abstraction:
1. **Global Tokens (Primitives):** Raw literal values (\`color.blue.500 = #3B82F6\`, \`font.size.16 = 1rem\`).
2. **Semantic / Alias Tokens:** Contextual purpose (\`color.background.brand = {color.blue.500}\`, \`color.text.interactive = {color.indigo.600}\`).
3. **Component Tokens:** Scoped application bindings (\`button.primary.bg.default = {color.background.brand}\`).

## 2. Accessibility & Contrast Thresholds
- **Body Text:** Must exceed a minimum contrast ratio of **4.5:1** against underlying container backgrounds (WCAG Level AA).
- **Large Text & Headings (>= 18pt / 24px):** Minimum contrast ratio of **3.0:1**.
- **Interactive UI Components & Focus Rings:** Explicit minimum ratio of **3.0:1** with a mandatory 2px solid offset ring on \`:focus-visible\`.

## 3. Spatial System (8pt Dynamic Grid)
All padding, margin, gutter, and layout dimensions must snap to the 8pt soft-grid system:
- \`space-1\` (4px) — Inline icon-to-label gaps
- \`space-2\` (8px) — Dense button and badge padding
- \`space-3\` (12px) — Form field inset padding
- \`space-4\` (16px) — Card and container padding
- \`space-6\` (24px) — Section spacing
- \`space-8\` (32px) — Major layout gaps`
  },
  {
    id: "doc-2",
    type: "document",
    title: "B2B SaaS Onboarding Friction & Usability Audit",
    description: "Empirical breakdown of first-time user drop-off points, cognitive friction analysis, and time-to-first-value optimizations.",
    category: "Usability",
    author: {
      name: "Marcus Sterling",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80",
      role: "Staff UX Researcher"
    },
    updatedAt: "3 days ago",
    tags: ["Onboarding", "Activation", "Time-to-Value", "Funnel"],
    isFeatured: true,
    readTime: "9 min read",
    documentFormat: "Report",
    documentContent: `# B2B SaaS Onboarding Friction & Usability Audit
**Sample Size:** 42 Moderated Sessions & 12,400 Mixpanel Telemetry Events

## Executive Summary
Across our enterprise cohort, 34% of trial accounts abandon the platform before completing the workspace provisioning flow. The root causes are cognitive overload during workspace invitation and premature configuration demands before users understand the core value proposition.

## Key Friction Discoveries
1. **The "Empty Canvas" Syndrome (Drop-off Rate: 28%)**
   - New workspaces initialized with zero demo data produce paralysis.
   - *Recommendation:* Pre-populate accounts with 2 interactive sample projects and progressive tooltips.
2. **Forced Multi-Factor Setup on Step 2 (Drop-off Rate: 16%)**
   - Requiring SMS/Authenticator setup before the primary action increases bounce rates.
   - *Recommendation:* Defer secondary security verification until sensitive project exports or team invites.
3. **Unclear Role Assignment Taxonomies**
   - Users struggle distinguishing "Reviewer" vs "Viewer (Restricted)".
   - *Recommendation:* Replace dense dropdown lists with visual persona cards showing permissions preview.`
  },
  {
    id: "doc-3",
    type: "document",
    title: "Mobile Usability Testing Protocol & Task Benchmarks",
    description: "Standardized moderated test script, System Usability Scale (SUS) questionnaire, and quantitative benchmark scoring.",
    category: "Research",
    author: {
      name: "Amina Diallo",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80",
      role: "Senior Research Lead"
    },
    updatedAt: "May 12, 2026",
    tags: ["Protocols", "SUS", "Benchmarking", "Mobile"],
    isFeatured: false,
    readTime: "6 min read",
    documentFormat: "Guide",
    documentContent: `# Mobile Usability Testing Protocol & Task Benchmarks

## 1. Study Objectives
Determine whether mobile participants can discover, customize, and deploy an AI workflow template without facilitator intervention within 180 seconds.

## 2. Participant Screening Matrix
- 5x Novice Designers (< 1 year experience with design copilot tools)
- 5x Power Users (> 3 years experience in Figma and design systems)
- Device split: 50% iOS (Safari), 50% Android (Chrome)

## 3. Standardized Task List
- **Task 1:** Sign into workspace and locate the "Brand Archetype" agent template.
- **Task 2:** Run agent using the preloaded FinTech design context.
- **Task 3:** Export synthesized findings as a Markdown report.

## 4. Benchmark Metric Targets
- **Task Completion Rate:** >= 85%
- **Average Time-on-Task:** <= 120s
- **Mean System Usability Scale (SUS) Score Target:** >= 80.5 (Grade A)`
  },
  {
    id: "doc-4",
    type: "document",
    title: "Microcopy & Voice Guidelines for AI Copilots",
    description: "Writing actionable error states, non-robotic fallback messages, and confidence-calibrated status notifications.",
    category: "Content Strategy",
    author: {
      name: "Julian Vance",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80",
      role: "Lead UX Writer"
    },
    updatedAt: "1 week ago",
    tags: ["UX Writing", "Microcopy", "Tone", "AI Voice"],
    isFeatured: false,
    readTime: "5 min read",
    documentFormat: "Guide",
    documentContent: `# Microcopy & Voice Guidelines for AI Copilots

## Voice Principles: Intelligent, Humble, Efficient
When our agents output recommendations or alert users to design system conflicts, they must speak as an expert peer—never sycophantic, robotic, or overly apologetic.

### 1. Confidence Calibration
- **High Confidence (> 90%):** State recommendation directly.
  - *Do:* "We recommend increasing button contrast to 4.5:1 to meet WCAG AA standards."
  - *Don't:* "I believe that maybe your button could perhaps have a little more contrast."
- **Low Confidence (< 70%):** Prompt user verification.
  - *Do:* "Found 3 potential header anomalies. Review suggestions?"

### 2. Error States & Recovery
Always pair a failure with a single-click recovery path:
- *Bad:* "Error 500: Failed to synthesize wireframe."
- *Good:* "Couldn't generate the wireframe due to an unexpected timeout. Click **Retry** or run in draft mode."`
  },
  {
    id: "doc-5",
    type: "document",
    title: "Design-to-Engineering Handoff Protocol",
    description: "Figma variable bindings, auto-layout requirements, and pull-request design QA checklists.",
    category: "Engineering",
    author: {
      name: "David Kim",
      avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=120&auto=format&fit=crop&q=80",
      role: "Design Technologist"
    },
    updatedAt: "2 weeks ago",
    tags: ["Handoff", "Specs", "QA", "Components"],
    isFeatured: false,
    readTime: "8 min read",
    documentFormat: "Spec",
    documentContent: `# Design-to-Engineering Handoff Protocol

## 1. Handoff Readiness Checklist
Before marking any canvas screen with the green "Ready for Dev" tag:
1. **Auto-Layout Enforcement:** 100% of frames must use auto-layout (no absolute coordinates without explicit justification).
2. **Component Swaps:** All icons and badges must be mapped to master library instances.
3. **Empty & Error States Included:** Every table, modal, and input must show zero-data and validation failure mocks.
4. **Responsive Breakpoints:** Mocks provided for Mobile (390px), Tablet (834px), and Desktop (1440px).`
  },
  {
    id: "doc-6",
    type: "document",
    title: "Enterprise Persona & Behavioral Archetype Repository",
    description: "Empirical profiles for Design Leads, Product Managers, and Front-End Engineers using UX AI Studio.",
    category: "Research",
    author: {
      name: "Elena Rostova",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&auto=format&fit=crop&q=80",
      role: "Lead Systems Architect"
    },
    updatedAt: "3 weeks ago",
    tags: ["Personas", "Archetypes", "JTBD", "Empathy"],
    isFeatured: false,
    readTime: "11 min read",
    documentFormat: "Report",
    documentContent: `# Enterprise Persona & Behavioral Archetype Repository

## Archetype 1: The Design Systems Guardian ("Maya")
- **Role:** Staff Product Designer & Tokens Steward
- **Primary Job-to-be-Done:** Ensure consistency across 14 product squads without becoming a human bottleneck.
- **Frustrations:** Engineers creating one-off hex codes; designers detaching master symbols in Figma.
- **AI Agent Affinity:** UX Design Reviewer, Wireframe Generator.

## Archetype 2: The Fast-Paced Product Strategist ("Liam")
- **Role:** Senior PM
- **Primary Job-to-be-Done:** Rapidly test product hypotheses and validate customer problem statements before engineering sprint commitment.
- **Frustrations:** Waiting 3 weeks for preliminary design exploration.
- **AI Agent Affinity:** User Persona Generator, Journey Mapper, Summarise Document.`
  },

  // ==================== WHITEBOARDS ====================
  {
    id: "wb-1",
    type: "whiteboard",
    title: "Customer Journey & Friction Mapping Canvas",
    description: "Collaborative whiteboard analyzing touchpoint pain points, emotional curves, and AI intervention opportunities.",
    category: "Journey Mapping",
    author: {
      name: "Marcus Sterling",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80",
      role: "Staff UX Researcher"
    },
    updatedAt: "Today at 10:30 AM",
    tags: ["Journey", "Pain Points", "Canvas", "Opportunities"],
    isFeatured: true,
    stickyCount: 24,
    collaboratorsCount: 6,
    canvasType: "User Journey",
    boardColumns: ["Awareness & Discovery", "Trial Onboarding", "First Value Delivery", "Team Collaboration", "Renewal & Scale"],
    stickyNotes: [
      { id: "sn-1", color: "yellow", text: "Users get lost finding documentation for token syncing", author: "Marcus S.", column: "Awareness & Discovery", votes: 4 },
      { id: "sn-2", color: "pink", text: "High friction: requires credit card before exploring sandbox", author: "Elena R.", column: "Trial Onboarding", votes: 9 },
      { id: "sn-3", color: "green", text: "Opportunity: auto-detect user's primary Figma team on sign-in", author: "David K.", column: "Trial Onboarding", votes: 7 },
      { id: "sn-4", color: "blue", text: "AI agent prompt generates high-fidelity spec in under 15 seconds", author: "Julian V.", column: "First Value Delivery", votes: 12 },
      { id: "sn-5", color: "orange", text: "Need permission presets: Editor vs Observer vs Compliance Officer", author: "Amina D.", column: "Team Collaboration", votes: 5 },
      { id: "sn-6", color: "purple", text: "Quarterly ROI executive report generator would lock in renewals", author: "Marcus S.", column: "Renewal & Scale", votes: 8 }
    ]
  },
  {
    id: "wb-2",
    type: "whiteboard",
    title: "User Discovery & Affinity Clustering Board",
    description: "Post-interview thematic clustering grouping qualitative insights into distinct product opportunities.",
    category: "Discovery",
    author: {
      name: "Amina Diallo",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80",
      role: "Senior Research Lead"
    },
    updatedAt: "Yesterday at 2:00 PM",
    tags: ["Affinity Map", "Discovery", "Clustering", "Interviews"],
    isFeatured: true,
    stickyCount: 32,
    collaboratorsCount: 8,
    canvasType: "Affinity Map",
    boardColumns: ["Navigation & Discovery", "Design System Adoption", "AI Quality Trust", "Export & Integrations"],
    stickyNotes: [
      { id: "sn-7", color: "yellow", text: "\"I couldn't tell which tab my agent deliverables were saved under\"", author: "Participant #3", column: "Navigation & Discovery", votes: 6 },
      { id: "sn-8", color: "pink", text: "\"We have 200 components in Figma but only 40 are coded in React\"", author: "Lead Architect", column: "Design System Adoption", votes: 11 },
      { id: "sn-9", color: "green", text: "Explainable AI: users want to see the heuristic rule behind suggestions", author: "Amina D.", column: "AI Quality Trust", votes: 14 },
      { id: "sn-10", color: "blue", text: "Direct GitHub Pull Request export is our #1 requested enterprise feature", author: "David K.", column: "Export & Integrations", votes: 15 }
    ]
  },
  {
    id: "wb-3",
    type: "whiteboard",
    title: "Design Sprint 2.0 Solution & Voting Board",
    description: "Rapid ideation canvas with 'How Might We' prompts, 8-minute sketches, and dot-voting heatmap targets.",
    category: "Ideation",
    author: {
      name: "Julian Vance",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80",
      role: "Lead UX Writer"
    },
    updatedAt: "4 days ago",
    tags: ["Design Sprint", "HMW", "Voting", "Workshop"],
    isFeatured: false,
    stickyCount: 18,
    collaboratorsCount: 5,
    canvasType: "Sprint Board",
    boardColumns: ["HMW Statements", "Crazy 8s Sketches", "Heatmap Deciders", "Storyboard Target"],
    stickyNotes: [
      { id: "sn-11", color: "yellow", text: "HMW turn user interview recordings into interactive persona cards automatically?", author: "Julian V.", column: "HMW Statements", votes: 10 },
      { id: "sn-12", color: "pink", text: "HMW notify designers of accessibility violations during active canvas manipulation?", author: "Elena R.", column: "HMW Statements", votes: 13 },
      { id: "sn-13", color: "green", text: "Winner: Live Copilot floating panel with real-time heuristic badge", author: "Marcus S.", column: "Heatmap Deciders", votes: 18 }
    ]
  },
  {
    id: "wb-4",
    type: "whiteboard",
    title: "Information Architecture & Taxonomy Mindmap",
    description: "High-level hierarchy nodes, permission boundaries, and nested navigation pathways for enterprise workspaces.",
    category: "Architecture",
    author: {
      name: "Elena Rostova",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&auto=format&fit=crop&q=80",
      role: "Lead Systems Architect"
    },
    updatedAt: "1 week ago",
    tags: ["IA", "Taxonomy", "Navigation", "Mindmap"],
    isFeatured: false,
    stickyCount: 22,
    collaboratorsCount: 4,
    canvasType: "Architecture",
    boardColumns: ["Global Navigation", "Workspace Level", "Project Containers", "Asset Repositories"],
    stickyNotes: [
      { id: "sn-14", color: "blue", text: "Unified search across Projects, Agents, Files, and Knowledge", author: "Elena R.", column: "Global Navigation", votes: 8 },
      { id: "sn-15", color: "purple", text: "Role-based project folders: Private, Squad Shared, and Public", author: "David K.", column: "Workspace Level", votes: 6 }
    ]
  },
  {
    id: "wb-5",
    type: "whiteboard",
    title: "Empathy & Persona Workshop Canvas",
    description: "Classic 4-quadrant alignment board documenting what users Say, Think, Do, and Feel during design reviews.",
    category: "Discovery",
    author: {
      name: "Marcus Sterling",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80",
      role: "Staff UX Researcher"
    },
    updatedAt: "2 weeks ago",
    tags: ["Empathy", "Say-Think-Do-Feel", "Alignment"],
    isFeatured: false,
    stickyCount: 28,
    collaboratorsCount: 7,
    canvasType: "Affinity Map",
    boardColumns: ["What They SAY", "What They THINK", "What They DO", "What They FEEL"],
    stickyNotes: [
      { id: "sn-16", color: "yellow", text: "\"I don't have time to write comprehensive design system documentation\"", author: "Staff Designer", column: "What They SAY", votes: 9 },
      { id: "sn-17", color: "pink", text: "Worried that automated reviews will flag their designs unfairly in front of PMs", author: "Marcus S.", column: "What They THINK", votes: 12 },
      { id: "sn-18", color: "blue", text: "Manually compares Figma frames against brand guidelines side-by-side", author: "Amina D.", column: "What They DO", votes: 7 },
      { id: "sn-19", color: "green", text: "Relieved when repetitive accessibility checks are handled automatically", author: "Julian V.", column: "What They FEEL", votes: 11 }
    ]
  },
  {
    id: "wb-6",
    type: "whiteboard",
    title: "Design System Component Audit & Triage",
    description: "Component lifecycle triage: identifying deprecated patterns, accessibility fixes, and candidate components for extraction.",
    category: "Design System",
    author: {
      name: "David Kim",
      avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=120&auto=format&fit=crop&q=80",
      role: "Design Technologist"
    },
    updatedAt: "3 weeks ago",
    tags: ["Audit", "Components", "Triage", "Tokens"],
    isFeatured: false,
    stickyCount: 26,
    collaboratorsCount: 6,
    canvasType: "Affinity Map",
    boardColumns: ["Keep As Is", "Needs Accessibility Fix", "Merge / Refactor", "Deprecate"],
    stickyNotes: [
      { id: "sn-20", color: "green", text: "Primary and Secondary Action Buttons (100% compliant)", author: "David K.", column: "Keep As Is", votes: 5 },
      { id: "sn-21", color: "yellow", text: "Dropdown select menu lacks keyboard arrow navigation support", author: "Elena R.", column: "Needs Accessibility Fix", votes: 14 },
      { id: "sn-22", color: "pink", text: "Legacy Modal v1 has hardcoded grey backdrop; migrate to Dialog v2", author: "David K.", column: "Deprecate", votes: 8 }
    ]
  },

  // ==================== FRAMEWORKS ====================
  {
    id: "fw-1",
    type: "framework",
    title: "The Double Diamond Design Process",
    description: "The classic Design Council methodology structured into Discover, Define, Develop, and Deliver phases with AI agent mappings.",
    category: "Methodology",
    author: {
      name: "Elena Rostova",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&auto=format&fit=crop&q=80",
      role: "Lead Systems Architect"
    },
    updatedAt: "Yesterday at 11:00 AM",
    tags: ["Double Diamond", "Diverge/Converge", "Process", "Roadmap"],
    isFeatured: true,
    frameworkCategory: "Methodology",
    stepsCount: 4,
    recommendedAgents: ["User Research Planner", "Focus Group Analyzer", "User Journey Mapper", "UX Design Reviewer"],
    templateSnippet: `### Double Diamond Execution Blueprint
1. DISCOVER (Divergent): User interviews, heuristic audits, competitive benchmark.
2. DEFINE (Convergent): Problem statement (How Might We), Jobs-to-be-Done, persona archetype.
3. DEVELOP (Divergent): Wireframe variations, multi-variant user flows, design critiques.
4. DELIVER (Convergent): Production design tokens, UAT acceptance tests, developer handoff.`,
    steps: [
      {
        title: "1. Discover (Divergent Thinking)",
        description: "Explore the problem space through open-ended qualitative inquiry, user interviews, competitive landscape audits, and analytics telemetry.",
        deliverables: ["User interview transcripts", "Affinity cluster board", "Competitive matrix"],
        tips: "Avoid proposing solutions in this phase; focus entirely on understanding user pain."
      },
      {
        title: "2. Define (Convergent Thinking)",
        description: "Synthesize research findings into actionable problem statements, clear user personas, and scoped project design briefs.",
        deliverables: ["Problem statements (HMW)", "Primary persona profiles", "Scope boundaries"],
        tips: "Align stakeholders on a single primary metric for success before designing."
      },
      {
        title: "3. Develop (Divergent Thinking)",
        description: "Iterate across multiple visual and interaction directions. Generate wireframes, test information architectures, and co-design with teammates.",
        deliverables: ["Low-fidelity wireframes", "User journey prototypes", "Design critique logs"],
        tips: "Leverage AI agents like the Wireframe Generator to produce 3 distinct structural variants."
      },
      {
        title: "4. Deliver (Convergent Thinking)",
        description: "Refine chosen solution into pixel-perfect design specifications, design tokens, responsive breakpoints, and engineering QA requirements.",
        deliverables: ["Production design token file", "Interactive prototype", "Handoff redlines"],
        tips: "Run UX Design Reviewer and UAT Creator to catch usability and accessibility edge cases."
      }
    ]
  },
  {
    id: "fw-2",
    type: "framework",
    title: "Jakob Nielsen's 10 Usability Heuristics Matrix",
    description: "The industry standard heuristic evaluation framework used by UX AI Studio agents to audit interface friction.",
    category: "Evaluation",
    author: {
      name: "Marcus Sterling",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80",
      role: "Staff UX Researcher"
    },
    updatedAt: "3 days ago",
    tags: ["Heuristics", "Nielsen", "Audit", "Usability"],
    isFeatured: true,
    frameworkCategory: "Evaluation",
    stepsCount: 10,
    recommendedAgents: ["UX Design Reviewer", "UAT Creator"],
    templateSnippet: `### Nielsen 10 Heuristics Scorecard
Audit target interface from 1 (Catastrophic) to 5 (Flawless):
1. Visibility of System Status
2. Match Between System and Real World
3. User Control and Freedom
4. Consistency and Standards
5. Error Prevention
6. Recognition Rather Than Recall
7. Flexibility and Efficiency of Use
8. Aesthetic and Minimalist Design
9. Help Users Recognize, Diagnose, and Recover from Errors
10. Help and Documentation`,
    steps: [
      {
        title: "1. Visibility of System Status",
        description: "The design should always keep users informed about what is going on, through appropriate feedback within a reasonable time.",
        deliverables: ["Loading spinners & skeleton states", "Progress trackers", "Save confirmations"]
      },
      {
        title: "2. Match Between System & Real World",
        description: "The design should speak the users' language using words, phrases, and concepts familiar to them rather than system-oriented jargon.",
        deliverables: ["Domain-specific terminology dictionary", "Intuitive iconography"]
      },
      {
        title: "3. User Control & Freedom",
        description: "Users often perform actions by mistake. They need a clearly marked 'emergency exit' to leave the unwanted action without an extended process.",
        deliverables: ["Undo / Redo capability", "Cancel buttons on modals", "Safe back navigation"]
      },
      {
        title: "4. Consistency & Standards",
        description: "Users should not have to wonder whether different words, situations, or actions mean the same thing. Follow platform and industry conventions.",
        deliverables: ["Design system token conformity", "Standard keyboard shortcuts"]
      },
      {
        title: "5. Error Prevention",
        description: "Good error messages are important, but the best designs carefully prevent problems from occurring in the first place.",
        deliverables: ["Destructive action confirmations", "Smart defaults", "Input constraints"]
      }
    ]
  },
  {
    id: "fw-3",
    type: "framework",
    title: "The Hook Model Canvas for Engaging UX",
    description: "Nir Eyal's 4-phase behavioral framework: Trigger, Action, Variable Reward, and Investment for sticky product experiences.",
    category: "Behavioral",
    author: {
      name: "Julian Vance",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80",
      role: "Lead UX Writer"
    },
    updatedAt: "May 8, 2026",
    tags: ["Hook Model", "Engagement", "Behavior", "Retention"],
    isFeatured: false,
    frameworkCategory: "Behavioral",
    stepsCount: 4,
    recommendedAgents: ["UX Writer", "Brand Archetype Finder"],
    templateSnippet: `### Hook Model Loop
1. TRIGGER: External notification / Internal need to streamline design.
2. ACTION: Click agent 'Run' with 1-click prompt preset.
3. VARIABLE REWARD: Instant customized heuristic deliverable with actionable fixes.
4. INVESTMENT: Saving custom agent settings and tagging workspace team members.`,
    steps: [
      {
        title: "Phase 1: Trigger (External & Internal)",
        description: "External triggers prompt initial action (notifications, emails, UI badges). Internal triggers link user emotions or pain points to the product habit.",
        deliverables: ["Notification taxonomy", "Internal emotional state mapping"]
      },
      {
        title: "Phase 2: Action",
        description: "The simplest behavior in anticipation of reward. Fogg Behavior Model: Behavior = Motivation x Ability x Prompt.",
        deliverables: ["Frictionless CTA hierarchy", "Micro-interaction optimizations"]
      },
      {
        title: "Phase 3: Variable Reward",
        description: "Provide genuine utility and delight without predictable monotony (Rewards of the Tribe, Hunt, or Self).",
        deliverables: ["AI insight synthesis", "Achievement milestones", "Dynamic recommendations"]
      },
      {
        title: "Phase 4: Investment",
        description: "The user puts something of value back into the product (data, tokens, team members, customizations), making the next loop more valuable.",
        deliverables: ["Custom agent configurations", "Workspace shared libraries"]
      }
    ]
  },
  {
    id: "fw-4",
    type: "framework",
    title: "Google HEART Metric Framework",
    description: "Holistic UX measurement framework evaluating Happiness, Engagement, Adoption, Retention, and Task Success.",
    category: "Metrics",
    author: {
      name: "Marcus Sterling",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80",
      role: "Staff UX Researcher"
    },
    updatedAt: "2 weeks ago",
    tags: ["HEART", "Metrics", "Analytics", "Goals-Signals"],
    isFeatured: false,
    frameworkCategory: "Metrics",
    stepsCount: 5,
    recommendedAgents: ["Focus Group Analyzer", "UX Design Reviewer"],
    templateSnippet: `### Goals-Signals-Metrics (GSM) Matrix
- Happiness: CSAT, Net Promoter Score, Ease of Use ratings.
- Engagement: Active agent runs per designer per week.
- Adoption: % of new projects configured with design tokens.
- Retention: 30-day and 90-day team member workspace return rate.
- Task Success: Time-to-complete first design review report.`,
    steps: [
      {
        title: "H - Happiness",
        description: "Measures of user attitude or satisfaction, typically collected via in-product micro-surveys or CSAT prompts.",
        deliverables: ["In-app CSAT survey triggers", "Ease of Use rating scorecard"]
      },
      {
        title: "E - Engagement",
        description: "The frequency, intensity, or depth of interaction over time (e.g. number of agent runs or file downloads per active session).",
        deliverables: ["Telemetry event definitions", "Weekly active engagement dashboard"]
      },
      {
        title: "A - Adoption",
        description: "Measures how many new users start using a feature or platform (e.g. % of workspaces running an AI workflow within 7 days).",
        deliverables: ["Activation funnel tracking", "First-run completion metrics"]
      },
      {
        title: "R - Retention",
        description: "The proportion of users who return to the product or feature in a subsequent time interval.",
        deliverables: ["Cohort retention heatmaps", "Churn leading-indicator alerts"]
      },
      {
        title: "T - Task Success",
        description: "Traditional behavioral usability metrics: efficiency (time on task), effectiveness (success rate), and error rate.",
        deliverables: ["Task completion benchmarks", "Form error occurrence tracking"]
      }
    ]
  },
  {
    id: "fw-5",
    type: "framework",
    title: "Jobs-To-Be-Done (JTBD) Opportunity Canvas",
    description: "Customer-centric framework focusing on the progress people seek in a given circumstance rather than static demographic attributes.",
    category: "Methodology",
    author: {
      name: "Amina Diallo",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80",
      role: "Senior Research Lead"
    },
    updatedAt: "2 weeks ago",
    tags: ["JTBD", "Outcome-Driven", "Jobs", "Customer Needs"],
    isFeatured: false,
    frameworkCategory: "Methodology",
    stepsCount: 4,
    recommendedAgents: ["User Persona Generator", "User Journey Mapper"],
    templateSnippet: `### JTBD Formula:
"When [Circumstance / Situation],
I want to [Core Motivation / Action],
So that [Desired Functional & Emotional Outcome]."`,
    steps: [
      {
        title: "1. The Job Performer & Core Job",
        description: "Define the human who is executing the job and the fundamental progress they are trying to achieve independent of technology.",
        deliverables: ["Core Job definition", "Contextual boundary statements"]
      },
      {
        title: "2. The Circumstance & Triggers",
        description: "The specific situation, friction, or catalyst that prompts the user to seek a new solution.",
        deliverables: ["Push and pull forces matrix", "Anxiety & habit obstacles"]
      },
      {
        title: "3. Desired Outcomes (Functional & Emotional)",
        description: "The metric of success the user uses to judge whether the job was accomplished satisfactorily.",
        deliverables: ["Outcome statements (e.g. 'Minimize time required to...')"]
      },
      {
        title: "4. Solution Validation",
        description: "Evaluate how existing competitors satisfy the job versus how our proposed feature creates an order-of-magnitude improvement.",
        deliverables: ["Opportunity score ranking", "Value proposition audit"]
      }
    ]
  },
  {
    id: "fw-6",
    type: "framework",
    title: "Kano Customer Delight Prioritization Matrix",
    description: "Feature prioritization model classifying capabilities into Must-Be, Performance, Attractive Delighters, and Indifferent.",
    category: "Prioritization",
    author: {
      name: "Elena Rostova",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&auto=format&fit=crop&q=80",
      role: "Lead Systems Architect"
    },
    updatedAt: "May 2, 2026",
    tags: ["Kano", "Prioritization", "Delight", "Roadmap"],
    isFeatured: false,
    frameworkCategory: "Prioritization",
    stepsCount: 4,
    recommendedAgents: ["UX Design Reviewer", "UAT Creator"],
    templateSnippet: `### Kano Matrix Categorization:
- MUST-BE (Basic): Contrast compliance, reliable saving, data privacy.
- PERFORMANCE (Linear): Generation speed, token sync latency, export fidelity.
- ATTRACTIVE (Delighters): Proactive anomaly detection, multi-agent co-reasoning.
- INDIFFERENT: Obscure file formatting converters.`,
    steps: [
      {
        title: "1. Must-Be / Baseline Expectations",
        description: "Features taken for granted. If missing, cause intense dissatisfaction; if present, do not increase customer satisfaction.",
        deliverables: ["Compliance baseline checklist", "Data integrity guarantees"]
      },
      {
        title: "2. One-Dimensional Performance Attributes",
        description: "The more of this capability provided, the higher customer satisfaction rises linearly (e.g. agent response speed, token accuracy).",
        deliverables: ["Benchmark speed improvements", "Reliability SLAs"]
      },
      {
        title: "3. Attractive Delighters",
        description: "Unexpected innovations that cause delight when present, but do not cause dissatisfaction when omitted because users don't expect them.",
        deliverables: ["Smart AI suggestions", "Automated wireframe generation"]
      },
      {
        title: "4. Indifferent & Reverse Features",
        description: "Features users do not care about or that actively harm usability when over-engineered.",
        deliverables: ["Deprecation candidate log", "UI clutter removal roadmap"]
      }
    ]
  }
];

export const ROADMAP_ITEMS: RoadmapItem[] = [
  // ==================== 1. STARTER ROADMAP ====================
  {
    id: "star-1",
    roadmapType: "starter",
    title: "Phase 1: Design Tokens & System Core",
    description: "Define semantic colors, typography scales, spacing curves, and accessible contrast thresholds.",
    status: "Completed",
    quarter: "Sprint 1-2",
    dateRange: "Oct 1 - Oct 14",
    progress: 100,
    priority: "P0 - Critical",
    effort: "M",
    impact: "High",
    track: "Design System",
    owner: {
      name: "Elena Rostova",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&auto=format&fit=crop&q=80",
      role: "Lead Systems Architect"
    },
    tags: ["Tokens", "WCAG 2.1", "Foundations"],
    deliverables: ["Token JSON Schema", "Figma Variable Collection", "Color Contrast Matrix"],
    aiAgent: "UX Design Reviewer"
  },
  {
    id: "star-2",
    roadmapType: "starter",
    title: "Phase 2: Core Components & Navigation Shell",
    description: "Build responsive App Shell, Header, Sidebar with submenus, modal containers, and standard button variants.",
    status: "Completed",
    quarter: "Sprint 3-4",
    dateRange: "Oct 15 - Oct 28",
    progress: 100,
    priority: "P0 - Critical",
    effort: "L",
    impact: "High",
    track: "Core App",
    owner: {
      name: "David Kim",
      avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=120&auto=format&fit=crop&q=80",
      role: "Design Technologist"
    },
    tags: ["Shell", "Sidebar", "Components"],
    deliverables: ["Sidebar Submenu Architecture", "Auto-layout Shell", "Responsive Breakpoints"]
  },
  {
    id: "star-3",
    roadmapType: "starter",
    title: "Phase 3: AI Copilot Workflow Integration",
    description: "Connect 15 specialized UX agents including Heuristic Reviewer, Wireframe Generator, and Journey Mapper.",
    status: "In Progress",
    quarter: "Sprint 5-6",
    dateRange: "Oct 29 - Nov 12",
    progress: 68,
    priority: "P0 - Critical",
    effort: "XL",
    impact: "High",
    track: "AI Engine",
    owner: {
      name: "Marcus Sterling",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80",
      role: "Staff UX Researcher"
    },
    tags: ["Agents", "Automation", "Gemini"],
    deliverables: ["Live Reasoning Output", "Deliverable Export to Markdown", "Prompt Calibration"],
    aiAgent: "UX Design Reviewer"
  },
  {
    id: "star-4",
    roadmapType: "starter",
    title: "Phase 4: Knowledge Hub & Artifacts",
    description: "Launch centralized repository for Design Documents, collaborative Whiteboards, and UX Frameworks.",
    status: "In Progress",
    quarter: "Sprint 7",
    dateRange: "Nov 13 - Nov 20",
    progress: 85,
    priority: "P1 - High",
    effort: "M",
    impact: "High",
    track: "Knowledge Hub",
    owner: {
      name: "Amina Diallo",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80",
      role: "Senior Research Lead"
    },
    tags: ["Knowledge", "Specs", "Whiteboards"],
    deliverables: ["Interactive Canvas", "Framework Deep-dives", "Document Reader"]
  },
  {
    id: "star-5",
    roadmapType: "starter",
    title: "Phase 5: Public GA Launch & Analytics",
    description: "General availability rollout, workspace billing, team invitations, and telemetry tracking dashboard.",
    status: "Upcoming",
    quarter: "Sprint 8",
    dateRange: "Nov 21 - Dec 5",
    progress: 10,
    priority: "P1 - High",
    effort: "L",
    impact: "High",
    track: "Product Launch",
    owner: {
      name: "Julian Vance",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80",
      role: "Lead UX Writer"
    },
    tags: ["Launch", "GA", "Product Hunt"],
    deliverables: ["Onboarding Flow", "Launch Announcement", "Telemetry Dashboards"]
  },

  // ==================== 2. FEATURES ROADMAP ====================
  {
    id: "feat-1",
    roadmapType: "features",
    title: "Real-Time Heuristic Overlay Panel",
    description: "Floating live inspection panel providing instant Nielsen heuristic feedback while actively designing in browser canvas.",
    status: "In Progress",
    quarter: "Q4 2026",
    releaseVersion: "v2.4",
    priority: "P0 - Critical",
    effort: "M",
    impact: "High",
    track: "AI Tools",
    progress: 75,
    owner: {
      name: "Elena Rostova",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&auto=format&fit=crop&q=80",
      role: "Lead Systems Architect"
    },
    tags: ["Heuristics", "Live Audit", "WCAG"],
    deliverables: ["Floating Dock", "Color Contrast Meter", "Quick-Fix Actions"],
    aiAgent: "UX Design Reviewer"
  },
  {
    id: "feat-2",
    roadmapType: "features",
    title: "Multi-Agent Co-Pilot Chaining",
    description: "Automate sequence: run Focus Group Analyzer -> pass insights into Persona Generator -> output Wireframe draft.",
    status: "Completed",
    quarter: "Q4 2026",
    releaseVersion: "v2.4",
    priority: "P0 - Critical",
    effort: "L",
    impact: "High",
    track: "Workflows",
    progress: 100,
    owner: {
      name: "Marcus Sterling",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80",
      role: "Staff UX Researcher"
    },
    tags: ["Workflows", "Chaining", "Multi-Agent"],
    deliverables: ["Drag & Drop Step Builder", "Variable Piping", "Execution Logger"]
  },
  {
    id: "feat-3",
    roadmapType: "features",
    title: "Design-to-Tailwind CSS Exporter",
    description: "1-click export of verified components into semantic Tailwind CSS v4 code with token mappings.",
    status: "Upcoming",
    quarter: "Q1 2027",
    releaseVersion: "v2.5",
    priority: "P1 - High",
    effort: "L",
    impact: "High",
    track: "Handoff",
    progress: 25,
    owner: {
      name: "David Kim",
      avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=120&auto=format&fit=crop&q=80",
      role: "Design Technologist"
    },
    tags: ["Code Export", "Tailwind", "React"],
    deliverables: ["Component Code Generator", "JSX Snippet Viewer", "NPM Package Export"]
  },
  {
    id: "feat-4",
    roadmapType: "features",
    title: "Figma Tokens Two-Way REST Sync",
    description: "Bi-directional synchronization between UX AI Studio token repository and Figma Variable Collections.",
    status: "In Progress",
    quarter: "Q1 2027",
    releaseVersion: "v2.5",
    priority: "P0 - Critical",
    effort: "XL",
    impact: "High",
    track: "Integrations",
    progress: 40,
    owner: {
      name: "David Kim",
      avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=120&auto=format&fit=crop&q=80",
      role: "Design Technologist"
    },
    tags: ["Figma Sync", "REST API", "Variables"],
    deliverables: ["Figma Plugin Manifest", "Conflict Resolution Dialog", "Auto-Webhooks"]
  },
  {
    id: "feat-5",
    roadmapType: "features",
    title: "Enterprise SSO, SAML & Granular RBAC",
    description: "Okta, Azure AD, and Google Workspace SAML login with custom role permissions (Editor, Viewer, Auditor).",
    status: "Planned",
    quarter: "Q2 2027",
    releaseVersion: "v3.0",
    priority: "P1 - High",
    effort: "XL",
    impact: "High",
    track: "Security",
    progress: 0,
    owner: {
      name: "Elena Rostova",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&auto=format&fit=crop&q=80",
      role: "Lead Systems Architect"
    },
    tags: ["SSO", "SAML", "Security", "RBAC"],
    deliverables: ["SCIM Provisioning", "Audit Logs Export", "Role Permission Matrix"]
  },
  {
    id: "feat-6",
    roadmapType: "features",
    title: "Visual Agent Creator Sandbox",
    description: "No-code drag-and-drop prompt engineering sandbox to build and test custom studio agents with live evaluation.",
    status: "Planned",
    quarter: "Q2 2027",
    releaseVersion: "v3.0",
    priority: "P2 - Medium",
    effort: "L",
    impact: "Medium",
    track: "AI Tools",
    progress: 0,
    owner: {
      name: "Julian Vance",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80",
      role: "Lead UX Writer"
    },
    tags: ["Custom Agents", "Prompt Builder", "Sandbox"],
    deliverables: ["Agent Testing Ground", "Evaluation Benchmark Suite"]
  },

  // ==================== 3. NOW, NEXT, LATER ROADMAP ====================
  {
    id: "nnl-1",
    roadmapType: "now-next-later",
    horizon: "now",
    title: "WCAG 2.2 Color Contrast Auto-Remediator",
    description: "One-click algorithm that adjusts foreground or background hex values to hit exact 4.5:1 AA contrast ratio with minimal hue shift.",
    status: "In Progress",
    progress: 80,
    priority: "P0 - Critical",
    effort: "S",
    impact: "High",
    track: "Design System",
    owner: {
      name: "Elena Rostova",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&auto=format&fit=crop&q=80",
      role: "Lead Systems Architect"
    },
    tags: ["Accessibility", "WCAG", "Automated Fix"],
    aiAgent: "UX Design Reviewer"
  },
  {
    id: "nnl-2",
    roadmapType: "now-next-later",
    horizon: "now",
    title: "Interactive Sticky Upvoting on Whiteboards",
    description: "Enable real-time collaborative dot-voting on affinity clustering sticky notes with participant attribution.",
    status: "Completed",
    progress: 100,
    priority: "P1 - High",
    effort: "XS",
    impact: "High",
    track: "Knowledge Hub",
    owner: {
      name: "Marcus Sterling",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80",
      role: "Staff UX Researcher"
    },
    tags: ["Whiteboards", "Voting", "Collaboration"]
  },
  {
    id: "nnl-3",
    roadmapType: "now-next-later",
    horizon: "now",
    title: "Unified Notification Dropdown & Badges",
    description: "Interactive bell dropdown tracking agent completion alerts, system updates, and task milestones with category filtering.",
    status: "Completed",
    progress: 100,
    priority: "P0 - Critical",
    effort: "S",
    impact: "High",
    track: "Core App",
    owner: {
      name: "Julian Vance",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80",
      role: "Lead UX Writer"
    },
    tags: ["Notifications", "Alerts", "Header"]
  },
  {
    id: "nnl-4",
    roadmapType: "now-next-later",
    horizon: "next",
    title: "Automated Design System Regression Monitor",
    description: "Background worker that audits Figma files weekly and alerts the team when unlinked hex codes or rogue font sizes appear.",
    status: "Upcoming",
    progress: 15,
    priority: "P1 - High",
    effort: "M",
    impact: "High",
    track: "Design System",
    owner: {
      name: "David Kim",
      avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=120&auto=format&fit=crop&q=80",
      role: "Design Technologist"
    },
    tags: ["Linter", "Regressions", "Governance"]
  },
  {
    id: "nnl-5",
    roadmapType: "now-next-later",
    horizon: "next",
    title: "AI Voice & Microcopy Consistency Checker",
    description: "Scan copy against brand archetypes and tone matrices (humorous vs authoritative vs technical) to prevent tonal whiplash.",
    status: "Upcoming",
    progress: 20,
    priority: "P2 - Medium",
    effort: "M",
    impact: "Medium",
    track: "Content",
    owner: {
      name: "Julian Vance",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80",
      role: "Lead UX Writer"
    },
    tags: ["UX Writing", "Tone", "Brand Archetypes"],
    aiAgent: "UX Writer"
  },
  {
    id: "nnl-6",
    roadmapType: "now-next-later",
    horizon: "next",
    title: "Project Milestone Checklist Automations",
    description: "Automatically check off milestone deliverables when AI agent output documents or Figma files are saved to project files.",
    status: "Upcoming",
    progress: 30,
    priority: "P1 - High",
    effort: "S",
    impact: "High",
    track: "Projects",
    owner: {
      name: "Elena Rostova",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&auto=format&fit=crop&q=80",
      role: "Lead Systems Architect"
    },
    tags: ["Automation", "Checklists", "Timeline"]
  },
  {
    id: "nnl-7",
    roadmapType: "now-next-later",
    horizon: "later",
    title: "Predictive Attention Heatmaps (Eye-Tracking AI)",
    description: "Synthesize synthetic attention heatmaps to predict first 3-second user gaze fixation on landing pages and checkout flows.",
    status: "Planned",
    progress: 0,
    priority: "P2 - Medium",
    effort: "XL",
    impact: "High",
    track: "Research",
    owner: {
      name: "Marcus Sterling",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80",
      role: "Staff UX Researcher"
    },
    tags: ["Eye-Tracking", "Predictive", "Heatmaps"]
  },
  {
    id: "nnl-8",
    roadmapType: "now-next-later",
    horizon: "later",
    title: "Natural Language Prompt to Figma Auto-Layout Canvas",
    description: "Generate structured, editable Figma frames directly from natural language design briefs and user persona specs.",
    status: "Planned",
    progress: 0,
    priority: "P1 - High",
    effort: "XL",
    impact: "High",
    track: "AI Engine",
    owner: {
      name: "David Kim",
      avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=120&auto=format&fit=crop&q=80",
      role: "Design Technologist"
    },
    tags: ["GenAI", "Figma Auto-Layout", "Direct Creation"],
    aiAgent: "Wireframe Generator"
  },
  {
    id: "nnl-9",
    roadmapType: "now-next-later",
    horizon: "later",
    title: "Multiplayer Canvas Real-Time Presence",
    description: "Live cursors, collaborative selection boxes, and WebRTC audio huddles inside the Whiteboard and Framework modules.",
    status: "Planned",
    progress: 0,
    priority: "P2 - Medium",
    effort: "L",
    impact: "Medium",
    track: "Collaboration",
    owner: {
      name: "Amina Diallo",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80",
      role: "Senior Research Lead"
    },
    tags: ["Multiplayer", "Live Presence", "WebSockets"]
  },

  // ==================== 4. STRATEGY ROADMAP ====================
  {
    id: "strat-1",
    roadmapType: "strategy",
    title: "Strategic Pillar 1: Autonomous Design Copilot Acceleration",
    description: "Transition from passive review bots to active, self-correcting agents that reduce design-to-spec cycle time by 60%.",
    status: "In Progress",
    quarter: "2026 - 2027",
    progress: 72,
    priority: "P0 - Critical",
    effort: "XL",
    impact: "High",
    track: "Strategic Pillar",
    owner: {
      name: "Elena Rostova",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&auto=format&fit=crop&q=80",
      role: "Lead Systems Architect"
    },
    tags: ["Vision", "OKR", "Autonomous AI"],
    deliverables: [
      "OKR 1: 85% of design squads run at least 3 AI agent workflows per week.",
      "OKR 2: Average review turnaround falls from 72h to < 5 minutes.",
      "OKR 3: 0 token regressions in production code releases."
    ]
  },
  {
    id: "strat-2",
    roadmapType: "strategy",
    title: "Strategic Pillar 2: Enterprise Accessibility (WCAG 2.2 Level AAA)",
    description: "Establish industry leadership by guaranteeing that 100% of generated and reviewed components exceed accessibility thresholds.",
    status: "In Progress",
    quarter: "2026 - 2027",
    progress: 88,
    priority: "P0 - Critical",
    effort: "L",
    impact: "High",
    track: "Strategic Pillar",
    owner: {
      name: "Marcus Sterling",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80",
      role: "Staff UX Researcher"
    },
    tags: ["Accessibility", "WCAG 2.2", "Compliance"],
    deliverables: [
      "OKR 1: 100% of color palette scales audited with automated contrast checks.",
      "OKR 2: Screen reader aria-label generator integrated into design handoff.",
      "OKR 3: VPAT Accessibility Compliance certification achieved."
    ]
  },
  {
    id: "strat-3",
    roadmapType: "strategy",
    title: "Strategic Pillar 3: Cross-Platform Design Token Uniformity",
    description: "Unify Web (Tailwind/CSS), iOS (SwiftUI), and Android (Jetpack Compose) under a single shared token pipeline.",
    status: "Upcoming",
    quarter: "2027",
    progress: 35,
    priority: "P1 - High",
    effort: "XL",
    impact: "High",
    track: "Strategic Pillar",
    owner: {
      name: "David Kim",
      avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=120&auto=format&fit=crop&q=80",
      role: "Design Technologist"
    },
    tags: ["Multi-Platform", "SwiftUI", "Compose", "Tailwind"],
    deliverables: [
      "OKR 1: Zero manual translation between web CSS and mobile tokens.",
      "OKR 2: CI/CD token build pipeline pushing directly to GitHub repositories.",
      "OKR 3: Token documentation sync with Figma Variables."
    ]
  },
  {
    id: "strat-4",
    roadmapType: "strategy",
    title: "Strategic Pillar 4: Democratized User Research & Continuous Synthesis",
    description: "Empower every PM and designer to run moderated research studies with automated qualitative theme extraction.",
    status: "Upcoming",
    quarter: "2027",
    progress: 45,
    priority: "P1 - High",
    effort: "L",
    impact: "High",
    track: "Strategic Pillar",
    owner: {
      name: "Amina Diallo",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80",
      role: "Senior Research Lead"
    },
    tags: ["Continuous Research", "Qualitative AI", "Affinity"],
    deliverables: [
      "OKR 1: Usability test synthesis time reduced from 5 days to 2 hours.",
      "OKR 2: 10,000 participant session hours processed annually.",
      "OKR 3: Automated customer empathy quote generator."
    ]
  },

  // ==================== 5. PORTFOLIO ROADMAP ====================
  {
    id: "port-1",
    roadmapType: "portfolio",
    title: "Core Design Studio Web (Desktop & Tablet)",
    description: "Primary responsive web application for managing agents, project deliverables, and real-time design reviews.",
    status: "In Progress",
    quarter: "Track: Web Core",
    dateRange: "Q3 - Q4 2026",
    progress: 92,
    priority: "P0 - Critical",
    effort: "XL",
    impact: "High",
    track: "Web Application",
    owner: {
      name: "Elena Rostova",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&auto=format&fit=crop&q=80",
      role: "Lead Systems Architect"
    },
    tags: ["Web", "React", "Tailwind", "Responsive"],
    dependencies: ["Figma Token API", "Gemini 2.5 Engine"]
  },
  {
    id: "port-2",
    roadmapType: "portfolio",
    title: "Design System Tokens & UI Kit v3",
    description: "Shared component repository, WCAG contrast checkers, and multi-theme palette generators.",
    status: "In Progress",
    quarter: "Track: Design System",
    dateRange: "Q4 2026",
    progress: 85,
    priority: "P0 - Critical",
    effort: "L",
    impact: "High",
    track: "Design System",
    owner: {
      name: "David Kim",
      avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=120&auto=format&fit=crop&q=80",
      role: "Design Technologist"
    },
    tags: ["Tokens", "Figma", "UI Kit"],
    dependencies: ["Token JSON Architecture"]
  },
  {
    id: "port-3",
    roadmapType: "portfolio",
    title: "Mobile Companion App (iOS & Android)",
    description: "Native mobile app for reviewing design specs, approving milestone handoffs, and receiving live run alerts.",
    status: "Upcoming",
    quarter: "Track: Mobile Apps",
    dateRange: "Q1 - Q2 2027",
    progress: 30,
    priority: "P1 - High",
    effort: "XL",
    impact: "Medium",
    track: "Mobile Companion",
    owner: {
      name: "Marcus Sterling",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80",
      role: "Staff UX Researcher"
    },
    tags: ["iOS", "Android", "React Native"],
    dependencies: ["REST API v2", "Push Notification Service"]
  },
  {
    id: "port-4",
    roadmapType: "portfolio",
    title: "AI Agent Reasoning & Evaluation Engine",
    description: "Specialized model pipeline powering 15 distinct UX agents with chain-of-thought heuristic analysis.",
    status: "In Progress",
    quarter: "Track: AI Engine",
    dateRange: "Continuous",
    progress: 90,
    priority: "P0 - Critical",
    effort: "XL",
    impact: "High",
    track: "AI & ML",
    owner: {
      name: "Amina Diallo",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80",
      role: "Senior Research Lead"
    },
    tags: ["Gemini 2.5", "Prompt Engineering", "Heuristics"],
    dependencies: ["Google GenAI API"]
  },

  // ==================== 6. CUSTOM ROADMAP ====================
  {
    id: "cust-1",
    roadmapType: "custom",
    title: "Checkout Funnel Drop-off Friction Redesign",
    description: "Streamline multi-step checkout form to single-page accordion to eliminate 24% customer cart abandonment.",
    status: "In Progress",
    quarter: "Sprint Cycle A",
    dateRange: "Oct 20 - Nov 5",
    progress: 60,
    priority: "P0 - Critical",
    effort: "M",
    impact: "High",
    track: "E-Commerce",
    owner: {
      name: "Elena Rostova",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&auto=format&fit=crop&q=80",
      role: "Lead Systems Architect"
    },
    tags: ["Checkout", "Conversion", "Friction"],
    deliverables: ["Single-page Prototype", "A/B Variant Specs", "UAT Checklist"],
    aiAgent: "UX Design Reviewer"
  },
  {
    id: "cust-2",
    roadmapType: "custom",
    title: "B2B SaaS Workspace Permission Selector",
    description: "Replace dense role dropdowns with interactive persona cards explaining exact access rights.",
    status: "Completed",
    quarter: "Sprint Cycle B",
    dateRange: "Oct 10 - Oct 19",
    progress: 100,
    priority: "P1 - High",
    effort: "S",
    impact: "Medium",
    track: "User Management",
    owner: {
      name: "Julian Vance",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80",
      role: "Lead UX Writer"
    },
    tags: ["Permissions", "RBAC", "Persona Cards"]
  },
  {
    id: "cust-3",
    roadmapType: "custom",
    title: "Dark Mode Contrast Calibration for Data Grids",
    description: "Fine-tune token palette for dark mode high-density tables to prevent eye strain during long analytical workflows.",
    status: "Upcoming",
    quarter: "Sprint Cycle C",
    dateRange: "Nov 6 - Nov 18",
    progress: 10,
    priority: "P2 - Medium",
    effort: "M",
    impact: "Medium",
    track: "Theming",
    owner: {
      name: "David Kim",
      avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=120&auto=format&fit=crop&q=80",
      role: "Design Technologist"
    },
    tags: ["Dark Mode", "Data Grid", "Tokens"]
  }
];
